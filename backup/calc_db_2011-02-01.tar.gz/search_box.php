<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="jquery/styles.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="jquery/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="jquery/jquery.autocomplete.js"></script>
<script type="text/javascript" src="ajax_magic.js"></script>
</head>



<input type="text" name="q" id="tags" value="Search for a Tag" style="color:gray;" onfocus="this.value=''; this.onfocus=null; this.style.color='black';" onkeydown="if (event.keyCode==13) javascript:search_query(document.getElementById('tags').value);" size="30"/>




<? 
$list_of_tags=implode(",",array_keys(tag_list()));
?>

<script type="text/javascript">
//<![CDATA[


var a1;

// function InitMonths() {
// 	a2.setOptions({lookup: '<?php echo $list_of_tags; ?>'.split(',') });
// }

a1 = $('#tags').autocomplete({
  width: 300,
  delimiter: /(,|;)\s*/,
  lookup: '<?php echo $list_of_tags; ?>'.split(',')
});

jQuery(function() {
	$('#navigation a').each(function() {
	  $(this).click(function(e) {
	    var element = $(this).attr('href');
	    $('html').animate({ scrollTop: $(element).offset().top }, 300, null, function() { document.location = element; });
	    e.preventDefault();
	  });
	});
});

//]]>
</script>