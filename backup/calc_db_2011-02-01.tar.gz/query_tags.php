
<?
include("connect.php");
include("functions.php");

// make sure something was actually given
if (strlen($_GET['tags']) == 0 || $_GET['tags'] == "undefined") { echo "No tags specified!"; include("search_box.php"); die; }

// get the list of search operators
$search_all = explode(",",$_GET['tags']);

// sort through the various operators
foreach ($search_all as $curtag)
{
	if (substr_count($curtag,"type:"))		// restrict to a particular type
	{
		$type_include = str_replace("type:","",$curtag);
		$_SESSION['last_type'] = $type_include; 	// for guessing the next problem type to add
	} 
	elseif (substr_count($curtag,"not:"))	// remove tags with not: operator
	{
		$tag_exclude[] = str_replace("not:","",$curtag);
	}
	else							// otherwise, search for problems with that tag
	{
		$tag_include[] = $curtag;
	}
}

// if a type restriction is set, get all the UIDs for that type.
// in the future, it would be nice if types were marked the same way as tags in the database.
$typeprobids = array();
if ($type_include)
{
	// possible sql injection here
	$q_type = mysql_query("SELECT uid FROM problems WHERE type=\"$type_include\"");
	while ($row = mysql_fetch_array($q_type)) { $typeprobids[] = $row{'uid'}; }
}

// get an array of all tags we're interested in 
$all_tags = array_merge($tag_include, $tag_exclude);

// if anything is there, put it together for mysql
if (sizeof($all_tags) > 0) 
{ 
	$all_tags_string = "\"".implode("\",\"",$all_tags)."\""; 

	// query for the tagids for all interesting tags -- possible sql injection here.
	$q_tagids = mysql_query("SELECT uid,tag FROM tags WHERE tag IN ($all_tags_string)");
	while ($row = mysql_fetch_array($q_tagids)) { $tagids[$row{'tag'}] = $row{'uid'}; }

	// for each tag, get the UIDs associated to it
	foreach($all_tags as $value)
	{
		$q_uids = mysql_query("SELECT probid FROM probtags WHERE tagid=".$tagids[$value]);
		while ($row = mysql_fetch_array($q_uids)) { $tagprobids[$value][] = $row{'probid'}; }
	}
}
elseif ($type_include) {
	// do nothing, but don't die in the next case. this could be nicer.
}
else { 
	echo "No search criteria were specified!"; die; 
}

// intersect all UIDs in include category
foreach ($tag_include as $tag)
{
	$include_uids_by_tag[$tag] = $tagprobids[$tag]; // pick out all the uids by tag to include
}
if (sizeof($include_uids_by_tag) > 1) 
{
	$include_uids = call_user_func_array('array_intersect', $include_uids_by_tag);
} else {
	$include_uids = end($include_uids_by_tag);
}


// if a type was specified, subtract everything that wasn't that type
if ($type_include && sizeof($tag_include) > 0) // type and include tag specified
{
	$include_uids = array_intersect($typeprobids, $include_uids);
} 
elseif ($type_include) // type but no include tags specified
{
	$include_uids = $typeprobids;
}
elseif (sizeof($tag_exclude) > 0 && sizeof($tag_include) == 0) // no type and no include tags... only not: operators specified.
{
	echo "Searching with only not: operators is not supported."; die;
}
else {

}

// merge all UIDs in exclude category
$exclude_uids = array();
foreach ($tag_exclude as $tag)
{
	$exclude_uids = array_merge($exclude_uids, $tagprobids[$tag]);
}

// remove excluded UIDs from included UIDs
$uid_list = array_diff($include_uids, $exclude_uids);


// build and print the search clue;
foreach ($search_all as $value) 
{ 
	$removed_text = implode(",",array_diff($search_all,array($value)));
	$search_text[] = "<span style='border:solid lightgray 1pt; padding:2px; -moz-border-radius:5px; border-radius:5px;'>$value&nbsp;<sup>(<a class='xbutton' href=\"javascript:query_tags('$removed_text')\">x</a>)</sup></span>"; 
}
$search_clue = implode(", ",$search_text);
echo "<p style=\"border: solid lightgray 1pt; padding:5px;line-height:140%;\"><b>Your search</b> <small>(Click <small>(<font color='grey'>x</font>)</small> to remove a critereon.)</small><br>$search_clue. </p>";


// if anything is left, put it back together for the sql query
if (sizeof($uid_list) > 0) { $uid_string = implode(", ",$uid_list); }
else { echo "Nothing matched your search query. Try removing a criterion above."; die; }


// get the tagids for every problem in the query -- THIS SHOULD BE REMOVED AND EARLIER RESULT USED.
unset($all_tags);
$q_tagids = mysql_query("SELECT probid,tagid FROM probtags WHERE probid IN ($uid_string)");
while ($row = mysql_fetch_array($q_tagids))
{
	$prob_tags[$row{'probid'}][$row{'tagid'}]="";
	$all_tags[$row{'tagid'}] = ""; // this will be filled with tag names later
}

// get the tag names for every tag found above
$tagid_list = "\"".implode("\",\"",array_keys($all_tags))."\"";
$q_tagnames = mysql_query("SELECT uid,tag FROM tags WHERE uid IN ($tagid_list)");
while ($row = mysql_fetch_array($q_tagnames))
{
	$all_tags[$row{'uid'}] = $row{'tag'};
}

// adjoin the tagids in $prob_tags with their real names
foreach($prob_tags as $uid => $tagarray)
{
	foreach($tagarray as $tagid => $blank)
	{
		$prob_tags[$uid][$tagid] = $all_tags[$tagid];
	}
}

// query the problems
$q_probs = mysql_query("SELECT uid,prob,answer,type FROM problems WHERE uid IN ($uid_string) ORDER BY type, uid");

// construct the main array of problems
while ($row = mysql_fetch_array($q_probs))
{
	$probs[$row{'type'}][$row{'uid'}]['prob'] = $row{'prob'};
	$probs[$row{'type'}][$row{'uid'}]['answer'] = $row{'answer'};
	$probs[$row{'type'}][$row{'uid'}]['tags'] = $prob_tags[$row{'uid'}]; // array of tagids from above
}


// get the directions for each type
$type_list = "\"".implode("\",\"",array_keys($probs))."\"";
$q_directions = mysql_query("SELECT type,directions FROM directions WHERE type IN ($type_list)");
while ($row = mysql_fetch_array($q_directions)) { $directions[$row{'type'}] = $row{'directions'}; }

// build and print the related tags field
sort($all_tags);
foreach ($all_tags as $value)
{
	if (!in_array($value, $search_all)) 
	{ 
		$added_text = implode(",",array_merge($search_all,array($value)));
		$notted_text = implode(",",array_merge(array_diff($search_all,array($value)),array("not:$value")));
		$related_text[] = "<span style='border:solid lightgray 1pt; padding:2px; -moz-border-radius:5px; border-radius:5px;'><a class='tag' href=\"javascript:query_tags('$added_text')\">$value</a>&nbsp;<sup>(<a class='xbutton' href=\"javascript:query_tags('$notted_text')\" title='Remove $value'>x</a>)</sup></span>"; 
	}
}
if (sizeof($related_text) > 0)
{
	$related_clue = implode(", ", $related_text);
	echo "<p style='border:solid lightgray 1pt; padding:5px;line-height:140%;'><b>Narrow your search</b> to a tag by clicking its name, or exclude that tag by clicking <small>(<font color=grey>x</font>)</small>.<br>$related_clue.</p>";
}

// add all to cart link
echo "<a href=\"javascript:add_to_cart_bulk($uid_string);\">Add all to cart</a>";

// compute content cell widths
$spaces = 2*(1 + $_SESSION['sol_disp']) + $_SESSION['tag_disp'];
$big_space = 2*round(100/$spaces);
$small_space = round(100/$spaces);

// begin the table to display results
echo "<table width=100% cellpadding=\"10\" cellspacing=\"0\" border=\"0\">";

// loop through each type
foreach ($probs as $type => $type_probs)
{
	// print a blank spacer row
	echo "<tr bgcolor=white><td></td></tr>";
	
	// print the directions row
	echo "<tr bgcolor=lightblue><td colspan=6><b>".$directions[$type]."</b></td></tr>";
	
	// loop through each problem of that type
	foreach ($type_probs as $uid => $curprob)
	{
		// start counting to flip between colors
		$count += 1;
		if ($count % 2) { $rowcolor = "E1FCFC"; } else { $rowcolor = "CCFFFF"; }
		
		// start the row
		echo "<tr bgcolor = \"$rowcolor\">";

		// print a blank spacer cell
		echo "<td width=\"1px\" bgcolor=white>&nbsp;</td>";

		// print add/edit buttons cell
		echo "<td width=\"50px\" align=center>";
		echo "<p><span id=\"button$uid\">";
		sensitive_button($uid);
		echo "</span>";
		echo "<p><a href='add_prob_form.php?uid=$uid' title='Edit problem number $uid' "; 
		echo "onclick=\"return GB_showCenter('Edit problem', this.href,550,700,function () { query_last();} )\">"; 
		echo "<img border=0 src='img/edit.png'></a>";
		echo "</td>";		
		
		// print the problem
		echo "<td width=$big_space%>";
		echo build_prob($uid,$curprob['prob'],0); 
		echo "</td>";
		
		// if solutions are enabled, print the solution
		if ($_SESSION['sol_disp'])
		{
			echo "<td width=$big_space%>";
			echo "<span style=\"font-size:x-small;\">Answer</span>"; 
			echo "<p  style=\"border: solid lightgray 1pt; padding:5px;\">";
			echo build_prob($uid,$curprob['answer'],0,"f","a");
			echo "</td>";
		}
		
		// if tags are enabled, print the tags
		if ($_SESSION['tag_disp'])
		{
			echo "<td width=$small_space%>";
			echo "<span id=\"tagarea$uid\"><small>Tags:&nbsp;(<a class='xbutton' href=\"javascript:load_tag_box($uid)\">add&nbsp;tag</a>)</small></span><br>";
			echo "<span id=\"taglist$uid\">";
			echo implode(", ",$probs[$type][$uid]['tags'])."";
			echo "</span></td>";
		}
		
		// finish the row
		echo "</tr>";
	}
	
	
}

// end the table of results
echo "</table>";









?>
