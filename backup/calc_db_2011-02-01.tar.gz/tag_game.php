<?
include("connect.php");
include("functions.php");

$q_random_uids = mysql_query("SELECT uid,type FROM problems ORDER BY RAND() LIMIT 3");
while ($row = mysql_fetch_array($q_random_uids)) {
	$result[$row{'uid'}] = $row{'type'};
}

?>

<h3>Tag game!</h3>

<p>Add any tags the following problems might be missing!</p>

<table width=100% cellpadding="10" cellspacing="0" border=0>





</table>

<center><h2><a href="javascript:play_tag_game();">Play Again</a>!</h2></center>
