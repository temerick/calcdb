<?
session_start();

if (!isset($_SESSION['sol_disp'])) $_SESSION['sol_disp'] = 0;
if ($_GET['toggle']) $_SESSION['sol_disp'] = !($_SESSION['sol_disp']);

echo "<a href=\"javascript:toggle_sol_disp()\">";

if ($_SESSION['sol_disp'])
	echo "shown";
else
	echo "hidden";

echo "</a>";

?>
