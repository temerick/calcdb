<?
include("../connect.php");
include("../functions.php");

$whichPage=$_GET['p'];
$time=time();

if(!mkdir("./temp/".session_id().$time)) { // Make a directory to store all of this stuff in.
	echo "unable to create directory. :(";
}

if($whichPage=="zip") { // this will be used for zipping and downloading / emailing.
	
	if(array_key_exists("email",$_POST)) { // Determine integrity of email address.
		include("validEmail.php");
		if(!validEmail($_POST['emailAddress'])) { // Huh. For some reason this hangs when I enter in a crazy domain that doesn't exist. Better than it going through, but it would be nice if it picked up on that. I don't know enough about the script to debug it right now, though.
			
			header( 'Location: http://people.virginia.edu/~svd5d/db_test/latex.php?p=notvalid' ); // I can't get this to work as a relative path. i.e. I wanted to use ../latex.php?p=notvalid , but that didn't fly for some reason. :(
			// This non-relative path is something it'd be really nice to fix. I'm not entirely sure what's wrong. I was thinking about using the server referrer and just tacking on "?p=notvalid" at the end, but that would break if the user entered in a bad email address more than once. (You'd get "?p=notvalid?p=notvalid", which would error.)
			
		}
	}
	
	
	
	// Grab the UIDs you're looking for
	$list_of_uids=array_values($_SESSION['mycart']);
	
	// Let's hunt for images:
	
	foreach($list_of_uids as $id) {
		$images=array_merge($images,find_images($id,2,"../"));
	}

	
	if(array_key_exists("problems",$_POST)) { // build "problems"
		build_tex("problems",$time); 
	}
	if(array_key_exists("answers",$_POST)) { // build "answers"
		build_tex("answers",$time);
	}
	if(array_key_exists("hybrid",$_POST)) { // build "hybrid"
		build_tex("hybrid",$time);
	}
	// Zip the files
	require ("pclzip.lib.php");
	$zipfile = new PclZip('temp/'.session_id().$time.'/packet.zip');
	
	
	print_r($images);
	
	// add problems
	if(array_key_exists("problems",$_POST)) { 
		
		$v_list = $zipfile->add('temp/'.session_id().$time.'/problems.tex','','temp/'.session_id().$time); 
		if ($v_list == 0) { // error handling
			die ("Error: " . $zipfile->errorInfo(true));
		}	
	}
	
	if(array_key_exists("answers",$_POST)) { // add answers
		
		$v_list = $zipfile->add('temp/'.session_id().$time.'/answers.tex','','temp/'.session_id().$time);
		if ($v_list == 0) {
			die ("Error: " . $zipfile->errorInfo(true));
		}
	}
	
	if(array_key_exists("hybrid",$_POST)) { // add hybrid
		
		$v_list = $zipfile->add('temp/'.session_id().$time.'/hybrid.tex','','temp/'.session_id().$time);
		if ($v_list == 0) {
			die ("Error: " . $zipfile->errorInfo(true));
		}
	}
	
	// Now to add the images:
	$v_list = $zipfile->add($images,'images/','../problem_images/');
	if ($v_list ==0) {
		die ("Error: " . $zipfile->errorInfo(true));
	}
	
	
	
	if(array_key_exists("download",$_POST)) {  // Download.
		header( 'Location: temp/'.session_id().$time.'/packet.zip');
	}
	
	if(array_key_exists("email",$_POST)) { // Email.
		include("email.php");
	}
	
} else { // if p=problems, answers, or hybrid	
	build_tex($whichPage,$time);
	header( 'Location: temp/'.session_id().$time.'/'.$whichPage. '.tex' );
}

?>
