<?php
include("connect.php");
?>

<?
$ids=array_keys($_POST,"on");
//$result = mysql_query("SELECT * FROM problems WHERE uid=".$UID);
?>

<table>
<tr>
<td>UID</td><td>Problem</td><td>Answer</td><td>Type</td><td>Comment</td></tr>


<?
foreach($ids as $UID) {
$row = mysql_fetch_array(mysql_query("SELECT * FROM problems WHERE uid=".$UID))
print_r($row);
//echo "<tr><td>".$row[0]{'uid'}."</td>
//<td>".$row[0]{'prob'}."</td>
//<td>".$row[0]{'answer'}."</td>
//<td> ".$row[0]{'type'}." </td><td>".$row[0]{'comment'}."</td>
//</tr>";
}
?>
</table>


<p>Are you SURE you want to delete this problem?</p>

<!--<p><a href="delete_act.php?uid=<?echo $UID ?>">Make it so.</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php">Go back</a></p>-->
