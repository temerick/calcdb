<?
include("connect.php");
?>

<?
$UID=$_GET["uid"];
$result = mysql_query("SELECT * FROM problems WHERE uid=".$UID);
?>

<p>Duplicating problem ID <? echo $UID; ?>.</p>

<form action="insert.php" method="post">
<?
while ($row = mysql_fetch_array($result)) {
$add_prob=$row{'prob'};
$add_ans=$row{'answer'};
$add_type=$row{'type'};
$add_comment=$row{'comment'};
include("add_prob_form.php"); 
}
?>
<input type="submit" value="Save" />
</form>


<p>Or <a href="index.php">Go back</a>.</p>
