<?
include("functions.php");
echo "testing should appear next if it works<br>";
echo build_prob(5,"testing [[f]] [[IMAGE]]",1,"f");

?>
