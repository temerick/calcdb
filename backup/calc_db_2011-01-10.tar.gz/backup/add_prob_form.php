<SCRIPT SRC="MathJax/MathJax.js"> 
  MathJax.Hub.Config({
    extensions: ["tex2jax.js"],
    jax: ["input/TeX","output/HTML-CSS"],
    tex2jax: {inlineMath: [["$","$"],["\\(","\\)"]]}
  });
</SCRIPT> 
<script src="ajax_magic.js" type="text/javascript"></script>
<script src="add_prob_java.js" type="text/javascript"></script>
<script src="toggle.js" type="text/javascript"></script>

<?

// this page exists as a separate html page, loaded in a frame via greybox.
// if we ever decide to load it via an invisible div in index.php, all of these includes and scripts will be unnecessary and probably create errors.

include("connect.php");
include("functions.php");

unset($_SESSION['last_action']);
unset($_SESSION['last_modified_uid']);
unset($_SESSION['last_modified_type']);

if (isset($_GET["uid"]))
{
	$edit_uid = $_GET["uid"];
} 
else {
	$edit_uid = "new";
}

?>



<table>
<tr>
<td><font size=+1><b>Problem Preview</b></font> <small>(UID <? echo $edit_uid; ?>)</small><hr>

<span id="prob_preview">
<?
if ($edit_uid != "new")
{
	$render_attributes = array(
		"uid" => $edit_uid,
		"inst" => "1",
		"prob" => "1",
		"sol" => "1",
		"type" => "1");

	echo "<table>";
	render_problem($render_attributes);
	echo "</table>";

	$q_prob = mysql_query("SELECT * FROM problems WHERE uid=" . $edit_uid);
	$a_prob = mysql_fetch_array($q_prob);
	$add_prob = $a_prob['prob'];
	$add_ans = $a_prob['answer'];
	$add_type = $a_prob['type'];
}
else
{
	echo "Type the LaTeX code for your problem in the boxes below, then click Preview.";
}

?>
</span>

<hr>

</td>
</tr>
<tr>
<td>
<span id="add_boxes">
	<form id="add_prob" name="add_prob">
	<table>
	<tr>
	<td>
	<p>Problem:<br><textarea rows="5" cols="35" id="prob_box" name="prob" onchange="javascript:boxes_changed()" onkeyup="javascript:boxes_changed()"><? echo $add_prob; ?></textarea></p>
	</td>
	<td>
	<p>Answer:<br><textarea rows="5" cols="35" id="answer_box" name="answer" onchange="javascript:boxes_changed()" onkeyup="javascript:boxes_changed()"><? echo $add_ans; ?></textarea></p>
	</td>
	</tr>
	<tr>
	<td colspan=2>
	<small><a href="javascript:switchMenu('p_format_notes')">Show formatting notes</a></small>
	</td>
	</tr>
	<tr>
	<td>
	<p>Type:<br>
<select name="type" id="type_box" onchange="javascript:boxes_changed()" onkeyup="javascript:boxes_changed()">
<? 
$a_types = type_list();
foreach ($a_types as $key => $value)
{
	if ($key == $add_type) { $sel = "selected"; } else { $sel = ""; }
	echo "<option $sel>$key</option>";
}
?>
</select>
</p>
	</td>
	</tr>
	</table>
	</form>
</span>
</td>
</tr>
<tr>
<td>
<hr>
<center>
<span id="add_controls">

<? if($edit_uid == "new") { $save_button = "hidden"; } else { $save_button = "button"; } ?>

<input type="button" id="add_preview" onclick="javascript:add_form_preview()" value="Preview" DISABLED>

<input type="<? echo $save_button; ?>" id="add_revert" onclick="javascript:add_form_revert(<? echo $edit_uid; ?>)" value="Revert" DISABLED>

<input type="button" id="add_copy" onclick="javascript:add_form_copy_to_cart()" value="Copy to Cart" DISABLED>


<input type="<? echo $save_button; ?>" id="add_save" onclick="javascript:add_form_save_to_db(<? echo $edit_uid; ?>)" value="Save to DB" DISABLED>

<input type=button id="add_add" onclick="javascript:add_form_add_to_db()" value="Add to DB" DISABLED>

<input type="<? echo $save_button; ?>" id="add_delete" onclick="javascript:add_form_delete_from_db(<? echo $edit_uid; ?>)" value="Delete from DB">

<p><small><a href="javascript:switchMenu('p_explain')">Explain these buttons</a></small></p>

</span>
</center>
<hr>
</td>
</tr>
<tr>
<td>
<p id="p_format_notes" style="display:none">Formatting notes: Type [[f]] for a random function name. Type [[IMAGE]] to include an image at that location.</p>

<p id="p_explain" style="display:none">
<b>You must preview your changes before any other action is taken!</b><br>
<? if ($edit_uid != "new") echo "\"Revert\" returns the problem to its original state.<br>"; ?>
"Copy to Cart" puts this problem in your cart, but does not alter the database at all. If you close your browser window, the problem will be lost.<br>
<? if ($edit_uid != "new") echo "\"Save to DB\" alters the problem in the database for everyone to see. Use this if you found an error in the problem.<br>"; ?>
"Add to DB" adds the problem to the database as a new problem<? if ($edit_uid != "new") echo ", leaving the original problem unaltered. Use this to add new problems using an existing problem as a template"?>.<br>
<? if ($edit_uid != "new") echo "\"Delete from DB\" deletes the problem from the database. This cannot be undone."; ?>
</td>
</tr>
</table>
