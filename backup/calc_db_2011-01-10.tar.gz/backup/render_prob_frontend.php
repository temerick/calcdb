<?
// this file executes render_prob based on POST input
// currently used as the preview update process for add_prob_form.php

include("connect.php");
include("functions.php");


echo "<table>";

if (isset($_POST['uid']))
{
	$rend['uid'] = $_POST['uid'];
} else {

	$rend['type_text'] = $_POST['type'];
	$rend['prob_text'] = $_POST['prob'];
	$rend['sol_text'] = $_POST['sol'];
}

render_problem($rend);

echo "</table>";

?>
