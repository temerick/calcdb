<?

// 01-05-2010: can this file be deleted? it doesn't seem to be used anywhere...

// sean@cittagazze:~/.dbmnt$ grep addTagConnections *
// sean@cittagazze:~/.dbmnt$ 


$nonexistent=array();
$n=0; // Number of elements in nonexistent.

foreach($arrayOfTags as $value) {
	$value=\strtolower(\trim($value));
	$id=mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE tag=\"".$value."\""));
	$tagid=$id{'uid'};
	//echo "value: ".$value."<br>id: ".$id{'uid'}."<br>UID: ".$UID;
	settype($tagid,"int"); 
	settype($UID,"int"); // They were strings before this.
	
	if($tagid!=0) { // Ensure that the tag actually exists.
		$sql="INSERT INTO probtags (probid, tagid) VALUES ('$UID','$tagid')";
	} else {
		$nonexistent[$n]=$value;
		$n=$n+1;
	}
	
	
//   	if (!mysql_query($sql,$dbhandle)) {
// 		die('Error: ' . mysql_error());
// 	}
}

if($n==0) {
	header('Location: ' . $_SERVER['HTTP_REFERER']);
} else {
	echo "The following tags do not currently exist in the database. Would you like to add them?<br><form action=\"createTags.php\" method=\"post\"><input type=\"hidden\" name=\"uid\" value=\"".$UID."\"><table>"; // need to carry through uid in case we need to add these tags later.
	foreach($nonexistent as $tag) {
		echo "<tr><td><input type=checkbox name=".$tag."></td><td>".$tag."</td></tr>";
	}
	echo "</table><input type=\"submit\" value=\"Tag 'em\"></form>";
}
?>
