<html>
<head>
<SCRIPT SRC="MathJax/MathJax.js"> 
  MathJax.Hub.Config({
    extensions: ["tex2jax.js"],
    jax: ["input/TeX","output/HTML-CSS"],
    tex2jax: {inlineMath: [["$","$"],["\\(","\\)"]]}
  });
</SCRIPT> 
</head>
<body>

<?php
include("connect.php");
?>

<?php
//execute the SQL query and return records
$FIELD=$_GET[col];
$VALUE=$_GET[value];

if ($VALUE=="all") {
	$QUERY="";
} else {
	$QUERY="WHERE $FIELD=\"$VALUE\"";
}
$result = mysql_query("SELECT * FROM problems $QUERY");
//print_r($result); this just proves the result is not a real array :(
//fetch tha data from the database
?>

<h2>All problems tagged "<? echo $VALUE; ?>"</h2>

<form action="decide.php" method="post">

<table>
<tr>
<td>Act</td><td width=300px>Problem</td><td>Answer</td><td>Type</td><td>Comment</td></tr>

<?
$COUNT=0;
while ($row = mysql_fetch_array($result)) {
echo "<tr><td><input type=checkbox name=".$row{'uid'}."></td>
<td>".$row{'prob'}." </td>
<td>".$row{'answer'}."</td>
<td> ".$row{'type'}." </td><td>".$row{'comment'}."</td>
<td><a href=\"modify.php?uid=".$row{'uid'}."&col=$FIELD&value=$VALUE\">Edit</a></td>
<td><a href=\"duplicate.php?uid=".$row{'uid'}."\">Dup</a></td>
</tr>\n\n";
$COUNT=$COUNT+1;
}
?>
</table>
<p><? echo $COUNT; ?> total records listed.</p>

<p>Add selected problems to your satchel <input type="submit" name="addcart" value="Bag 'em"></p>

<p>Generate LaTeX code for selected problems <input type="submit" name="latex" value="Break it down yall"></p>


<br><br><br>

<a href="index.php">Back to main page</a>

</body>
</html>
