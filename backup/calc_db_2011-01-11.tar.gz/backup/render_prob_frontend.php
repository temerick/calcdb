<?
// this file executes render_prob based on POST input
// currently used as the preview update process for add_prob_form.php

include("connect.php");
include("functions.php");

// render_problem assumes a table already exists, so here you go

echo "<table>";


// if a UID is posted, render that problem
// otherwise, render the "temporary problem" with the given attributes

if (isset($_POST['uid']))
{
	$rend['uid'] = $_POST['uid'];
} else {

	$rend['type_text'] = rawurldecode($_POST['type']);
	$rend['prob_text'] = rawurldecode($_POST['prob']);
	$rend['sol_text'] = rawurldecode($_POST['sol']);
}


// if this problem is in the preview pane, we need to disable links and things.
// this spaghetti is delicious

if ($_POST['preview']=="true") { $rend['preview'] = "1"; echo $rend['preview']; } else { $rend['preview'] = "0"; }

$rend['base_uid']=$_POST['baseuid'];

// THIS
// IS
// RENDER_PROBLEM

render_problem($rend);

echo "</table>";

?>
