<?
// include("connect.php");
// include("functions.php");
// 
// $query="SELECT MAX(uid) FROM problems";
//  
// $result = mysql_query($query) or die(mysql_error());
// 
// $row = mysql_fetch_array($result);
// echo "The biggest uid is " .$row['MAX(uid)'];
// echo "<br />";
// 	

$string="Hello appledumpling! apple apple appapplele";
$to_replace="apple";
$replace_with="World";
$start_position=strpos($string, $to_replace);
$i=0;
while($start_position!==false) {
	$string=substr_replace($string,$replace_with.$i,$start_position,strlen($to_replace));
	$start_position=strpos($string, $to_replace);
	$i++;
}
echo $string;

$pizza="one.two.three.four";
$file_suffix=substr($pizza,strrpos($pizza,"."));
echo "\nFile suffix: ".$file_suffix;
?>
