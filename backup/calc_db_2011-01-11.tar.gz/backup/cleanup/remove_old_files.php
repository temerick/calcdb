<? 

// function rrmdir($dir) { 
// 	if (is_dir($dir)) { 
// 		$objects = scandir($dir); 
// 		foreach ($objects as $object) { 
// 			
//        		if ($object != "." && $object != "..") { 
//          		if (filetype($dir."/".$object) == "dir") rrmdir($dir."/".$object); else unlink($dir."/".$object); 
//        		}
//  
//      	}
//  
// 		reset($objects); 
//      	return rmdir($dir); 
// 
//    	} else {
// 
// 		return false;
// 
// 	}
// } 


function rrmdir($str){
    if(is_file($str)){
        return @unlink($str);
    }
    elseif(is_dir($str)){
        $scan = glob(rtrim($str,'/').'/*');
        foreach($scan as $index=>$path){
            rrmdir($path);
        }
        return @rmdir($str);
    }
}



// this doesn't seem to be working at the moment. The goal is to have it remove files that are older than 1 day old.

$current_date=date('z',time());

$stuff_to_remove=array();
$age=array();

if ($handle = opendir('../latex/temp')) {

    /* This is the correct way to loop over the directory. */
    while (false !== ($file = readdir($handle))) {
		$file_creation_date=date('z',substr($file,32));
		$how_old=abs(($current_date-$file_creation_date)%365);
		if($how_old>1 && $file!="." && $file!="..") {
			
			$stuff_to_remove[]=(string) $file;
			$age[]=$how_old;
		}
    }
	
    closedir($handle);
	
	foreach($stuff_to_remove as $index => $file_name) {
		if(rrmdir("../latex/temp/".$file_name)) {
			echo "Successfully removed the file/folder ".$file_name.", which is ".$age[$index]." days old.<br />";
		} else {
			echo "<b>Failed</b> to remove the file/folder ".$file_name.", which is ".$age[$index]." days old.<br />";
		}
	}
}

?>