<?




// This block creates an array of problem instruction types
// in the form $a_types["type name"] = # of that type

function type_list()
{
	$a_types = array();
	$q_types = mysql_query("SELECT type FROM directions");
	while ($row = mysql_fetch_array($q_types)) {
		$trimtype = trim($row{'type'});
		if (!array_key_exists($trimtype, $a_types)) {
			$a_types[$trimtype]=0;
		}
	}
	
	$q_types = mysql_query("SELECT type FROM problems");
	while ($row = mysql_fetch_array($q_types)) {
		$trimtype = trim($row{'type'});
		$a_types[$trimtype] +=1;
	}
	//if (isset($a_types[""])) {
	//	$a_types["(no type)"] = $a_types[""];
	//	unset($a_types[""]);
	//}
	return $a_types;
}



// This block returns an array of tags
// in the form $a_tags["tag name"] = # of that tag

function tag_list()
{
	$a_tags = array();
	$q_tags = mysql_query("SELECT * FROM probtags");

	while ($row = mysql_fetch_array($q_tags)) {
		$specificTag = mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE uid=\"$row[tagid]\""));
		$trimTag=trim($specificTag[tag]);
		if (!array_key_exists($trimTag,$a_tags)) {
			$a_tags[$trimTag]=1;
		} else {
			$a_tags[$trimTag]+=1;
		}
	}
	ksort($a_tags);
	return $a_tags;
}





// This function is intended to render a single problem from the database.
// AS A ROW IN A PRE-EXISTING TABLE.
// To be used repeatedly in query.php and for previewing problems in add/edit/copy/delete/whatever dialogs
// The problem can be rendered with any of its components, depending on arguements passed.
// See below for the full list of possibilities (which are assumed false unless otherwise set to true).

// the $rend variable dictates what is shown
// the $a_prob variable is the problem content

// here's an example. attributes with 0 need not be specified, and not all the ones listed below are supported yet.
//
//	$rend = array(
//		"uid" => $edit_uid,
//		"b_updown" => "0",
//		"b_addrem" => "0",
//		"b_edit" => "0",
//		"ruid" => "0",
//		"inst" => "1",	if not specified, rendered by default
//		"prob" => "1",	if not specified, rendered by default
//		"sol" => "1",	if not specified, rendered by default
//		"type" => "1", 
//		"tags" => "0", 
//		"comment" => "0",
//		"color" => "0" );

function render_problem($rend)
{

	// determine whether or not we're doing a web preview
	if ($rend['preview']==1) {
		$rend_type=2;
	} else {
		$rend_type=0;
	}
	
	if(isset($rend['base_uid'])) {
		$uid=$rend['base_uid'];
	} else {
		$uid="";
	} // This will only prove to be of use later...

	// this is horribly unrobust... but should work at least for add_prob_form
	if (isset($rend['uid'])) {
		$a_prob = mysql_fetch_array(mysql_query("SELECT * FROM problems WHERE uid=" . $rend['uid']));
	} else {
		$a_prob['type'] = $rend['type_text']; // if no uid is given, $rend should pass in all the atributes that $a_prob should have
		$a_prob['prob'] = $rend['prob_text'];
		$a_prob['answer'] = $rend['sol_text'];
		unset($rend); // this makes my soul hurt
		$rend['uid'] = "";
	}
	
	
	switch ($rend['color']) {
		case 0: $color="FFFFFF"; break;
		case 1: $color="CCFFFF"; break;
		case 2: $color="FFB3B3"; break;
	} 


	echo "<tr bgcolor=" . $color . "><td>"; 

	// make an anchor if this is a problem with a real UID
	//if ($rend['uid']) echo "<a name=#".$rend['uid'].">".$rend['uid']."</a>";

	echo "<table><tr>";
	// cell containing up/down button
	if ($rend["b_updown"]) {
		echo "<td><center>";
		echo "<img border=0 src='img/up.png'>";
		echo "<p>";
		echo "<img border=0 src='img/down.png'>";
		echo "</center></td>";
	}

	// cell containing add/remove button
	echo "<td><center>"; 
	if ($rend["b_addrem"]) {
		echo "<p><span id=\"button" . $rend['uid'] . "\">";
		sensitive_button($rend['uid']); // sensitive_button function is below
		echo "</span>";
	}

	// edit button
	if ($rend["b_edit"]) echo "<p><a href='add_prob_form.php?uid=".$rend['uid']."' title='Edit problem number ".$rend['uid']."' onclick=\"return GB_showCenter('Edit problem', this.href,700,700,function () { prob_query('most_recent_change','');} )\"><img border=0 src='img/edit.png'></a>";

	echo "</center></td>";
	echo "</table>";

	
	
	echo "</td><td>";
	
	// cell containing the problem
	// in each of the next three, if the corresponding flag is not set, it will show it by default. this may or may not be desirable.

	// directions first
	if (!isset($rend["inst"]) || $rend["inst"]) { 
		$prob_instructions = mysql_fetch_array(mysql_query("SELECT directions FROM directions WHERE type=\"". trim($a_prob["type"]) . "\""));
		if ($prob_instructions['directions']) { // some problems don't have directions, so don't print the blank line
			echo $prob_instructions['directions'];
			echo "<br><br>"; }
	}
	
	// then the problem
	if (!isset($rend['prob']) || $rend['prob'])
		echo build_prob($rend['uid'],$a_prob['prob'],$rend_type);
		echo "<br><br>";

	// then the solution
	if (!isset($rend['sol']) || $rend['sol'])
		echo "Answer: " . build_prob($rend['uid'],$a_prob['answer'],$rend_type,"f","a");

	echo "</td><td>";

	// cell containing tags... all this code came from the old grabTabs.php

	if ($rend['tags']) {
		echo "<span id=\"".$rend['uid'].",tags\" class=\"editText\">".grab_tags($rend['uid'])."</span>";
	}

	echo "</td><td>";

	// cell containing ... modify/copy buttons?


	// finish off the row
	echo "</td></tr>";

}




function grab_tags($uid)
{
	$findConnections = mysql_query("SELECT tagid FROM probtags WHERE probid=".$uid);
	$tagList="";
	while($rowTwo=mysql_fetch_array($findConnections)) {
		$tag=mysql_fetch_array(mysql_query("SELECT tag FROM tags WHERE uid=".$rowTwo{'tagid'}));
		if($rowTwo{'tagid'}!=0) {
			$tagList=$tagList.", ".$tag{tag};
		}
	
	}
	$tagList=trim($tagList,","); // Throw away the extra comma at the end.
	return $tagList;
}


// This function renders a button to add/remove problem from cart, depending on whether or not the problem is already in the cart.

function sensitive_button($uid)
{

	if (in_array($uid,$_SESSION['mycart']))
		echo "<a href='javascript:add_to_cart(" . $uid. ")'><img border=0 src='img/rem.png'></a>";
	else
		echo "<a href='javascript:add_to_cart(" . $uid. ")'><img border=0 src='img/add.png'></a>";


}



// This function formats a string associated to a problem with uid=$uid. 
// The output will be for use either on the web ($format=0),
// in the tex source ($format=1) or in the web preview ($format=2). It will add the function name to the random function which,
// unless otherwise specified, is just "f". 
// The filename_prepend deals with images occuring in a string. When parsing, one may want to
// distinguish between problems and answers. (so we have one image for problems and another
// for answers.)

function build_prob($uid,$string,$format,$function_name="f",$filename_prepend="") {
	

	$to_replace=array();
	$replacements=array();
	
	// Web formatting array.
	if($format==0) { 
		
		// replacing functions
		$to_replace="[[f]]";
		$replacement=$function_name."(x)";
		$string=str_replace($to_replace,$replacement,$string);
		
		$to_replace="[[IMAGE]]";
		$start_position=strpos($string, $to_replace);
		$i=0;
		while($start_position!==false) {
			$file_path="problem_images/".$filename_prepend.$uid."-".$i;
			if(file_exists($file_path.".png")) { // Checking for png.
				$replace_with="<p><a href=\"".$file_path.".png\" onclick=\"return GB_showImage('Problem ".$uid."', this.href)\"><img width=50 border=2 src=\"".$file_path.".png\" alt=\"Image not found.\"></a></p>"; 
			} else if (file_exists($file_path.".jpg")) { // Checking for jpg.
				$replace_with="<p><a href=\"".$file_path.".jpg\" onclick=\"return GB_showImage('Problem ".$uid."', this.href)\"><img width=50 border=2 src=\"".$file_path.".jpg\" alt=\"Image not found.\"></a></p>"; 
			} else {
				$replace_with="<p><a href=\"image_upload.php?filename=".$filename_prepend.$uid."-".$i."\" onclick=\"return GB_showCenter('Upload Image', this.href,150,350,function () { prob_query('last_query','');})\">Add Image</a></p>";
			}
			$string=substr_replace($string,$replace_with,$start_position,strlen($to_replace));
			$start_position=strpos($string, $to_replace);
			$i++;
		}	
	}
	
	// LaTeX formatting array.
	if($format==1) { 
		
		// replacing functions
		$to_replace="[[f]]";
		$replacement=$function_name."(x)";
		$string=str_replace($to_replace,$replacement,$string);
		
		$to_replace="[[IMAGE]]";
		$start_position=strpos($string, $to_replace);
		$i=0;
		while($start_position!==false) {
			$replace_with="\\includegraphics(images/".$uid."-".$i.".png)";
			$string=substr_replace($string,$replace_with,$start_position,strlen($to_replace));
			$start_position=strpos($string, $to_replace);
			$i++;
		}
		
		// replacing images (assuming there are less than 10)
		// for($i=0;$i<10;$i++) {
		// 	$to_replace[]="[[IMAGE]]";
		// 	$replacements[]="\\includegraphics(images/".$uid."-".$i.".png)";
		// }	
		
	}
	
	// Web preview formatting array.
	if($format==2) { 
		
		// replacing functions
		$to_replace="[[f]]";
		$replacement=$function_name."(x)";
		$string=str_replace($to_replace,$replacement,$string);
		
		$to_replace="[[IMAGE]]";
		$start_position=strpos($string, $to_replace);
		$i=0;
		while($start_position!==false) {
			$file_path="problem_images/".$filename_prepend.$uid."-".$i;
			if(file_exists($file_path.".png")) { // Checking for png.
				$replace_with="<p><img width=50 border=2 src=\"".$file_path.".png\" alt=\"Image not found.\"></p>"; 
			} else if (file_exists($file_path.".jpg")) { // Checking for jpg.
				$replace_with="<p><img width=50 border=2 src=\"".$file_path.".jpg\" alt=\"Image not found.\"></p>"; 
			} else {
				$replace_with="<p>Add Image</p>";
			}
			$string=substr_replace($string,$replace_with,$start_position,strlen($to_replace));
			$start_position=strpos($string, $to_replace);
			$i++;
		}
			
	}
	
	// Returning the result.
	return $string;
	
}



function replace_all($string,$to_replace,$replace_with) {
	$start_position=strpos($string, $to_replace);
	$i=0;
	while($start_position!==false) {
		$string=substr_replace($string,$replace_with.$i,$start_position,strlen($to_replace));
		$start_position=strpos($string, $to_replace);
		$i++;
	}
	return $string;
}



// This function takes in a .csv formatted string, and returns the appropriate array.
if (!function_exists('str_getcsv')) { 
    function str_getcsv($input, $delimiter = ',', $enclosure = '"', $escape = '\\', $eol = '\n') { 
        if (is_string($input) && !empty($input)) { 
            $output = array(); 
            $tmp    = preg_split("/".$eol."/",$input); 
            if (is_array($tmp) && !empty($tmp)) { 
                while (list($line_num, $line) = each($tmp)) { 
                    if (preg_match("/".$escape.$enclosure."/",$line)) { 
                        while ($strlen = strlen($line)) { 
                            $pos_delimiter       = strpos($line,$delimiter); 
                            $pos_enclosure_start = strpos($line,$enclosure); 
                            if ( 
                                is_int($pos_delimiter) && is_int($pos_enclosure_start) 
                                && ($pos_enclosure_start < $pos_delimiter) 
                                ) { 
                                $enclosed_str = substr($line,1); 
                                $pos_enclosure_end = strpos($enclosed_str,$enclosure); 
                                $enclosed_str = substr($enclosed_str,0,$pos_enclosure_end); 
                                $output[$line_num][] = $enclosed_str; 
                                $offset = $pos_enclosure_end+3; 
                            } else { 
                                if (empty($pos_delimiter) && empty($pos_enclosure_start)) { 
                                    $output[$line_num][] = substr($line,0); 
                                    $offset = strlen($line); 
                                } else { 
                                    $output[$line_num][] = substr($line,0,$pos_delimiter); 
                                    $offset = ( 
                                                !empty($pos_enclosure_start) 
                                                && ($pos_enclosure_start < $pos_delimiter) 
                                                ) 
                                                ?$pos_enclosure_start 
                                                :$pos_delimiter+1; 
                                } 
                            } 
                            $line = substr($line,$offset); 
                        } 
                    } else { 
                        $line = preg_split("/".$delimiter."/",$line); 
    
                        /* 
                         * Validating against pesky extra line breaks creating false rows. 
                         */ 
                        if (is_array($line) && !empty($line[0])) { 
                            $output[$line_num] = $line; 
                        }  
                    } 
                } 
                return $output; 
            } else { 
                return false; 
            } 
        } else { 
            return false; 
        } 
    } 
}






?>
