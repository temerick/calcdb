<?
// INSERTS a problem in the database based on POST input. currently called from add_prob_java.js
// returns a success message

include("connect.php");

$update_uid = addslashes($_POST['uid']);
$update_type = addslashes($_POST['type']);
$update_prob = addslashes($_POST['prob']);
$update_answer = addslashes($_POST['sol']);
$base_uid = $_POST['base_uid']; // the uid of the problem that was getting edited (or "new")

$sql="INSERT INTO problems (prob,answer,type) VALUES (\"$update_prob\", \"$update_answer\", \"$update_type\");";

if (!mysql_query($sql,$dbhandle)) {
  die('Error: ' . mysql_error());
} else {
	echo "<h3>Problem created in database as UID ".mysql_insert_id().".</h3><p><input type=button value=\"Close Window\" onclick=\"parent.parent.GB_hide();\">";
	$_SESSION['last_action'] = "insert";
	$_SESSION['last_modified_uid'] = mysql_insert_id();
	$_SESSION['last_modified_type'] = stripslashes($update_type);
}

mysql_close($dbhandle);

?>
