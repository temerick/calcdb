// function to call when the text boxes change
function boxes_changed()
{
	document.getElementById("add_preview").disabled = false;
	document.getElementById("add_revert").disabled = false;
	document.getElementById("add_copy").disabled = true;
	document.getElementById("add_save").disabled = true;
	document.getElementById("add_add").disabled = true;
	document.getElementById("add_delete").disabled = true;
}


// function to call when the preview button is hit
function previewed()
{
	document.getElementById("add_preview").disabled = true;
	document.getElementById("add_copy").disabled = false;
	document.getElementById("add_save").disabled = false;
	document.getElementById("add_add").disabled = false;
}


// function called after revert button is hit.
function reverted()
{
	document.getElementById("add_preview").disabled = true;
	document.getElementById("add_revert").disabled = true;
	document.getElementById("add_copy").disabled = true;
	document.getElementById("add_save").disabled = true;
	document.getElementById("add_add").disabled = true;
	document.getElementById("add_delete").disabled = false;
}


function disable_everything()
{
	// just in case i need it later; this is called after Add, Save and Delete buttons are hit.
	//switchMenu("add_boxes"); // not the best solution, but whatever.
	document.getElementById("prob_box").disabled = true;
	document.getElementById("answer_box").disabled = true;
	document.getElementById("type_box").disabled = true;
}







// function to update the preview pane of the add problem form

function add_form_preview(uid)
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("prob_preview").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"prob_preview"]); // re-renders page with MathJax
			previewed();
		}
	}

	params=
		"baseuid="+uid
		+"&type="+encodeURIComponent(document.add_prob.type.value)
		+"&prob="+encodeURIComponent(document.add_prob.prob.value)
		+"&sol="+encodeURIComponent(document.add_prob.answer.value)
		+"&preview=true";
	xmlhttp.open("POST","render_prob_frontend.php", true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length", params.length);
	xmlhttp.setRequestHeader("Connection", "close");
	xmlhttp.send(params);
}


// function to revert the preview pane of the add problem form.... this will not change the text boxes back yet though :(

function add_form_revert(uid)
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("prob_preview").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"prob_preview"]); // re-renders page with MathJax
			reverted();
		}
	}

	params="uid="+uid;
	xmlhttp.open("POST","render_prob_frontend.php", true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length", params.length);
	xmlhttp.setRequestHeader("Connection", "close");

	xmlhttp.send(params);

}












// function to UPDATE a problem in the database

function add_form_save_to_db(uid)
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("add_controls").innerHTML=xmlhttp.responseText;

			disable_everything();
		}
	}

	params=
		"uid="+uid
		+"&type="+encodeURIComponent(document.add_prob.type.value)
		+"&prob="+encodeURIComponent(document.add_prob.prob.value)
		+"&sol="+encodeURIComponent(document.add_prob.answer.value);
	xmlhttp.open("POST","database_update.php", true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length", params.length);
	xmlhttp.setRequestHeader("Connection", "close");
	xmlhttp.send(params);
}



// function to ADD a problem in the database

function add_form_add_to_db(uid)
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("add_controls").innerHTML=xmlhttp.responseText;

			disable_everything();
		}
	}
	
	params=
		"baseuid="+uid
		+"&type="+encodeURIComponent(document.add_prob.type.value)
		+"&prob="+encodeURIComponent(document.add_prob.prob.value)
		+"&sol="+encodeURIComponent(document.add_prob.answer.value);
	xmlhttp.open("POST","database_insert.php", true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length", params.length);
	xmlhttp.setRequestHeader("Connection", "close");
	xmlhttp.send(params);
}


// function to DELETE a problem in the database

function add_form_delete_from_db(uid)
{
	ans=confirm("This will PERMANENTLY DELETE this problem from the database. Are you sure?");
	if (ans) {
		xmlhttp=new XMLHttpRequest();

		xmlhttp.onreadystatechange=function() { 
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				document.getElementById("add_controls").innerHTML=xmlhttp.responseText;

				disable_everything();
			}
		}

		params="uid="+uid;
		xmlhttp.open("POST","database_delete.php", true);
		xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttp.setRequestHeader("Content-length", params.length);
		xmlhttp.setRequestHeader("Connection", "close");
		xmlhttp.send(params);
	}
}

