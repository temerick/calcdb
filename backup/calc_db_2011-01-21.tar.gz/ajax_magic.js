// function to display a query result in the content frame
// inputs are q_type (should be "tags" or "type") and q_value (the query)

function prob_query(q_type, q_value)
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"d_query"]); // re-renders page with MathJax
			editbox_init(); // re-initialize instantedit; needs to be done on every query.
		}
	}

	// this stuff should probably be run through URIencode   +"&highlight="+highlight
	xmlhttp.open("GET","query.php?col="+q_type+"&value="+q_value,true); 
	xmlhttp.send();
	document.getElementById("d_query").innerHTML="Reticulating splines...";
}

// This will be called from the search box. Currently, it only handles a single uid input, or a tag input.
function search_query(item) 
{
	
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"d_query"]); // re-renders page with MathJax
		}
	}
	
	if(!isNaN(parseInt(item))) {
		// If we have a number...
		xmlhttp.open("GET","query_uids.php?uids="+item); 
		xmlhttp.send();
		document.getElementById("d_query").innerHTML="Reticulating splines...";
	} else {
		// If we have a tag...
		xmlhttp.open("GET","query_tags.php?tags="+item); 
		xmlhttp.send();
		document.getElementById("d_query").innerHTML="Reticulating splines...";
	}
	
}


// query_tags ... new version of prob_query

function query_tags(taglist)
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"d_query"]); // re-renders page with MathJax
		}
	}
	
	xmlhttp.open("GET","query_tags.php?tags="+taglist); 
	xmlhttp.send();
	document.getElementById("d_query").innerHTML="Reticulating splines...";
}

// query_uids ... new version of prob_query

function query_uids(uidlist)
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"d_query"]); // re-renders page with MathJax
		}
	}
	
	xmlhttp.open("GET","query_uids.php?uids="+uidlist); 
	xmlhttp.send();
	document.getElementById("d_query").innerHTML="Reticulating splines...";
}


function query_cart()
{

}

function query_all()
{

}



// function to add a problem to the cart by uid

function add_to_cart(uid)
{
	xmlhttp_add=new XMLHttpRequest();

	xmlhttp_add.onreadystatechange=function() { 
		if (xmlhttp_add.readyState==4 && xmlhttp_add.status==200) {
			document.getElementById("button"+uid).innerHTML=xmlhttp_add.responseText;
			update_cart_count();
		}
	}

	xmlhttp_add.open("GET","addtocart.php?uid="+uid, true);
	xmlhttp_add.send();
	document.getElementById("button"+uid).innerHTML="<img src='img/ajax-loader.gif'>"
}


// function to update the cart count

function update_cart_count()
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("cartcount").innerHTML=xmlhttp.responseText;
		}
	}

	xmlhttp.open("GET","print_cart_count.php", true);
	xmlhttp.send();
}



// function to toggle solution display

function toggle_sol_disp()
{
	xmlhttp_sol=new XMLHttpRequest();

	xmlhttp_sol.onreadystatechange=function() { 
		if (xmlhttp_sol.readyState==4 && xmlhttp_sol.status==200) {
			document.getElementById("sol_disp").innerHTML=xmlhttp_sol.responseText;
			prob_query("last_query","");
		}
	}

	xmlhttp_sol.open("GET","print_sol_disp_pref.php?toggle=true", true);
	xmlhttp_sol.send();
}



// function to tag solution display

function toggle_tag_disp()
{
	xmlhttp_sol=new XMLHttpRequest();

	xmlhttp_sol.onreadystatechange=function() { 
		if (xmlhttp_sol.readyState==4 && xmlhttp_sol.status==200) {
			document.getElementById("tag_disp").innerHTML=xmlhttp_sol.responseText;
			prob_query("last_query","");
		}
	}

	xmlhttp_sol.open("GET","print_tag_disp_pref.php?toggle=true", true);
	xmlhttp_sol.send();
}


// show the help out page

function help_out()
{
	xmlhttp_add=new XMLHttpRequest();

	xmlhttp_add.onreadystatechange=function() { 
		if (xmlhttp_add.readyState==4 && xmlhttp_add.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp_add.responseText;
		}
	}

	xmlhttp_add.open("GET","help_out.php", true);
	xmlhttp_add.send();
}


// show the user info page

function user_info()
{
	xmlhttp_add=new XMLHttpRequest();

	xmlhttp_add.onreadystatechange=function() { 
		if (xmlhttp_add.readyState==4 && xmlhttp_add.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp_add.responseText;
		}
	}

	xmlhttp_add.open("GET","user_info.php", true);
	xmlhttp_add.send();
}


function save_new_pw()
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
		}
	}

	params=
		"oldpw="+encodeURIComponent(document.edit_pw.oldpw.value)
		+"&newpw1="+encodeURIComponent(document.edit_pw.newpw1.value)
		+"&newpw2="+encodeURIComponent(document.edit_pw.newpw2.value);
	xmlhttp.open("POST","user_info.php", true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length", params.length);
	xmlhttp.setRequestHeader("Connection", "close");
	xmlhttp.send(params);
}


// play tag game!

function play_tag_game()
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"d_query"]); // re-renders page with MathJax
			editbox_init(); // re-initialize instantedit; needs to be done on every query.
		}
	}

	// this stuff should probably be run through URIencode   +"&highlight="+highlight
	xmlhttp.open("GET","tag_game.php",true); 
	xmlhttp.send();
	document.getElementById("d_query").innerHTML="Reticulating splines...";
}
