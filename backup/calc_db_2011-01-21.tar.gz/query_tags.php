
<?
include("connect.php");
include("functions.php");

// get the list of tags
$tags = explode(",",$_GET['tags']);

// sort through the various operators
foreach ($tags as $curtag)
{
	if (substr_count($curtag,"type:"))		// restrict to a particular type
	{
		echo "restricting to type ". str_replace("type:","",$curtag)."<br>";
		$type_restrict = str_replace("type:","",$curtag);
	} 
	elseif (substr_count($curtag,"not:"))	// remove tags with not: operator
	{
		echo "not including problems tagged ". str_replace("not:","",$curtag)."<br>";
		$tag_exclude[] = str_replace("not:","",$curtag);
	}
	else							// otherwise, search for problems with that tag
	{
		echo "including problems tagged $curtag<br>";
		$tag_include[] = $curtag;
	}
}

print_r($tag_include);
echo "<br>";
print_r($tag_exclude);


?>
