<?
// this form is to add a new type. it will appear in a span in add_prob_form when the "New" type option is selected.

include("connect.php");
include("functions.php");

if ($_POST['typename'])
{
	$converted_type = ereg_replace("[^A-Za-z0-9[:space:]_-]", "", $_POST['typename']);  //strip all special characters except dash
	
	if (!$converted_type || print_directions($converted_type)) // if true, the type name already exists or is empty
	{
		echo "That type name already exists or has a problem with it! Use a different one (no special characters allowed).<br><br>";
		unset($_POST['typename']); // so that the form prints again below.
	} else {
		// quotation marks are killing us. replace them with double '.
		$directions=str_replace('"',"''",$_POST['directions']);
		$directions = addslashes($directions);

		$sql="INSERT INTO directions (type,directions,boolean) VALUES (\"$converted_type\", \"$directions\", \"0\");";
		if (!mysql_query($sql,$dbhandle)) {
			die('Error: ' . mysql_error());
		} else {
			echo "Directions created!<br><input type=\"button\" onclick=\"javascript:type_created('$converted_type','$directions');\" value=\"Back to problem\">";
		}
	}
} 

if (!$_POST['typename'])
{
	//if (!isset($converted_type)) $converted_type="";
	//if (!isset($_POST['directions_text'])) $_POST['directions_text']="";

	echo "<form name=\"add_type\">";
	echo "<p>Type name:<br>";
	echo "<input type=\"text\" name=\"type_name\" value=\"$converted_type\">";

	echo "<p>Directions for this type:<br>";
	echo "<textarea rows=\"2\" cols=\"35\" name=\"directions_text\">".$_POST['directions']."</textarea>";

	echo "<p><input type=\"button\" onclick=\"javascript:create_type();\" value=\"Create\">";
	echo "<input type=\"button\" onclick=\"javascript:cancel_create_type();\" value=\"Cancel\">";
}

?>

