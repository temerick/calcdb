<?
if (isset($_SESSION['mycart']) && sizeof($_SESSION['mycart']) > 0)
{
	echo "your cart already exists!";
} else {
	$uid_list = $_GET['restore_cart'];
	$_SESSION['mycart'] = explode(",",$uid_list);
	echo "<center>Restored UID list $uid_list to cart.<br><br><a href=\"javascript:prob_query('cart','')\">View your cart</a>";
}

?>
