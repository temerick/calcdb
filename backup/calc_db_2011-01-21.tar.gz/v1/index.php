<html>
<title>Calculus Problem Database</title>
<head>
<SCRIPT SRC="MathJax/MathJax.js"> 
  MathJax.Hub.Config({
    extensions: ["tex2jax.js"],
    jax: ["input/TeX","output/HTML-CSS"],
    tex2jax: {inlineMath: [["$","$"],["\\(","\\)"]]}
  });
</SCRIPT> 
</head>
<body>

<?php
include("connect.php");
?>

<? // create a list of types (should be tags later, I guess)
$result = mysql_query("SELECT * FROM problems");
$types = array();
while ($row = mysql_fetch_array($result)) {
	$trimtype=trim($row{'type'}); // stupid tim's shoddy database work oh crap he's right behind me
	if (!array_key_exists($trimtype,$types)) {
		$types[$trimtype]=1;
	} else {
		$types[$trimtype]+=1; }
	}
$result = mysql_query("SELECT * FROM tags");
$tags = array();
while ($row = mysql_fetch_array($result)) {
	$tags[$row{'uid'}]=trim($row{'tag'}); }

//print_r($tags);

?>

<h1>Calculus Problem Database</h1>

<h3>List problems by type</h3>
<table>
<tr><td width="300px" valign=top>
<table>
<? // tag list

$result = mysql_query("SELECT * FROM probtags");
$tags = array();
while ($row = mysql_fetch_array($result)) {
	// echo "row: ".print_r($row)."<br>";
	$specificTag = mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE uid=\"$row[tagid]\""));
	// echo "ST: ".$specificTag."<br>";
	$trimTag=trim($specificTag[tag]);
	if (!array_key_exists($trimTag,$tags)) {
		$tags[$trimTag]=1;
	} else {
		$tags[$trimTag]+=1;
	}
}


foreach($tags as $key => $value) {
echo "<tr><td><a href=\"query.php?col=tags&value=$key\">$key</a></td><td>$value</td></tr>";
} 
?>
</table>
</td>
<td valign=top>
<? // tag list 
// foreach($tags as $key => $value) {
// echo "<a href=\"query.php?col=tag&value=$key\">$value</a><br>"; } 
?>
</td>
<td valign=top>
<h3>SWEET ASS TAG CLOUD</h3>
<p style="max-width:200px;">
<?
include("tagcloud.php");
printTagCloud($tags);
?>
</p>
</td></tr></table>

<h3><a href="query.php?col=type&value=all">List all problems</a></h3>

<br>

<h3><a href="viewcart.php">See your bag o' problems</a> (<? echo count($_SESSION['mycart']); ?> problems)</h3>

<br><br><br>

<p>Add a problem, using full LaTeX markup:</p>

<form action="insert.php" method="post">
<? 
$add_prob="";
$add_ans="";
$add_type="";
$add_comment="";
include("add_prob_form.php"); 
?>
<input type="submit">
</form>

<br><br><br>

<h3>Debugging crap</h3>
<p><a href="debug_viewsession.php">View current $SESSION</a>
<p><a href="debug_destroysession.php">Destroy current $SESSION</a>

</body>
</html>
