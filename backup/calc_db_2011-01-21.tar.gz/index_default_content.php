<center>
<?
if($subheadertext!="") echo "<table cellspacing='0' cellpadding='0'>
	<tr><td bgcolor='CCFFFF'><h3>".$subheadertext."</h3></td></tr></table>";
?>
<h2>Welcome to Calc DB. Select a search criterion.</h2><? if($_COOKIE['username']=="tre8a" || $_COOKIE['username']=="svd5d") { include("search_box.php"); } ?>

<p><font size=+1 color=red>Warning:</font> This site is edited live on the server. Anything may explode at any time.

<p><font size=+1 color=red>Firefox:</font> Some versions of Firefox seem to render math extremely slowly. Try using <a href="http://www.google.com/chrome">Google Chrome</a> instead.

<p>&nbsp;
</center>

<center>
<h3>Tags</h3>
<? print_tag_cloud($a_tags,"tags"); ?></center>

<p><p>

<center>
<h3>Types</h3>
<? print_tag_cloud($a_types,"type"); ?></center>


