<?

include("cookie_check.php");

// This will be used to convey context-relevant subheaders on the main page. e.g. "Your email has been sent successfully".
$subtxt=$_GET['subtxt'];
$subheadertext=""; // set to empty by default.
switch($subtxt) {
	
	case "texEmail":
		$subheadertext="Your email has been sent successfully. You should receive it shortly.";
		break;
}

?>

<html>
<head>
<title>Calculus Problem Database</title>

<script type="text/javascript"> var GB_ROOT_DIR = "./greybox/"; </script>
<script type="text/javascript" src="greybox/AJS.js"></script>
<script type="text/javascript" src="greybox/AJS_fx.js"></script>
<script type="text/javascript" src="greybox/gb_scripts.js"></script>
<link href="greybox/gb_styles.css" rel="stylesheet" type="text/css" media="all" />
<script src="toggle.js" type="text/javascript"></script>
<script src="ajax_magic.js" type="text/javascript"></script>
<SCRIPT SRC="MathJax/MathJax.js"> 
  MathJax.Hub.Config({
    extensions: ["tex2jax.js"],
    jax: ["input/TeX","output/HTML-CSS"],
    tex2jax: {inlineMath: [["$","$"],["\\(","\\)"]]}
  });
</SCRIPT> 
<script type="text/javascript" src="instantedit.js"></script>

</head>
<body>



<?php
include("connect.php");
include("functions.php");

$a_types = type_list();
$a_tags = tag_list();

?>



<table width=100%>
<tr>
<td width=190 valign=top>
<center><a href="index.php"><img border=0 src="img/logo.png"></a></center>


<h3><a href="javascript:prob_query('cart','')">Cart</a> (<span id="cartcount"><? include("print_cart_count.php"); ?></span>)</h3>



<h3><a href="javascript:switchMenu('tag_list')">Tag List</a></h3>
<div id="tag_list" style="display:none">
<? foreach($a_tags as $key => $value) { echo "<a href=\"javascript:prob_query('tags','$key')\">$key</a> ($value)<br>"; } ?><br>
</div>



<h3><a href="javascript:switchMenu('type_list')">Type List</a></h3>
<div id="type_list" style="display:none">
<? foreach($a_types as $key => $value) { echo "<a href=\"javascript:prob_query('tags','type:$key')\">$key</a> ($value)<br>"; } ?><br>
</div>


<h3><a href="javascript:prob_query('all','')">All Probs</a></h3>

<h3><img src="img/add.jpg" width=15> <a href="add_prob_form.php" title="Add problem" onclick="return GB_showCenter('Add problem', this.href,550,700,function () { prob_query('most_recent_change','');})">Add Prob</a></h3>

<p>Solutions: <span id="sol_disp"><? include("print_sol_disp_pref.php"); ?></span>
<br>Tags: <span id="tag_disp"><? include("print_tag_disp_pref.php"); ?></span>



<h3><a href="javascript:help_out()">Help Out!</a></h3>

<br><br><br>
<font size=-2>
<p><a href="javascript:prob_query('tags','type:testing')">Testing Probs</a></p>
<p><a href="javascript:query_uids('247,231,216,78')">query uid test</a></p>
<p><a href="javascript:query_tags('series,type:series-con-div,not:ratio test')">query tag test</a></p>
<p><a href="debug_viewsession.php">View $SESSION</a>
<br><a href="debug_destroysession.php">Destroy $SESSION</a>
<p>Logged in as <b><? echo $_COOKIE['username']; ?></b>
<br /><a href="javascript:user_info()">Edit</a> password.
<br /><a href="login.php?do=drop">Login</a> as another user.</p>
</font>

<font size=-1>
<p><a href="mailto:tre8a@virginia.edu">Email</a> the admins with problems or feature requests.</p>
</font>


</td>
<td valign=top>
<span id="d_query">


<? // select the content that goes here, based on GET

if ($_GET['restore_cart'])
{
	include("index_restore_cart.php");
} else {
	include("index_default_content.php");
}


?>





</span> <? // end d_query span ?>
</td>
</tr>
</table>
