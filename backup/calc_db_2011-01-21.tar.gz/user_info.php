<form id="edit_pw" name="edit_pw">
<?

include("connect.php");

if(array_key_exists('oldpw',$_POST)) {
	
	$oldPW=rawurldecode($_POST['oldpw']);
	$newPW1=rawurldecode($_POST['newpw1']);
	$newPW2=rawurldecode($_POST['newpw2']);
	
	$username=$_COOKIE['username'];
	
	/* grab appropriate user from the database. */
	$user_info=mysql_fetch_array(mysql_query("SELECT * FROM user_data WHERE username=\"$username\""));
	$password=$user_info['password'];
	
	/* check to make sure that the old password is correct. */
	
	if(md5($oldPW)==$password) {
		
		/* check to make sure that the two new passwords match */
		if($newPW1==$newPW2) {
			$md5_pw=md5($newPW1);
			mysql_query("UPDATE user_data SET password=\"$md5_pw\" WHERE username=\"$username\"");
			
			/* reset cookies */
			setcookie("username",$username,time()+60*60*24*30*3);
			setcookie("password",md5($md5_pw),time()+60*60*24*30*3);
			$error_text="Your password has been successfully updated.";
			
		} else {
			$error_text="<font color='red'>The two copies of the new password you entered don't match.</font>";
		}
	} else {
		$error_text="<font color='red'>The old password you entered was incorrect.</font>";
	}
	
}


?>
<script src="ajax_magic.js" type="text/javascript"></script>

<center><h3>Change password for <? echo $_COOKIE['username']; ?></h3>
<? echo $error_text; ?>

<table>
	<tr>
		<td><b>Old Password:</b></td>
		<td><input type="password" name="oldpw"></td>
	</tr>
	<tr>
		<td><b>New Password:</b></td>
		<td><input type="password" name="newpw1"></td>
	</tr>
	<tr>
		<td><b>Re-Enter New Password:</b></td>
		<td><input type="password" name="newpw2"></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="button" id="save_pw" value="Save Changes" onclick="javascript:save_new_pw()"></td>
	</tr>
</table>
</form>
</center>