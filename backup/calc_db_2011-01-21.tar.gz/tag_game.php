<?
include("connect.php");
include("functions.php");

$q_random_uids = mysql_query("SELECT uid,type FROM problems ORDER BY RAND() LIMIT 3");
while ($row = mysql_fetch_array($q_random_uids)) {
	$result[$row{'uid'}] = $row{'type'};
}

?>

<h3>Tag game!</h3>

<p>Add any tags the following problems might be missing!</p>

<table width=100% cellpadding="10" cellspacing="0" border=0>
<tr>

<?
if (sizeof($result)>0)
{
	$COUNT=0;

	$last_type_rendered = "";

	foreach ($result as $UID => $prob_type) {
	
		if ($prob_type != $last_type_rendered) { // block determining if a new type set is starting
			$prob_instructions = mysql_fetch_array(mysql_query("SELECT directions FROM directions WHERE type=\"". $prob_type . "\""));
			echo "<tr bgcolor=white><td></td></tr><tr bgcolor=lightblue><td valign=center colspan=6><h4>".$prob_instructions['directions']."</h4></td></tr>";
			$last_type_rendered = $prob_type;
		}
	
		// To bounce between colors for rows
		$color=($COUNT +1)%2;
		if ($_GET['highlight'] == $UID) { $color = "2"; }

		$render_attributes = array(
			"uid" => "$UID",
			"b_updown" => "0",
			"b_addrem" => "1",
			"b_edit" => "1",
			"inst" => "0",
			"prob" => "1",
			"sol" => "1",
			"tags" => "1", 
			"color" => $color );

		render_problem($render_attributes);

		$COUNT+=1;

	}
} else { // query returned nothing, say so.
	echo "<td>Nothing found!</td>";
}

?>



</table>

<center><h2><a href="javascript:play_tag_game();">Play Again</a>!</h2></center>
