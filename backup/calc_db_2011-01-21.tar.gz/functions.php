<?

// Note: When the database moves to a new home, we must change the $urlbase variable in the build_tex function below!


// This function completely removes all trace of a problem from the system.
// The problem is removed from the database, all of it's tags are removed, and 
// all associated images are removed. USE WITH CAUTION!!!!!
function purge($uid) {
	
	// First remove the problem.
	mysql_query("DELETE FROM problems WHERE uid=$uid");
	
	// Then remove all associated tags.
	mysql_query("DELETE FROM probtags WHERE probid=$uid");
	
	// Then remove all associated images.
	$i=0;
		
		// images associated to the problem.
		while(file_exists("problem_images/".$uid."-".$i.".jpg")) {
//			echo "Removing the file problem_images/".$uid."-".$i.".jpg<br />";
			echo exec("rm problem_images/".$uid."-".$i.".jpg");
			$i++;
		}
	
	$i=0;
	
		// images associated to the solution.
		while(file_exists("problem_images/a".$uid."-".$i.".jpg")) {
//			echo "Removing the file problem_images/a".$uid."-".$i.".jpg<br />";
			echo exec("rm problem_images/a".$uid."-".$i.".jpg");
			$i++;
		}

	// if the problem is in the cart, remove it as well
	$uid_in_cart = array_search($uid,$_SESSION['mycart']);
	if ($uid_in_cart) {
		unset($_SESSION['mycart'][$uid_in_cart]);
	}
}


// This block creates an array of problem instruction types
// in the form $a_types["type name"] = # of that type

function type_list($array_of_uids="all")
{
	$a_types = array();
	$q_types = mysql_query("SELECT type FROM directions");
	while ($row = mysql_fetch_array($q_types)) {
		$trimtype = trim($row{'type'});
		if (!array_key_exists($trimtype, $a_types)) {
			$a_types[$trimtype]=0;
		}
	}
	
	if($array_of_uids=="all") {
		$end_of_query="";
	} else {
		$end_of_query=" WHERE ";
		foreach($array_of_uids as $key) { // Creating the query.
			$end_of_query=$end_of_query."uid='".$key."' OR ";
		}
		$end_of_query=substr($end_of_query,0,-3);
	}
	
	
	
	$q_types = mysql_query("SELECT type FROM problems".$end_of_query);
	while ($row = mysql_fetch_array($q_types)) {
		$trimtype = trim($row{'type'});
		$a_types[$trimtype] +=1;
	}
	
	ksort($a_types);
	return $a_types;
}



// This block returns an array of tags
// in the form $a_tags["tag name"] = # of that tag

function tag_list()
{
	$a_tags = array();
	$q_tags = mysql_query("SELECT * FROM probtags");

	while ($row = mysql_fetch_array($q_tags)) {
		$specificTag = mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE uid=\"$row[tagid]\""));
		$trimTag=trim($specificTag[tag]);
		if (!array_key_exists($trimTag,$a_tags)) {
			$a_tags[$trimTag]=1;
		} else {
			$a_tags[$trimTag]+=1;
		}
	}
	ksort($a_tags);
	return $a_tags;
}





// This function is intended to render a single problem from the database.
// AS A ROW IN A PRE-EXISTING TABLE.
// To be used repeatedly in query.php and for previewing problems in add/edit/copy/delete/whatever dialogs
// The problem can be rendered with any of its components, depending on arguements passed.
// See below for the full list of possibilities (which are assumed false unless otherwise set to true).

// the $rend variable dictates what is shown
// the $a_prob variable is the problem content

// here's an example. attributes with 0 need not be specified, and not all the ones listed below are supported yet.
//
//	$rend = array(
//		"uid" => $edit_uid,
//		"b_updown" => "0",
//		"b_addrem" => "0",
//		"b_edit" => "0",
//		"ruid" => "0",
//		"inst" => "1",	if not specified, rendered by default
//		"prob" => "1",	if not specified, rendered by default
//		"sol" => "1",	if not specified, rendered by default
//		"type" => "1", 
//		"tags" => "0", 
//		"comment" => "0",
//		"color" => "0" );

function render_problem($rend)
{

	// determine whether or not we're doing a web preview
	if ($rend['preview']==1) {
		$rend_type=2;
	} else {
		$rend_type=0;
	}

	// determine cell colors
	switch ($rend['color']) {
		case 0: $color="E1FCFC"; break; // alternating for query
		case 1: $color="CCFFFF"; break; // alternating for query
		case 2: $color="FFB3B3"; break; // highlight after database action
		case 3: $color="FFFFFF"; break; // white for add prob form
	} 	


	if(isset($rend['baseuid']) && $rend['baseuid']!="new") {
		$uid=$rend['baseuid'];
	} else {
		$uid="";
	} // This will only prove to be of use later...

	// this is horribly unrobust... but should work at least for add_prob_form
	if (isset($rend['uid'])) {
		$a_prob = mysql_fetch_array(mysql_query("SELECT * FROM problems WHERE uid=" . $rend['uid']));
	} else {
		$a_prob['type'] = $rend['type_text']; // if no uid is given, $rend should pass in all the atributes that $a_prob should have
		$a_prob['prob'] = $rend['prob_text'];
		$a_prob['answer'] = $rend['sol_text'];
		//unset($rend); // this makes my soul hurt
		$rend['uid'] = $uid; // This was "", but I want to try to snag the baseuid... we'll see.
	}
	
	



	echo "<tr bgcolor=" . $color . ">"; 
	
	if ($rend_type != 2) // if previewing, the padding cell, up/down buttons, add and edit buttons are unnecessary
	{
		echo "<td width=\"10px\" bgcolor=white>&nbsp;</td>"; // padding cell

		echo "<td width=\"50px\">"; 

		echo "<table border=0><tr>";
		// cell containing up/down button
		if ($rend["b_updown"]) {
			echo "<td width=30><center>";
			echo "<img border=0 src='img/up.png'>";
			echo "<p>";
			echo "<img border=0 src='img/down.png'>";
			echo "</center></td>";
		}

		// cell containing add/remove button
		echo "<td width=\"50px\"><center>"; 
		if ($rend["b_addrem"]) {
			echo "<p><span id=\"button" . $rend['uid'] . "\">";
			sensitive_button($rend['uid']); // sensitive_button function is below
			echo "</span>";
		}

		// edit button
		if ($rend["b_edit"]) echo "<p><a href='add_prob_form.php?uid=".$rend['uid']."' title='Edit problem number ".$rend['uid']."' onclick=\"return GB_showCenter('Edit problem', this.href,550,700,function () { prob_query('most_recent_change','');} )\"><img border=0 src='img/edit.png'></a>";

		echo "</center></td>";
		echo "</table>";
	}
	
	// compute some nice cell widths, favorite prob and sol
	$spaces = 2*($rend['prob'] + $rend['sol']) + $rend['tags'];
	$big_space = 2*round(100/$spaces);
	$small_space = round(100/$spaces);
	
	echo "</td><td width=$big_space%>";
	
	// cell containing the problem
	// in each of the next three, if the corresponding flag is not set, it will show it by default. this may or may not be desirable.

	// directions first
	if (!isset($rend['inst']) || $rend['inst']) { 
		if (print_directions($a_prob["type"])) { // some problems don't have directions, so don't print the blank line
			echo $prob_instructions['directions'];
			echo "<br><br>"; }
	}
	
	// then the problem
	if (!isset($rend['prob']) || $rend['prob'])
		echo build_prob($rend['uid'],$a_prob['prob'],$rend_type);
		echo "<br><br>";


	// in the next two, we don't want cells of minimum width to be there if the content isn't there, thus the else statements.

	// then the solution
	if (!isset($rend['sol']) || $rend['sol'])
	{
		echo "</td><td width=$big_space%>";
		echo "<span style=\"font-size:x-small;\">Answer</span><br><p  style=\"border: solid lightgray 1pt; padding:5px;\"> " . build_prob($rend['uid'],$a_prob['answer'],$rend_type,"f","a"). "</p>";
	} else {
			echo "</td><td>";
	}

	// cell containing tags... all this code came from the old grabTabs.php

	if ($rend['tags']) {
		echo "</td><td width=$small_space%>";
		echo "<span id=\"".$rend['uid'].",tags\" class=\"NOTedItText\">".grab_tags($rend['uid'])."</span>";
	} else {
		echo "</td><td>";
	}

	echo "</td>";

	// finish off the row
	echo "</tr>";

}




function grab_tags($uid)
{
	$findConnections = mysql_query("SELECT tagid FROM probtags WHERE probid=".$uid);
	$tagList="";
	while($rowTwo=mysql_fetch_array($findConnections)) {
		$tag=mysql_fetch_array(mysql_query("SELECT tag FROM tags WHERE uid=".$rowTwo{'tagid'}));
		if($rowTwo{'tagid'}!=0) {
			$tagList=$tagList.", ".$tag{tag};
		}
	
	}
	$tagList=trim($tagList,","); // Throw away the extra comma at the end.
	
	if($tagList=="") {
		return "None.";
	} else {
		return $tagList;
	}
}


// This function renders a button to add/remove problem from cart, depending on whether or not the problem is already in the cart.

function sensitive_button($uid)
{

	if (in_array($uid,$_SESSION['mycart']))
		echo "<a href='javascript:add_to_cart(" . $uid. ")'><img border=0 src='img/rem.png'></a>";
	else
		echo "<a href='javascript:add_to_cart(" . $uid. ")'><img border=0 src='img/add.png'></a>";


}



// This function formats a string associated to a problem with uid=$uid. 
// The output will be for use either on the web ($format=0),
// in the tex source ($format=1) or in the web preview ($format=2). It will add the function name to the random function which,
// unless otherwise specified, is just "f". 
// The filename_prepend deals with images occuring in a string. When parsing, one may want to
// distinguish between problems and answers. (so we have one image for problems and another
// for answers.)

function build_prob($uid,$string,$format,$function_name="",$filename_prepend="") {
	

	$to_replace=array();
	$replacements=array();
	
		if($function_name=="") {
			$rand=rand(0,50);
			
			if($rand<15) {
				$function_name="f";
			} else if($rand<25) {
				$function_name="g";
			} else if($rand<35) {
				$function_name="h";
			} else {
				$rand=rand(0,24);
				$alphabet_minus_x="abcdefghijklmnopqrstuvwyz";
				$function_name=$alphabet_minus_x[$rand];
			}
		}
	
		// replacing functions
		$to_replace="[[f]]";
		$replacement=$function_name."(x)";
		$string=str_replace($to_replace,$replacement,$string);
		

	// Web formatting array.
	if($format==0) { 
		
		$to_replace="[[IMAGE]]";
		$start_position=strpos($string, $to_replace);
		$i=0;
		while($start_position!==false) {
			$file_path="problem_images/".$filename_prepend.$uid."-".$i;
			if (file_exists($file_path.".jpg")) { // Checking for jpg.  // changed <p> to <br><br> below to fix some formatting issues.
				$replace_with="<br><br><a href=\"".$file_path.".jpg\" onclick=\"return GB_showImage('Problem ".$uid."', this.href)\"><img width=50 border=2 src=\"".$file_path.".jpg\" alt=\"Image not found.\"></a><br><small><a href=\"image_upload.php?filename=".$filename_prepend.$uid."-".$i."\" onclick=\"return GB_showCenter('Upload Image', this.href,150,350,function () { prob_query('last_query','');})\">(change)</a></small><br><br>"; 
			} else {
				$replace_with="<br><br><a href=\"image_upload.php?filename=".$filename_prepend.$uid."-".$i."\" onclick=\"return GB_showCenter('Upload Image', this.href,150,350,function () { prob_query('last_query','');})\">Add Image</a><br><br>";
			}
			$string=substr_replace($string,$replace_with,$start_position,strlen($to_replace));
			$start_position=strpos($string, $to_replace);
			$i++;
		}
		$string=str_replace_every_other("$","$\displaystyle ",$string);
	}
	
	// LaTeX formatting array.
	if($format==1) { 
		
		$to_replace="[[IMAGE]]";
		$start_position=strpos($string, $to_replace);
		$i=0;
		while($start_position!==false) { 
			$replace_with="\begin{center}\includegraphics[width=4in]{images/".$filename_prepend.$uid."-".$i.".jpg}\end{center}";
			$string=substr_replace($string,$replace_with,$start_position,strlen($to_replace));
			$start_position=strpos($string, $to_replace);
			$i++;
		}		
	}
	
	// Web preview formatting array.
	if($format==2) { 
		
		$to_replace="[[IMAGE]]";
		$start_position=strpos($string, $to_replace);
		$i=0;
		while($start_position!==false) {
			$file_path="problem_images/".$filename_prepend.$uid."-".$i;
			if (file_exists($file_path.".jpg")) { // Checking for jpg.     // changed <p> to <br><br> below to fix some formatting issues.
				$replace_with="<br><br><img width=50 border=2 src=\"".$file_path.".jpg\" alt=\"Image not found.\"><br><br>"; 
			} else {
				$replace_with="<br><br>Add Image<br><br>";
			}
			$string=substr_replace($string,$replace_with,$start_position,strlen($to_replace));
			$start_position=strpos($string, $to_replace);
			$i++;
		}
		$string=str_replace_every_other("$","$\displaystyle ",$string);
	}
	
	// Returning the result.
	return $string;
	
}



function replace_all($string,$to_replace,$replace_with) {
	$start_position=strpos($string, $to_replace);
	$i=0;
	while($start_position!==false) {
		$string=substr_replace($string,$replace_with.$i,$start_position,strlen($to_replace));
		$start_position=strpos($string, $to_replace);
		$i++;
	}
	return $string;
}











function print_tag_cloud($tags,$field) {
        // $tags is the array
      
	if ($field=="tags") 
	{
		$field="";   // tags dont need a modifier
	} else {
		$field=$field.":";
	}

        arsort($tags);
       
        $max_size = 32; // max font size in pixels
        $min_size = 12; // min font size in pixels
       
        // largest and smallest array values
        $max_qty = max(array_values($tags));
        $min_qty = min(array_values($tags));
       
        // find the range of values
        $spread = $max_qty - $min_qty;
        if ($spread == 0) { // we don't want to divide by zero
                $spread = 1;
        }
       
        // set the font-size increment
        $step = ($max_size - $min_size) / ($spread);
       
        // loop through the tag array
        foreach ($tags as $key => $value) {
                // calculate font-size
                // find the $value in excess of $min_qty
                // multiply by the font-size increment ($size)
                // and add the $min_size set above
                $size = round($min_size + (($value - $min_qty) * $step));
       
                echo "<a href=\"javascript:prob_query('tags','$field$key')\" style='font-size: " . $size . "px' title='" . $value . " things tagged with " . $key . "'>" . $key . "</a> ";
        }
}














// This function takes in a .csv formatted string, and returns the appropriate array.
if (!function_exists('str_getcsv')) { 
    function str_getcsv($input, $delimiter = ',', $enclosure = '"', $escape = '\\', $eol = '\n') { 
        if (is_string($input) && !empty($input)) { 
            $output = array(); 
            $tmp    = preg_split("/".$eol."/",$input); 
            if (is_array($tmp) && !empty($tmp)) { 
                while (list($line_num, $line) = each($tmp)) { 
                    if (preg_match("/".$escape.$enclosure."/",$line)) { 
                        while ($strlen = strlen($line)) { 
                            $pos_delimiter       = strpos($line,$delimiter); 
                            $pos_enclosure_start = strpos($line,$enclosure); 
                            if ( 
                                is_int($pos_delimiter) && is_int($pos_enclosure_start) 
                                && ($pos_enclosure_start < $pos_delimiter) 
                                ) { 
                                $enclosed_str = substr($line,1); 
                                $pos_enclosure_end = strpos($enclosed_str,$enclosure); 
                                $enclosed_str = substr($enclosed_str,0,$pos_enclosure_end); 
                                $output[$line_num][] = $enclosed_str; 
                                $offset = $pos_enclosure_end+3; 
                            } else { 
                                if (empty($pos_delimiter) && empty($pos_enclosure_start)) { 
                                    $output[$line_num][] = substr($line,0); 
                                    $offset = strlen($line); 
                                } else { 
                                    $output[$line_num][] = substr($line,0,$pos_delimiter); 
                                    $offset = ( 
                                                !empty($pos_enclosure_start) 
                                                && ($pos_enclosure_start < $pos_delimiter) 
                                                ) 
                                                ?$pos_enclosure_start 
                                                :$pos_delimiter+1; 
                                } 
                            } 
                            $line = substr($line,$offset); 
                        } 
                    } else { 
                        $line = preg_split("/".$delimiter."/",$line); 
    
                        /* 
                         * Validating against pesky extra line breaks creating false rows. 
                         */ 
                        if (is_array($line) && !empty($line[0])) { 
                            $output[$line_num] = $line; 
                        }  
                    } 
                } 
                return $output; 
            } else { 
                return false; 
            } 
        } else { 
            return false; 
        } 
    } 
}





// This file takes two inputs:
//    - $whichPage is either "problems", "answers", or "hybrid". and corresponds to
// 		the file which needs to be rendered.
//	  - $time is the time corresponding to where you want the files to be put.
// 	  - This also relies on the value of the $_SESSION['mycart']


function build_tex($whichPage,$time) {

	$urlbase="http://people.virginia.edu/~svd5d/db_test";
	
	
	$ourFileName = "temp/".session_id().$time."/".$whichPage.".tex";
	$handle = fopen($ourFileName, 'w') or die("can't open file");


	fwrite($handle,"
% This file was created by CalcDB. -- $urlbase
%
% To restore the cart that created this problem set, visit the following URL:
% ");
	
	$uid_list = implode(",",$_SESSION['mycart']);
	
	fwrite($handle,"$urlbase/index.php?restore_cart=".$uid_list);
	
	fwrite($handle,"
%
% If you find an error in a problem, please contribute by correcting it in CalcDB. Use the link above, or search for the UID of the problem shown below. Correcting a problem is easy and saves future generations much heartache!
%
%
\documentclass[letterpaper]{article}
\usepackage{amsmath, amsfonts, amsthm, graphicx, amssymb, textcomp, enumerate}
\usepackage[margin=.75in]{geometry}
\everymath=\expandafter{\\the\everymath\displaystyle} %causes all math to be \\displaystyle
\pagestyle{empty}
\begin{document}
\begin{enumerate}"); // Beginning of document

	// this assumes that the only latexing will be done from the cart.
	$listOfProbs=$_SESSION['mycart'];
	$arrayOfKeys=array_values($listOfProbs);

	$type_list=type_list($arrayOfKeys);


	// Creating the query.
	$end="";
	foreach($arrayOfKeys as $key) { 
		$end=$end." OR uid='".$key."'";
	}


	$query="SELECT * FROM problems WHERE".substr($end,3)." ORDER BY type"; // This should only query for the things we want. Still not super efficient, but clean enough considering I couldn't come up with a better option. The substr function kills the leading "OR" that shouldn't be there.

	$probs=mysql_query($query);

	$n=0; // Number of problems. (excluding individual parts. Can otherwise be thought about as number of types.)
	$types=array(); // List of types of problems.


	$functionList=range('a','z'); // list of functions (i.e. a(x), b(x), ... ) Also, this is used to label the individual parts. ("problem 1 part a", etc.)

	$result=mysql_fetch_array($probs);

	while($result!==false) { // This while loop will run through the list of problems.

		$currentFunction=0; // will run through the different functions.
		$n++; // add one to the problem number.

		// Fetch directions
		$directions=mysql_fetch_array(mysql_query("SELECT (directions) from directions WHERE type=\"$result[type]\"")); 

		// Create new problem and print directions.
		fwrite($handle,"\n\n% Problem number ".$n."\n\item ".$directions['directions']); 

		$types[$n]=$result['type'];

		// Only have parts if there are more than one of them.
		if($type_list[$types[$n]]!=1) {
			fwrite($handle,"\n\n\t\begin{enumerate}");
		}

		while($result['type']==$types[$n]) { // This while loop will run through the list of parts.

			// Print problems and hybrid.
			if($whichPage=="problems" || $whichPage=="hybrid") { 

				$newProblem = build_prob($result['uid'],$result['prob'],1,$functionList[$currentFunction]);

				// Now I need to distinguish between whether there is a single problem, or there are multiple problems.
				if ($type_list[$types[$n]]==1) { // The one-part case.
					fwrite($handle,"\n\n\t".$newProblem);
				} else { // The multi-part case.
					fwrite($handle,"\n\n\t% Problem ".$n.$functionList[$currentFunction]." - CalcDB UID ".$result['uid']."\n\n\t\item ".$newProblem);
				}

				if($whichPage=="hybrid") {
					fwrite($handle," \\\\ \n \\textbf{Answer:} ".build_prob($result['uid'],$result['answer'],1,$functionList[$currentFunction],"a"));
				}
			}

			// Print answers.
			if($whichPage=="answers") {
				// Now I need to distinguish between whether there is a single problem, or there are multiple problems.
				$newAnswer=build_prob($result['uid'],$result['answer'],1,$functionList[$currentFunction],"a");
				if ($type_list[$types[$n]]==1) { // The one-part case.
					fwrite($handle,"\n\n\t".$newAnswer);
				} else { // The multi-part case.
					fwrite($handle,"\n\n\t% Answer to problem ".$n.$functionList[$currentFunction]." - CalcDB UID ".$result['uid']."\n\n\t\item ".$newAnswer);
				}
			}

			$result=mysql_fetch_array($probs);
			$currentFunction++;

		}

		// Only have parts if there are more than one of them.
		if($type_list[$types[$n]]!=1) {
			fwrite($handle,"\n\n\t\end{enumerate}");
		}
	}


	fwrite($handle,"\n\n\end{enumerate}\n\end{document}");
	fclose($handle);
	
	
	
}






// This function takes a UID and spits out an array of image file locations 
// which are attached to that uid.
//    - type=0 if you want the images associated to the problem.
//    - type=1 if you want the images associated to the answer.
//    - type=2 if you want both.
// Since this relies on the folder in which the images are located, we need to worry
// about where this thing is being called from. Hence the $path variable. It's a 
// string which gives the relative path back to home. e.g. if the file in which I'm 
// calling "find_images" is located inside of /latex, I'd have "../" as my relative
// path. :(
function find_images($uid,$type=2,$path="") {
	
	$result=array();
	if($type==0 || $type==2) {
		$i=0; // image index.
	
		while(file_exists($path."problem_images/".$uid."-".$i.".jpg")) {
			$result[]=$path."problem_images/".$uid."-".$i.".jpg";
			$i++;
		}
	}
	
	if($type==1 || $type==2) {
		$i=0; // reset index.
	
		while(file_exists($path."problem_images/a".$uid."-".$i.".jpg")) {
			$result[]=$path."problem_images/a".$uid."-".$i.".jpg";
			$i++;
		}
	}
	
	return $result;
}


function print_directions($type)
{
	$prob_instructions = mysql_fetch_array(mysql_query("SELECT directions FROM directions WHERE type=\"". trim($type) . "\""));
	return $prob_instructions['directions'];
}




// sweet. from http://xavisys.com/replace-every-other-occurrence-with-str_replace/
function str_replace_every_other($needle, $replace, $haystack, $replace_first=true) {
    $offset = strpos($haystack, $needle);
    //If we don't replace the first, go ahead and skip it
    if (!$replace_first) {
        $offset += strlen($needle);
        $offset = strpos($haystack, $needle, $offset);
    }
    while ($offset !== false) {
        $haystack = substr_replace($haystack, $replace, $offset, strlen($needle));
        $offset += strlen($replace);
        $offset = strpos($haystack, $needle, $offset);
        if ($offset !== false) {
            $offset += strlen($needle);
            $offset = strpos($haystack, $needle, $offset);
        }
    }
    return $haystack;
}


?>
