<?php

include("../connect.php");

$q = strtolower($_GET["q"]);
if (!$q) return;


$items=array();


/* ADD ALL TAGS TO SEARCH LIST */
$query=mysql_query("SELECT * FROM tags");
while($result=mysql_fetch_array($query)) {
	$items[$result['tag']]="tag";
}


/* ADD ALL PROBLEMS AND UIDS TO SEARCH LIST */
// $query=mysql_query("SELECT * FROM problems");
// while($result=mysql_fetch_array($query)) {
// 	$items[$result['uid']]="problem id";
// 	$items[$result['prob']]="problem";
// }

/* ADD ALL DIRECTIONS TO SEARCH LIST */
// $query=mysql_query("SELECT * FROM directions");
// while($result=mysql_fetch_array($query)) {
// 	$items[$result['directions']]="directions";
// }


foreach ($items as $key=>$value) {
	if (strpos(strtolower($key), $q) !== false) {
		echo "$key|$value\n";
	}
}

?>