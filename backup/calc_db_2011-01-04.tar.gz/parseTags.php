<?

include("connect.php");
include("strgetcsv.php");


// Requires a string, "tagList", and a "UID".
// This will insert all tags which are currently in the database into the database.

// Removes all current tags from the problem (as long as the input wasn't empty)
if(trim($tagList!="") && !$batch) {
	$sql="DELETE FROM probtags WHERE probid=\"$UID\";";
	
	if (!mysql_query($sql,$dbhandle)) {
		die('Error: ' . mysql_error());
   	}
}

$arrayOfTags=str_getcsv($tagList);

$nonexistent=array();
$n=0; // Number of elements in nonexistent.

foreach($arrayOfTags[0] as $value) {

	$value=strtolower(trim($value));
	if ($value != "") { // Make sure we don't add any empty tags.
		$id=mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE tag=\"".$value."\""));
		$tagid=$id{'uid'};
		
		settype($tagid,"int"); 
		settype($UID,"int"); // They were strings before this.
		
		if($tagid!=0) { // Ensure that the tag actually exists.
			$sql="INSERT INTO probtags (probid, tagid) VALUES ('$UID','$tagid')";
			
			if (!mysql_query($sql,$dbhandle)) {
				die('Error: ' . mysql_error());
			}
			
		} else { // Add tag to "list of nonexistents" if it does not exist.
		
			$nonexistent[$n]=$value;
			$n=$n+1;
			
		}
	}
}
	
foreach($nonexistent as $tag) { // Create nonexistent tags.

	$value=strtolower(trim($tag));
	$sql="INSERT INTO tags (tag) VALUES ('$value')";
	
	if (!mysql_query($sql,$dbhandle)) {
		die('Error: ' . mysql_error());
   	}
   	
	$id=mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE tag=\"".$value."\""));
	$tagid=$id{'uid'};
	settype($tagid,"int"); 
	settype($UID,"int"); // They were strings before this.
	if($tagid!=0) { // Ensure that the tag actually exists. (It should... I just created it.)
	
		$sql="INSERT INTO probtags (probid, tagid) VALUES ('$UID','$tagid')";
		
		if (!mysql_query($sql,$dbhandle)) {
  			die('Error: ' . mysql_error());
  		}
	}
	

}


?>