<html>
<head>
<title>Calculus Problem Database</title>
</head>
<body>

<script src="toggle.js" type="text/javascript"></script>
<script src="ajax_magic.js" type="text/javascript"></script>

<?php
include("connect.php");
?>

<?
// This block creates an array of problem instruction types
// in the form $a_types["type name"] = # of that type
// -------------------------------------------------------------------------------------------
$a_types = array();
$q_types = mysql_query("SELECT distinct type FROM problems");

while ($row = mysql_fetch_array($q_types)) {
	$trimtype=trim($row{'type'});
	if (!array_key_exists($trimtype, $a_types)) {
		$a_types[$trimtype]=1;
	} else {
		$a_types[$trimtype]+=1; }
}
// -------------------------------------------------------------------------------------------



// This block creates an array of tags
// in the form $a_tags["tag name"] = # of that tag
// -------------------------------------------------------------------------------------------
$a_tags = array();
$q_tags = mysql_query("SELECT * FROM probtags");

while ($row = mysql_fetch_array($q_tags)) {
	$specificTag = mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE uid=\"$row[tagid]\""));
	$trimTag=trim($specificTag[tag]);
	if (!array_key_exists($trimTag,$a_tags)) {
		$a_tags[$trimTag]=1;
	} else {
		$a_tags[$trimTag]+=1;
	}
}
// -------------------------------------------------------------------------------------------

?>



<table width=100%>
<tr>
<td width=200 valign=top>
<h1>Navigation</h1><hr>

<h3><a href="javascript:switchMenu('tag_list')">Tag List</a></h3>
<div id="tag_list" style="display:none">
<? foreach($a_tags as $key => $value) { echo "$key ($value)<br>"; } ?><br>
</div>



<h3><a href="javascript:switchMenu('type_list')">Type List</a></h3>
<div id="type_list" style="display:none">
<? foreach($a_types as $key => $value) { echo "$key ($value)<br>"; } ?><br>
</div>

<button type="button" onclick="loadXMLDoc()">Change Content</button>


</td>
<td valign=top>
<div id="d_query">
content in div named query


<? // code for content ?>

</div>
</td>
</tr>
</table>
