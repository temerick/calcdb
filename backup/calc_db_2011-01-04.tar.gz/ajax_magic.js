function loadXMLDoc()
{
// don't mess with this -- block to create magic hoohah -- (which will even work with IE5)
if (window.XMLHttpRequest){xmlhttp=new XMLHttpRequest();}else{xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");}

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("d_query").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","query.php?col=tags&value=composite%20domain",true);
xmlhttp.send();
}
