<?php
include("connect.php");
?>

<?
$prob = addslashes($_POST[prob]);
$answer = addslashes($_POST[answer]);
$type = addslashes($_POST[type]);
$comment = addslashes($_POST[comment]);


$sql="INSERT INTO problems (prob, answer, type, comment) VALUES ('$prob','$answer','$type','$comment')";

if (!mysql_query($sql,$dbhandle))
  {
  die('Error: ' . mysql_error());
  }
echo "1 record added <a href=\"index.php\">Go back</a>";


mysql_close($dbhandle)
?>
