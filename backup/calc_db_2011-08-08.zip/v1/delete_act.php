<?php
include("connect.php");
?>

<?
//echo $_GET["uid"];
$sql="DELETE FROM problems WHERE uid=\"".$_GET["uid"]."\";";

if (!mysql_query($sql,$dbhandle))
  {
  die('Error: ' . mysql_error());
  }
echo "1 record deleted. <a href=\"index.php\">Go back</a>";

mysql_close($dbhandle)
?>
