<?

if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/png")
|| ($_FILES["file"]["type"] == "image/pjpeg"))
&& ($_FILES["file"]["size"] < 200000)) {
	
	$filename=$_POST['filename']; // This is the filename I want to assign on the server.
	
	
	if ($_FILES["file"]["error"] > 0) {
    	echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    } else {
    	// echo "Upload: " . $_FILES["file"]["name"] . "<br />";
    	// echo "Type: " . $_FILES["file"]["type"] . "<br />";
    	// echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
    	// echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";


		$file_suffix=substr($_FILES["file"]["name"],strrpos($_FILES["file"]["name"],".")); // this includes the "."
		
		
    	if (file_exists("problem_images/" . $filename.$file_suffix)) {
      		echo $filename.$file_suffix . " already exists. ";
      	} else {
      		move_uploaded_file($_FILES["file"]["tmp_name"],
      			"problem_images/" . $filename.$file_suffix);
      		echo "Success!";
      	}
		
		$file_prefix=substr($_FILES["file"]["name"],0,strrpos($_FILES["file"]["name"],"."));
		
		if($file_suffix!=".jpg") {
			echo exec("convert ./problem_images/".$filename.$file_suffix." ./problem_images/".$filename.".jpg");
		}
	}
} else {
  	echo "Invalid file";
}
?>