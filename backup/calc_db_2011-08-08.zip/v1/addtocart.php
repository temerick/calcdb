<?php
include("connect.php");

foreach($_SESSION['addtocart'] as $key => $value) {
	if(is_numeric($key) && !in_array($key,$_SESSION['mycart'])){
		$_SESSION['mycart'][]=$key; 
		//echo "added $key to your cart<br>"; 
	}
	else { 
		//echo "$key is already in your cart<br>"; 
	}
}
header( 'Location: viewcart.php' );


?>
