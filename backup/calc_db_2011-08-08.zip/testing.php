<?
echo "<a href='javascript:share_cart($user,$cart_number)'>hihi</a>";
print_r($_GET);

?>