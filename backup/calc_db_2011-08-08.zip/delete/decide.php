<?
include("connect.php");
if ($_POST['latex']) {
	$_SESSION['sel_prob'] = $_POST;
	header( 'Location: latex.php' );
} else if ($_POST['addcart']) {
	$_SESSION['addtocart'] = $_POST;
	header( 'Location: addtocart.php' );
} else if ($_POST['tag']) {
	print_r($_POST);
	$keys=array_keys($_POST,"on");
	$tagList=$_POST['type'];
	$batch=TRUE;
	foreach($keys as $UID) {
		include("parseTags.php");
	}
	header('Location: ' . $_SERVER['HTTP_REFERER']);
} else if ($_POST['delete']) {
	include("delete.php");
}
?>
