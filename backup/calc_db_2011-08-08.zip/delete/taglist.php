<?php
include("connect.php");
?>

<? // create a list of types (should be tags later, I guess)


// $result = mysql_query("SELECT * FROM problems");
// $types = array();
// while ($row = mysql_fetch_array($result)) {
// $trimtype=trim($row{'type'}); // stupid tim's shoddy database work oh crap he's right behind me
// if (!array_key_exists($trimtype,$types)) {
// 	$types[$trimtype]=1;
// } else {
// 	$types[$trimtype]+=1; }
// }


$result = mysql_query("SELECT * FROM probtags");
$tags = array();
while ($row = mysql_fetch_array($result)) {
	// echo "row: ".print_r($row)."<br>";
	$specificTag = mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE uid=\"$row[tagid]\""));
	// echo "ST: ".$specificTag."<br>";
	$trimTag=trim($specificTag[tag]);
	if (!array_key_exists($trimTag,$tags)) {
		$tags[$trimTag]=1;
	} else {
		$tags[$trimTag]+=1;
	}
}

print_r($tags);

?>