
<?
include("connect.php");
include("functions.php");

$FIELD=$_GET['col'];
$VALUE=$_GET['value'];

//echo "field is $FIELD<br>";
//echo $_SESSION['last_modified_uid'];

// this block is for the special case of "most_recent_change", whose UID is stored in $_SESSION
// 
if ($FIELD=="most_recent_change") {
	$_GET['highlight'] = $_SESSION['last_modified_uid'];

	if (isset($_SESSION['last_action']) && $_SESSION['last_action'] == "insert")
	{	// if the last action was a new problem creation, query for that problem's type
		$FIELD="tags";
		$VALUE="type:".$_SESSION['last_modified_type'];
	} else { // if the last action was a delete or update or is not defined, just repeat the last query
		$FIELD="last_query";
	}
}

// when solution display is toggled, or we finish adding/modifying a problem, use prob_query("last_query") to refresh the search panel. this next block deals with that. query is stored in SESSION. also uses last query if no $FIELD is provided.
if (!isset($FIELD) || $FIELD=="last_query" || $FIELD=="") 
{
	if ($_SESSION['last_col'])
	{
		$FIELD = $_SESSION['last_col'];
		$VALUE = $_SESSION['last_value'];
	} else {
		echo "Select a search criterion.";
		die;
	}
} else {
	$_SESSION['last_col'] = $FIELD;
	$_SESSION['last_value'] = $VALUE;
}


// at the end of this block, $result should be an array of problems to be rendered.
// $FIELD should ONLY have values "all", "cart", "uidlist" or "tags"
$t_result=array();

if ($FIELD=="all") {		// returning all problems
	$probIds = mysql_query("SELECT * FROM problems");
	while ($row = mysql_fetch_array($probIds)) {
		$t_result[] = $row['uid'];
	}

} else if ($FIELD=="cart") {		// returning problems in the cart
	$t_result = $_SESSION['mycart'];

} else if ($FIELD=="uidlist") {
	if ($VALUE) { $t_result = explode(",",$VALUE); } else { echo "No results found."; die; }
	
} else if ($FIELD=="tags") {		// returning all problems matching a particular tag
	$arrayOfTags=str_getcsv($VALUE);	// split the tag list into an array

	foreach ($arrayOfTags[0] as $tag) { // get the uids for problems matching each particular tag
		if (substr_count($tag, "type:") > 0)
		{	// if a type was specified as a "type:blah" tag, restrict to those also.
			$type_restrict = str_replace("type:","",$tag);
			$q_type_probs = mysql_query("SELECT uid FROM problems WHERE type=\"$type_restrict\"");
			while ($row = mysql_fetch_array($q_type_probs)) {
				$tag_result["type:$type_restrict"][] = $row['uid'];
			}
		} else { // get all the problems matching the current tag
			$tagid = mysql_fetch_array(mysql_query("SELECT uid FROM tags WHERE tag=\"$tag\""));
			$probIds = mysql_query("SELECT probid FROM probtags WHERE tagid=\"$tagid[uid]\"");
			while ($row = mysql_fetch_array($probIds)) {
				$tag_result[$tag][]=$row['probid'];
			}
		}

	}

	// if there is more than one tag, intersect all the above arrays, to emulate AND search. much more useful.
	if (sizeof($arrayOfTags[0]) > 1)
	{
		$t_result=call_user_func_array('array_intersect', $tag_result);
	} else {
		$t_result=$tag_result[end($arrayOfTags[0])];
	}

	// find related tags... result is $related_tags[meaningless index] = "tag name"
	$uid_list_string = implode(",",$t_result);
	$q_othertags = mysql_query("SELECT tagid FROM probtags WHERE probid IN ($uid_list_string)");
	while ($row = mysql_fetch_array($q_othertags)) { $related_tag_ids[] = $row['tagid']; }
	$related_tag_ids = array_unique($related_tag_ids);
	$tag_id_list_string = implode(",",$related_tag_ids);
	$q_relatedtags = mysql_query("SELECT tag FROM tags WHERE uid IN ($tag_id_list_string)");
	while ($row = mysql_fetch_array($q_relatedtags)) { 
		if (!in_array($row['tag'],$arrayOfTags[0])) $related_tags[] = $row['tag']; 
	}

} else {

	echo "this should not have happened!";
	die;
}


// this could probably be done more elegantly in the above,
// but i want to convert the above array which is "dummy#" => "uid"
// to an array which carries types, i.e. "uid" => "type"

$uid_string = implode(",", $t_result);
$type_query = mysql_query("SELECT uid,type FROM problems WHERE uid IN (".$uid_string.");");
$result=array();
foreach($t_result as $stupid => $uid)
{
	$temp_type = mysql_fetch_array($type_query);
	$result[$temp_type['uid']] = $temp_type['type'];
}


 //print the latex option box if this is the cart
if ($FIELD=="cart")
{
	echo "<h2>Your selected problems</h2>";
	echo "<center><h3><a href=\"javascript:switchMenu('latex_options')\">Download LaTeX</a></h3>";
	echo "<span id=\"latex_options\" style=\"display:none\">";
	include("latex.php");
	echo "</span></center>";
}
else
{
	echo "<h3>Search results</h3>";
	// the cart should respect the order of 'mycart' array, but if we're just querying problems, let's sort them by type
	asort($result);
}

if ($FIELD=="tags")
{
	// print the current query tags, with option to remove them ($arrayOfTags should still be around)
	echo "<p style=\"border: solid lightgray 1pt; padding:5px;\">Tags you searched for: ";
	$search_tags = $arrayOfTags[0];
	if (sizeof($search_tags) > 1)
	{
		foreach ($search_tags as $curtag)
		{
			$tag_removed = array_diff($search_tags,array($curtag));
			$tag_removed_list = implode(",",$tag_removed);
			$search_tags_text[] = "<a href=\"javascript:prob_query('tags','$tag_removed_list')\">$curtag</a>";
		}
		echo implode(", ", $search_tags_text);
		echo " <small>(click to remove from current query)</small>";

	} else {
		echo end($search_tags);
	}
	echo "</p>";


	if (sizeof($related_tags)>0)
	{
		// print the related tags search narrowing links.
		// for now, only in tag search, although see note above where $related_tags is created.
		echo "<p style=\"border: solid lightgray 1pt; padding:5px;\">Narrow your search: ";
		echo "<span id=\"tag_subsearch\" >";
		foreach($related_tags as $new_value)
		{
			$related_tags_text[] = "<a href=\"javascript:prob_query('tags','$VALUE,$new_value')\">$new_value</a>";
		}
		echo implode(", ",$related_tags_text);
		echo "</span></p>";
	}
}

?>


<table width=100% cellpadding="10" cellspacing="0" border=0>
<tr>

<?
if (sizeof($result)>0)
{
	$COUNT=0;

	$last_type_rendered = "";

	foreach ($result as $UID => $prob_type) {
	
		if ($prob_type != $last_type_rendered) { // block determining if a new type set is starting
			$prob_instructions = mysql_fetch_array(mysql_query("SELECT directions FROM directions WHERE type=\"". $prob_type . "\""));
			echo "<tr bgcolor=white><td></td></tr><tr bgcolor=lightblue><td valign=center colspan=6><h4>".$prob_instructions['directions']."</h4></td></tr>";
			$last_type_rendered = $prob_type;
		}
	
		// To bounce between colors for rows
		$color=($COUNT +1)%2;
		if ($_GET['highlight'] == $UID) { $color = "2"; }

		// for up/down buttons only in cart
		if ($FIELD=="cart") {$updown = "1"; } else { $updown = "0"; }

		$render_attributes = array(
			"uid" => "$UID",
			"b_updown" => $updown,
			"b_addrem" => "1",
			"b_edit" => "1",
			"inst" => "0",
			"prob" => "1",
			"sol" => $_SESSION['sol_disp'],
			"tags" => $_SESSION['tag_disp'], 
			"color" => $color );
	
		//echo "rendering" . $UID;

		render_problem($render_attributes);

		$COUNT+=1;

	}
} else { // query returned nothing, say so.
	echo "<td>Nothing found!</td>";
}

?>

<script>window.onload=alert("hi");</script>
</table>

