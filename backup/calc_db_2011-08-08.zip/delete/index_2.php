<?
// This page exists because, for some reason, I was unable to save edits to index.php.
// I'm not sure why this is the case, but it's weird.

?>
<html>
<head>
<title>Calculus Problem Database</title>

<script type="text/javascript">
	var GB_ROOT_DIR = "./greybox/";
</script>
<link href="greybox/gb_styles.css" rel="stylesheet" type="text/css" media="all" />

</head>
<body>

<script src="toggle.js" type="text/javascript"></script>
<script src="ajax_magic.js" type="text/javascript"></script>
<SCRIPT SRC="MathJax/MathJax.js"> 
  MathJax.Hub.Config({
    extensions: ["tex2jax.js"],
    jax: ["input/TeX","output/HTML-CSS"],
    tex2jax: {inlineMath: [["$","$"],["\\(","\\)"]]}
  });
</SCRIPT> 
<script type="text/javascript" src="instantedit.js"></script>
<script type="text/javascript" src="greybox/AJS.js"></script>
<script type="text/javascript" src="greybox/AJS_fx.js"></script>
<script type="text/javascript" src="greybox/gb_scripts.js"></script>



<?php
include("connect.php");
?>

<?
// This block creates an array of problem instruction types
// in the form $a_types["type name"] = # of that type
// -------------------------------------------------------------------------------------------
$a_types = array();
$q_types = mysql_query("SELECT type FROM problems");

while ($row = mysql_fetch_array($q_types)) {
	$trimtype=trim($row{'type'});
	if (!array_key_exists($trimtype, $a_types)) {
		$a_types[$trimtype]=1;
	} else {
		$a_types[$trimtype]+=1; }
}
// -------------------------------------------------------------------------------------------



// This block creates an array of tags
// in the form $a_tags["tag name"] = # of that tag
// -------------------------------------------------------------------------------------------
$a_tags = array();
$q_tags = mysql_query("SELECT * FROM probtags");

while ($row = mysql_fetch_array($q_tags)) {
	$specificTag = mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE uid=\"$row[tagid]\""));
	$trimTag=trim($specificTag[tag]);
	if (!array_key_exists($trimTag,$a_tags)) {
		$a_tags[$trimTag]=1;
	} else {
		$a_tags[$trimTag]+=1;
	}
}
ksort($a_tags);
// -------------------------------------------------------------------------------------------

?>



<table>
<tr>
<td width=190 valign=top>
<center><a href="index.php"><img src="img/logo.png"></a></center>


<h3><a href="javascript:prob_query('cart','')">Cart</a> (<span id="cartcount"><? include("print_cart_count.php"); ?></span>)</h3>



<h3><a href="javascript:switchMenu('tag_list')">Tag List</a></h3>
<div id="tag_list" style="display:none">
<? foreach($a_tags as $key => $value) { echo "<a href=\"javascript:prob_query('tags','$key')\">$key</a> ($value)<br>"; } ?><br>
</div>



<h3><a href="javascript:switchMenu('type_list')">Type List</a></h3>
<div id="type_list" style="display:none">
<? foreach($a_types as $key => $value) { echo "<a href=\"javascript:prob_query('type','$key')\">$key</a> ($value)<br>"; } ?><br>
</div>


<h3><a href="javascript:prob_query('','all')">All Probs</a></h3>



<p>Solutions: <span id="sol_disp"><? include("print_sol_disp_pref.php"); ?></span>



<br><br><br>
<font size=-2>
<p><a href="debug_viewsession.php">View $SESSION</a>
<br><a href="debug_destroysession.php">Destroy $SESSION</a>
</font>



</td>
<td valign=top>
<span id="d_query">
	
<center>Select a search criterion.</center>


<? // code for content ?>

</span>
</td>
</tr>
</table>
