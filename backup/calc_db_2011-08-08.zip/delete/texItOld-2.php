<?
include("../connect.php");
include("../functions.php");


// This file takes two inputs:
//    - $whichPage is either "problems", "answers", or "hybrid". and corresponds to
// 		the file which needs to be rendered.
//	  - $time is the time corresponding to where you want the files to be put.
// 	  - This also relies on the value of the $_SESSION['mycart']


function build_tex($whichPage,$time) {

	$urlbase="http://people.virginia.edu/~svd5d/db_test";
	
	
	$ourFileName = "temp/".session_id().$time."/".$whichPage.".tex";
	$handle = fopen($ourFileName, 'w') or die("can't open file");


	fwrite($handle,"
% This file was created by CalcDB. -- $urlbase
%
% To restore the cart that created this problem set, visit the following URL:
% ");
	
	$uid_list = implode(",",$_SESSION['mycart']);
	
	fwrite($handle,"$urlbase/index.php?restore_cart=".$uid_list);
	
	fwrite($handle,"
%
% If you find an error in a problem, please contribute by correcting it in CalcDB. Use the link above, or search for the UID of the problem shown below. Correcting a problem is easy and saves future generations much heartache!
%
%
\documentclass[letterpaper]{article}
\usepackage{amsmath, amsfonts, amsthm, graphicx, amssymb, textcomp, enumerate}
\usepackage[margin=.75in]{geometry}
\everymath=\expandafter{\\the\everymath\displaystyle} %causes all math to be \\displaystyle
\pagestyle{empty}
\begin{document}
\begin{enumerate}"); // Beginning of document

	if(!empty($_SESSION['mycart'])) {
		// this assumes that the only latexing will be done from the cart.
		// $listOfProbs=$_SESSION['mycart'];
	
		$type_list=type_list($_SESSION['mycart']);


		// Creating the query.
		//$end="";
		//foreach($listOfProbs as $key) { 
		//	$end=$end." OR uid='".$key."'";
		//}

		// Query the database
		$query="SELECT * FROM problems WHERE uid IN ($uid_list) ORDER BY type";
		$probs=mysql_query($query);

		$n=0; // Number of problems. (excluding individual parts. Can otherwise be thought about as number of types.)
		$types=array(); // List of types of problems.
		
		
		$functionList='abcdefghijklmnopqrstuvwyz'; // list of functions (i.e. a(x), b(x), ... ) 
		
		// used to label the parts.
		$part_list=range('a','z');
		
		$result=mysql_fetch_array($probs);

		while($result!==false) { // This while loop will run through the list of problems.

			$currentFunction=0; // will run through the different functions.
			$n++; // add one to the problem number.

			// Fetch directions
			$directions=mysql_fetch_array(mysql_query("SELECT (directions) from directions WHERE type=\"$result[type]\"")); 

			// Create new problem and print directions.
			fwrite($handle,"\n\n% Problem number ".$n."\n\item ".$directions['directions']); 

			$types[$n]=$result['type'];

			// Only have parts if there are more than one of them.
			if($type_list[$types[$n]]!=1) {
				fwrite($handle,"\n\n\t\begin{enumerate}");
			}

			while($result['type']==$types[$n]) { // This while loop will run through the list of parts.

				// Print problems and hybrid.
				if($whichPage=="problems" || $whichPage=="hybrid") { 

					$newProblem = build_prob($result['uid'],$result['prob'],1,$functionList[$currentFunction]);

					// Now I need to distinguish between whether there is a single problem, or there are multiple problems.
					if ($type_list[$types[$n]]==1) { // The one-part case.
						fwrite($handle,"\n\n\t".$newProblem);
					} else { // The multi-part case.
						
						$super_part="";
						$part=$currentFunction%26;
						$item="";
						
						if($currentFunction>25) {
							$super_part = $part_list[($currentFunction-($currentFunction%26))/26-1];
							$item="[(".$super_part.$part_list[$part].")]";
						}
						
						fwrite($handle,"\n\n\t% Problem ".$n.$super_part.$part_list[$part]." - CalcDB UID ".$result['uid']."\n\n\t\item".$item." ".$newProblem);
					}

					if($whichPage=="hybrid") {
						fwrite($handle," \\\\ \n \\textbf{Answer:} ".build_prob($result['uid'],$result['answer'],1,$functionList[$currentFunction],"a"));
					}
				}

				// Print answers.
				if($whichPage=="answers") {
					// Now I need to distinguish between whether there is a single problem, or there are multiple problems.
					$newAnswer=build_prob($result['uid'],$result['answer'],1,$functionList[$currentFunction],"a");
					if ($type_list[$types[$n]]==1) { // The one-part case.
						fwrite($handle,"\n\n\t".$newAnswer);
					} else { // The multi-part case.
						
						$super_part=""; 
						$item="";
						$part=$currentFunction%26;
						
						if($currentFunction>25) {
							$super_part = $part_list[($currentFunction-($currentFunction%26))/26-1];
							$item="[(".$super_part.$part_list[$part].")]";
						}
						
						fwrite($handle,"\n\n\t% Answer to problem ".$n.$super_part.$part_list[$part]." - CalcDB UID ".$result['uid']."\n\n\t\item".$item." ".$newAnswer);
					}
				}

				$result=mysql_fetch_array($probs);
				$currentFunction++;

			}

			// Only have parts if there are more than one of them.
			if($type_list[$types[$n]]!=1) {
				fwrite($handle,"\n\n\t\end{enumerate}");
			}
		}
	} else {
		fwrite($handle,"\n\n\item Dude, there wasn't anything in your cart.
		                                 __ 
		                       _ ,___,-'\",-=-. 
		           __,-- _ _,-'_)_  (\"\"`'-._\ `. 
		        _,'  __ |,' ,-' __)  ,-     /. | 
		      ,'_,--'   |     -'  _)/         `\ 
		    ,','      ,'       ,-'_,`           : 
		    ,'     ,-'       ,(,-(              : 
		         ,'       ,-' ,    _            ; 
		        /        ,-._/`---'            / 
		       /        (____)(----. )       ,' 
		      /         (      `.__,     /\ /, 
		     :           ;-.___         /__\/| 
		     |         ,'      `--.      -,\ | 
		     :        /            \    .__/ 
		      \      (__            \    |_ 
		       \       ,`-, *       /   _|,\ 
		        \    ,'   `-.     ,'_,-'    \ 
		       (_\,-'    ,'\\\")--,'-'       __\ 
		        \       /  // ,'|      ,--'  `-. 
		         `-.    `-/ \'  |   _,'         `. 
		            `-._ /      `--'/             \ 
		    -DOH!-     ,'           |              \ 
		              /             |               \ 
		           ,-'              |               / 
		          /                 |             -' 
");
	}

	fwrite($handle,"\n\n\end{enumerate}\n\end{document}");
	fclose($handle);
	
	
	
}


$whichPage=$_GET['p'];
$time=time();

if(!mkdir("./temp/".session_id().$time)) { // Make a directory to store all of this stuff in.
	echo "unable to create directory. :(";
}

if($whichPage=="zip") { // this will be used for zipping and downloading / emailing.
	
	if(array_key_exists("email",$_POST)) { // Determine integrity of email address.
		include("validEmail.php");
		if(!validEmail($_POST['emailAddress'])) { // Huh. For some reason this hangs when I enter in a crazy domain that doesn't exist. Better than it going through, but it would be nice if it picked up on that. I don't know enough about the script to debug it right now, though.
			
			header( 'Location: http://people.virginia.edu/~svd5d/db_test/latex.php?p=notvalid' ); // I can't get this to work as a relative path. i.e. I wanted to use ../latex.php?p=notvalid , but that didn't fly for some reason. :(
			// This non-relative path is something it'd be really nice to fix. I'm not entirely sure what's wrong. I was thinking about using the server referrer and just tacking on "?p=notvalid" at the end, but that would break if the user entered in a bad email address more than once. (You'd get "?p=notvalid?p=notvalid", which would error.)
			
		}
	}
	
	
	
	// Grab the UIDs you're looking for
	$list_of_uids=array_values($_SESSION['mycart']);
	
	// Let's hunt for images:
	
	foreach($list_of_uids as $id) {
		$images=array_merge($images,find_images($id,2,"../"));
	}

	
	if(array_key_exists("problems",$_POST)) { // build "problems"
		build_tex("problems",$time); 
	}
	if(array_key_exists("answers",$_POST)) { // build "answers"
		build_tex("answers",$time);
	}
	if(array_key_exists("hybrid",$_POST)) { // build "hybrid"
		build_tex("hybrid",$time);
	}
	// Zip the files
	require ("pclzip.lib.php");
	$zipfile = new PclZip('temp/'.session_id().$time.'/packet.zip');
	
	
	print_r($images);
	
	// add problems
	if(array_key_exists("problems",$_POST)) { 
		
		$v_list = $zipfile->add('temp/'.session_id().$time.'/problems.tex','','temp/'.session_id().$time); 
		if ($v_list == 0) { // error handling
			die ("Error: " . $zipfile->errorInfo(true));
		}	
	}
	
	if(array_key_exists("answers",$_POST)) { // add answers
		
		$v_list = $zipfile->add('temp/'.session_id().$time.'/answers.tex','','temp/'.session_id().$time);
		if ($v_list == 0) {
			die ("Error: " . $zipfile->errorInfo(true));
		}
	}
	
	if(array_key_exists("hybrid",$_POST)) { // add hybrid
		
		$v_list = $zipfile->add('temp/'.session_id().$time.'/hybrid.tex','','temp/'.session_id().$time);
		if ($v_list == 0) {
			die ("Error: " . $zipfile->errorInfo(true));
		}
	}
	
	// Now to add the images:
	$v_list = $zipfile->add($images,'images/','../problem_images/');
	if ($v_list ==0) {
		die ("Error: " . $zipfile->errorInfo(true));
	}
	
	
	
	if(array_key_exists("download",$_POST)) {  // Download.
		header( 'Location: temp/'.session_id().$time.'/packet.zip');
	}
	
	if(array_key_exists("email",$_POST)) { // Email.
		include("email.php");
	}
	
} else { // if p=problems, answers, or hybrid	
	build_tex($whichPage,$time);
	header( 'Location: temp/'.session_id().$time.'/'.$whichPage. '.tex' );
}

?>
