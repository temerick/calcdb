<html>
<head>
<?
if($_GET[edit]==1) {
echo "<script type=\"text/javascript\" src=\"instantedit.js\"></script>";
} else {
echo "<SCRIPT SRC=\"../MathJax/MathJax.js\"> 
  MathJax.Hub.Config({
    extensions: [\"tex2jax.js\"],
    jax: [\"input/TeX\",\"output/HTML-CSS\"],
    tex2jax: {inlineMath: [[\"$\",\"$\"],[\"\\(\",\"\\)\"]]}
  });
</SCRIPT>"; 
}
?>
</head>
<body>
<?
include("connect.php");
?>

<?php

//execute the SQL query and return records
$FIELD=$_GET[col];
$VALUE=$_GET[value];

if ($VALUE=="all") {
	$QUERY="";
} else {
	$QUERY="WHERE $FIELD=\"$VALUE\"";
}
$result = mysql_query("SELECT * FROM problems $QUERY");
//fetch the data from the database
?>

<table>
<tr><td width=300px>Problem</td><td>Answer</td><!--<td>Comment</td>--><td>Tags</td></tr>

<?
$COUNT=0;
while ($row = mysql_fetch_array($result)) {
$UID=$row{'uid'};
include("grabTags.php");
echo "<tr>
<!--<form action=\"tagProbs_act.php\" method=\"post\"><input type=\"hidden\" name=\"uid\" value=\"".$UID."\">-->
<td><span id=\"".$UID.",prob\" class=\"editText\">".$row{'prob'}."</span></td><td><span id=\"".$UID.",answer\" class=\"editText\">".$row{'answer'}."</span></td><!--<td>".$row{'comment'}."</td>--><td><span id=\"".$UID.",tags\" class=\"editText\">".$tagList."</span></td>
<!--<td><textarea rows=\"1\" cols=\"35\" name=\"bunchATags\"></textarea></td><td><input type=\"submit\" value=\"Save\" /></td></form>-->
</tr>\n\n";
$COUNT=$COUNT+1;
}
?>
</table>


<p><? echo $COUNT; ?> total records listed.</p>

</body>
</html>