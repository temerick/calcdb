<html>
<head>
	<script type="text/javascript">
        var GB_ROOT_DIR = "./greybox/";
    </script>
    <link href="greybox/gb_styles.css" rel="stylesheet" type="text/css" media="all" />
</head>

<body>
	
	<script type="text/javascript" src="greybox/AJS.js"></script>
	<script type="text/javascript" src="greybox/AJS_fx.js"></script>
	<script type="text/javascript" src="greybox/gb_scripts.js"></script>
	
	<h3>Does this ajax script work?</h3>
	<a href='add_prob_form.php?uid=1' title='Edit' rel='gb_page_center[800, 500]'><img src='img/add.jpg'></a>

</body>
</html>