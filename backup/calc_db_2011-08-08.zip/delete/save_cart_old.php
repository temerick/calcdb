<?

include("connect.php");

/**
 * This function will save a cart into the database with the associated name. The entry in the database will be stored
 * as date;cart_name;uid_list
 */

function save_cart($cart_name,$uid_list) {
	$cart_to_use=0;
	
	$user_info=mysql_fetch_array(mysql_query("SELECT * FROM user_data WHERE username='".$_COOKIE['username']."'"));
	
	while(array_key_exists('save_cart_'.$cart_to_use,$user_info) && $user_info['save_cart_'.$cart_to_use]!="") {
		$cart_to_use++;
	}
	
	if(!array_key_exists('save_cart_'.$cart_to_use,$user_info)) { 
		mysql_query("ALTER TABLE user_data ADD save_cart_$cart_to_use LONGTEXT");
	}
	$date=date('m/d/Y');
	
	$query="UPDATE `user_data` SET `save_cart_$cart_to_use`='$date;$cart_name;$uid_list;No' WHERE `username`='".$_COOKIE['username']."'";
	$result=mysql_query($query);
}

if(array_key_exists("cartname",$_POST)) {
	$uids=implode(",",$_SESSION['mycart']);
	
	// This will change all of the semicolons in the cart name into commas. Hopefully that won't mess with people too much.
	$name=rawurldecode($_POST['cartname']);
	save_cart(str_replace(";",",",$name),$uids); 
}
?>

<? // Now to display the carts ?>
<center><h1>Your Saved Carts</h1>
<table width=75%><tr><td><b>Name</b></td><td><b>Date</b></td><td><b>Shared</b></td><td width=50px></td><td width=50px></td></tr>
	<?
	$user_array=mysql_fetch_array(mysql_query("SELECT * FROM user_data WHERE username='".$_COOKIE['username']."'"));
	// print_r($user_array);
	// echo "<br>";
	
	$n=0; // Run through the carts
	$cart_exists=false;
	while(array_key_exists("save_cart_".$n,$user_array)) {
		if($user_array['save_cart_'.$n]!="") {
			
			$cart_exists=true;
			$cart=explode(";",$user_array['save_cart_'.$n]);
			
			// If the cart doesn't specify whether it is shared, it probably isn't.
			if(!array_key_exists(4,$cart)) 
				$cart[4]="No";
			
			
			// If the cart's name is empty
			if($cart[1]=="") 
				$cart[1]="None.";
			
			echo "<tr><td>$cart[1]</td><td>$cart[0]</td><td>$cart[4]</td><td><a href='index.php?restore_cart=$cart[2]'>Restore</a></td><td><a href='edit_carts.php?cart=$n' onclick=\"return GB_showCenter('Add problem', this.href,200,330,function () { saved_carts();})\">Edit</a></td></tr>";
		}
		$n++;
	}
	?>
</table>
<? if(!$cart_exists) echo "<br>You don't have any saved carts. :("; ?>
</center>