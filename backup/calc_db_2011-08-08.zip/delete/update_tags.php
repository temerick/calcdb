<?
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // always modified
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0"); // HTTP/1.1
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache"); // HTTP/1.0

$fieldnameArray=split(",",$_GET['fieldname']);
$content=trim($_GET['content']);
//we get 2 vars: fieldname and content. so you get: $fieldname=$content;
//and we get the vars set in the function setVarsForm(vars). These could be used 
//to identify a user with sending userID=1 
//you also can use $_COOKIE['someID'] in the file.


//THIS UPDATES A DATABASE
//create DB connection

if($fieldnameArray[1]=="tags") { // Need to parse tags.

	$tagList=$content;
	$UID=$fieldnameArray[0];
	include("parseTags.php");

} else {
	
	if($content!="") { // Make sure people don't delete problems on accident
		$dbContent=addslashes($content);
		
		include("connect.php");
		
		$sql="UPDATE problems SET 
		$fieldnameArray[1]=\"$dbContent\"
		WHERE uid=\"$fieldnameArray[0]\";
		";
		
		if (!mysql_query($sql,$dbhandle)) {
		  die('Error: ' . mysql_error());
		}
		
		mysql_close($dbhandle);
	}
}


//OR

//THIS STARTS A FUNCTION
//if($_GET['fieldname'] == "userName")
//  setUserName($_GET['content']);
//if($_GET['fieldname'] == "userCity")
//  setUserCity($_GET['content']);
//
//

//OR


//THIS WRITES CONTENT TO A TEXT FILE
//$handle = fopen($_GET['fieldname'].".txt", "w+");
//fwrite($handle, stripslashes($_GET['content']));
//fclose($handle);

echo $content;//strip_tags(,"<br><p><img><a><br /><strong><em>");
?>