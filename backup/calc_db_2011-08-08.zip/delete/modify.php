<html>
<head>
<SCRIPT SRC="MathJax/MathJax.js"> 
  MathJax.Hub.Config({
    extensions: ["tex2jax.js"],
    jax: ["input/TeX","output/HTML-CSS"],
    tex2jax: {inlineMath: [["$","$"],["\\(","\\)"]]}
  });
</SCRIPT> 
</head>
<body>
<?
include("connect.php");
?>

<?
$UID=$_GET["uid"];
$result = mysql_query("SELECT * FROM problems WHERE uid=".$UID);
?>
<?
while ($row = mysql_fetch_array($result)) {
$add_prob=$row{'prob'};
$add_ans=$row{'answer'};
$add_type=$row{'type'};
$add_comment=$row{'comment'}; }
?>

<h3>Modify Problem #<? echo $UID; ?></h3>

<table>
<tr>
<td width=300px>Problem</td><td>Answer</td><td>Type</td><td>Comment</td></tr>
<tr>
<td>
<? echo $add_prob ?>
</td><td>
<? echo $add_ans ?>
</td><td>
<? echo $add_type ?>
</td><td>
<? echo $add_comment ?>
</td></tr>
</table>

<br><br><br>

<form action="modify_act.php" method="post">
<?
echo "<input type=\"hidden\" name=\"uid\" value=\"".$UID."\">";
include("add_prob_form.php"); 
?>
<input type="submit" value="Save" /> or <a href="query.php?col=<? echo $_GET['col']?>&amp;value=<? echo $_GET['value'] ?>">Go back</a>
</form>


<p>Or you can be a jerk and <a href="delete.php?uid=<?echo $UID; ?>">delete</a> this problem.</p>


</body>
</html>
