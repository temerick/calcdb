<?

include("connect.php");
include("functions.php");

echo (strpos(file_get_contents("http://artsandsciences.virginia.edu/mathematics/people/graduatestudents/index.html"),"<td> tre8a </td>"));

echo "<br /><br />".md5("abcdefgkljsdlkjalsjdklasjd asd aj dlkjsd adlkj asd lkjaskdj");

?>
