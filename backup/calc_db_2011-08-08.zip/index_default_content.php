<center>
<h2>Welcome to Calc DB. Select a search criterion.</h2>

<p><font size=+1 color=red>Warning:</font> This site is edited live on the server. Anything may explode at any time.

<p><font size=+1 color=red>Firefox:</font> Some versions of Firefox seem to render math extremely slowly. Try using <a href="http://www.google.com/chrome">Google Chrome</a> instead.


<?
if(!function_exists(tag_list)) {
	include("connect.php");
	include("functions.php");
}

$username=$_COOKIE['username'];

if($username=="tre8a" || $username=="svd5d") $experimental=true;

// if(!$experimental) $a_types = type_list(); This was when we were displaying the types. BLEH!

$a_tags = fast_tags();

// Get rid of unwanted tags.
$user_data=mysql_fetch_array(mysql_query("SELECT * FROM user_data WHERE username='$username'"));
$unwanted_tags=explode("%",$user_data['bad_tags']);
foreach($unwanted_tags as $tag) {
	$tag=trim(str_replace("not:","",$tag));
	unset($a_tags[$tag]);
}
?>

<p>&nbsp;
</center>

<table width=100% cellpadding="20px">
	<tr>
<? if($experimental): ?>
	<td width="60%" valign="top" bgcolor="gray">
		<center><h3>Screencast to go here</h3></center>
	</td>
<? endif; ?>
	<td valign="top">
<center>
<h3>Tags</h3>
<? print_tag_cloud($a_tags,"tags"); ?></center>
</td>
</tr>
</table>
<a href="javascript:help_out();" class="help_out">
<div role="button" class="help_out">Help out</div>
</a>
