<?
session_start();
echo count($_SESSION['mycart']);
?>
