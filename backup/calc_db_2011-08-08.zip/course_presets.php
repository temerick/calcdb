<?

$presets["Math 1210"]["gen_type"]="Functions,Derivatives,Limits,Derivative Applications,Integration,Integration Applications,Other";
$presets["Math 1210"]["not"]="not:trig,not:integration by parts,not:lhopital,not:hyperbolic trig,not:trig sub,not:partial fractions,not:long division,not:improper integral";

$presets["Math 1220"]["gen_type"]="Derivatives,Derivative Applications,Integration,Differential Equations,Integration Applications,Other,Multivariable Functions,Multivariable Integrals,Multivariable Derivatives,Probability,Sequences,Series,Power Series";
$presets["Math 1220"]["not"]="not:lhopital,not:hyperbolic trig,not:trig sub,not:partial fractions,not:long division,not:root test,not:limit comparison test";

$presets["Math 1310"]["gen_type"]="Functions,Derivatives,Limits,Derivative Applications,Integration,Integration Applications,Other";

$presets["Math 1320"]["gen_type"]="Integration,Parametric & Polar,Integration Applications,Other,Multivariable Functions,Multivariable Integrals,Sequences,Series,Power Series";
$presets["Math 1320"]["not"]="not:level curves";
?>