<html>
<body>

<? session_start(); print_r($_SESSION); ?>

<body>
</html>
