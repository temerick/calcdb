<? 

include("connect.php");
$username=$_COOKIE['username'];

?>
<div class="topbar">
<div class="left">
	<a href="javascript:close_everything_but('');home()"><img src="img/logo.png" alt="Calc|DB" height="26px" style="padding:2px;border-style:none;"></a>
</div>
<div class="left">
	<ul>
		<li class="block_float">Current course: 
		</li>
		<li class="block_float">
			<span id="list_of_current_course_options_top">
			<span id="current_selected_course">
			<a class="boxed_link" href="javascript:close_everything_but('list_of_current_course_options');visibility_toggle('list_of_current_course_options')">
			<?
			$person_prefs=mysql_fetch_array(mysql_query("SELECT * FROM user_data WHERE username='$username'"));
			if(!$person_prefs['current_course']) {
				echo "none.";
			} else {
				echo $person_prefs['current_course'];
			}
		
			?>
			</a>
			</span>
			</span>
			<div class="courses_pop_down" id="list_of_current_course_options" style="display:none;">
				<ul>
					<li class="block"><a class="boxed_link" href="javascript:change_current_course('Math 1210')">Math 1210</a></li>
					<li class="block"><a class="boxed_link" href="javascript:change_current_course('Math 1220')">Math 1220</a></li>
					<li class="block"><a class="boxed_link" href="javascript:change_current_course('Math 1310')">Math 1310</a></li>
					<li class="block"><a class="boxed_link" href="javascript:change_current_course('Math 1320')">Math 1320</a></li>
					<li class="block"><a class="boxed_link" href="javascript:change_current_course('Custom');list_tags();">Custom</a></li>
					<li class="block"><a class="boxed_link" href="javascript:change_current_course('')">none.</a></li>
				</ul>
			</div>
		</li>
		<li class="block_float"><span id="solutions_topbar"></span>Solutions 
		<?
			if($person_prefs['solution_pref']==0) { $value=""; }
			else { $value="checked"; }
			echo "<input type='checkbox' onclick='javascript:toggle_sol_disp_checkbox()' $value>";
		?>
		</li>
		<li class="block_float"><span id="tags_topbar"></span>Tags 
		<?
			if($person_prefs['tag_pref']==0) { $value=""; }
			else { $value="checked"; }
			echo "<input type='checkbox' onclick='javascript:toggle_tag_disp_checkbox()' $value>";
		?>
		</li>
	</ul>
</div>


<div class="right">
	<ul>
		<li class="block_float">
			<? include("search_box.php"); ?>
		</li>
		<li class="block_float">
			<a class="boxed_link" href="javascript:close_everything_but('');query_cart()">My Cart (<span id="cartcount"><? include("print_cart_count.php"); ?></span>)</a>
		</li>
		<li class="block_float">
			<a class="boxed_link" href="javascript:close_everything_but('cart_pop_down');visibility_toggle('cart_pop_down')">Carts</a>
		<div class="cart_pop_down" id="cart_pop_down" style="display:none;">
			<ul>
				<li class="block"><a class="boxed_link" href="javascript:saved_carts();visibility_toggle('cart_pop_down')">Saved Carts</a></li>
				<li class="block"><a class="boxed_link" href="javascript:shared_carts();visibility_toggle('cart_pop_down')">Shared Carts</a></li>
			</ul>
		</div>
		</li>
		<li class="block_float">
			<a class="boxed_link" href="javascript:close_everything_but('login_pop_down_options');visibility_toggle('login_pop_down_options')"><? echo $_COOKIE['username']; ?></a>
		<div class="login_pop_down" id="login_pop_down_options" style="display:none;">
			<ul>
				<li class="block"><a class="boxed_link" href="add_prob_form.php" title="Add problem" onclick="visibility_toggle('login_pop_down_options');return GB_showCenter('Add problem', this.href,550,720,function () { query_last();})">Add a problem</a></li>
				<li class="block"><a class="boxed_link" href="javascript:query_my_probs();visibility_toggle('login_pop_down_options')">My problems</a></li>
				<li class="block"><a class="boxed_link" href="javascript:user_info();visibility_toggle('login_pop_down_options')">Edit password</a></li>
				<li class="block"><a class="boxed_link" href="http://people.virginia.edu/~svd5d/db_test/login.php?do=drop">Logout</a></li>
			</ul>
		</div>
		</li>
	</ul>
</div>
</div>
