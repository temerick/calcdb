// function to display a query result in the content frame
// inputs are q_type (should be "tags" or "type") and q_value (the query)

function prob_query(q_type, q_value)
{
	alert("This should not have happend!");
/*
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"d_query"]); // re-renders page with MathJax
		}
	}
	

	
	// this stuff should probably be run through URIencode   +"&highlight="+highlight
	xmlhttp.open("GET","query.php?col="+q_type+"&value="+q_value,true); 
	xmlhttp.send();
	document.getElementById("d_query").innerHTML="Reticulating splines...";
*/
}




// This will be called from the search box. Currently, it only handles a single uid input, or a tag input.
function search_query(item) 
{
	
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"d_query"]); // re-renders page with MathJax
		}
	}
	
	if(!isNaN(parseInt(item))) {
		// If we have a number...
		xmlhttp.open("GET","query_uids.php?uids="+item); 
		xmlhttp.send();
		document.getElementById("d_query").innerHTML="Reticulating splines...";
	} else {
		// If we have a tag...
		xmlhttp.open("GET","query_tags.php?tags="+item); 
		xmlhttp.send();
		document.getElementById("d_query").innerHTML="Reticulating splines...";
	}
	
}


// the following are the various query functions

function query_tags(taglist)
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			window.last_query_type = "tags";
			window.last_query_value = taglist;
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"d_query"]); // re-renders page with MathJax
		}
	}
	
	xmlhttp.open("GET","query_tags.php?tags="+taglist); 
	xmlhttp.send();
	document.getElementById("d_query").innerHTML="Reticulating splines...";
}

function query_uids(uidlist)
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			window.last_query_type = "uids";
			window.last_query_value = uidlist;
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"d_query"]); // re-renders page with MathJax
		}
	}
	
	xmlhttp.open("GET","query_uids.php?uids="+uidlist); 
	xmlhttp.send();
	document.getElementById("d_query").innerHTML="Reticulating splines...";
}

function query_cart()
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			window.last_query_type = "cart";
			window.last_query_value = "";
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"d_query"]); // re-renders page with MathJax
		}
	}
	
	xmlhttp.open("GET","query_cart.php"); 
	xmlhttp.send();
	document.getElementById("d_query").innerHTML="Reticulating splines...";
}

function query_all()
{

}

function query_last()
{
	if (window.last_query_type == "tags")
	{
		query_tags(window.last_query_value);
	}
	else if (window.last_query_type == "uids")
	{
		query_uids(window.last_query_value);
	}
	else if (window.last_query_type == "cart")
	{
		query_cart();
	}
	else
	{
	
	}
}


// tag box functions
function load_tag_box(uid)
{

	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("tagarea"+uid).innerHTML=xmlhttp.responseText;
			document.getElementById('text'+uid).focus();
		}
	}
	
	xmlhttp.open("GET","tag_box.php?uid="+uid); 
	xmlhttp.send();
	document.getElementById("tagarea"+uid).innerHTML="Loading";
	
}

function add_tag(uid,tag)
{
	regex=/^[0-9a-zA-Z ,]+$/;
	if (regex.test(tag))
	{
		xmlhttp=new XMLHttpRequest();

		xmlhttp.onreadystatechange=function() { 
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				document.getElementById("taglist"+uid).innerHTML=xmlhttp.responseText;
			}
		}
		
		xmlhttp.open("GET","tag_problem.php?uid="+uid+"&tag="+tag);
		xmlhttp.send();
		document.getElementById("taglist"+uid).innerHTML="Loading";
		document.getElementById("text"+uid).value="";
	}
	else
	{
		alert("Only letters, numbers and spaces are allowed in tag names.");
	}
}



// function to add a problem to the cart by uid

function add_to_cart(uid)
{
	xmlhttp[uid]=new XMLHttpRequest();

	xmlhttp[uid].onreadystatechange=function() { 
		if (xmlhttp[uid].readyState==4 && xmlhttp[uid].status==200) {
			document.getElementById("button"+uid).innerHTML=xmlhttp[uid].responseText;
			update_cart_count();
		}
	}

	xmlhttp[uid].open("GET","addtocart.php?uid="+uid, true);
	xmlhttp[uid].send();
	document.getElementById("button"+uid).innerHTML="<img src='img/ajax-loader.gif'>"
}


// Shares or unshares a cart from the carts menus
function share_cart(cartnumber,personid) {
	xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange=function() {
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("cart"+cartnumber+"_"+personid).innerHTML=xmlhttp.responseText;
		}
	}
	
	xmlhttp.open("GET","cart_share.php?cart="+cartnumber+"&personid="+personid+"&change=true", true);
	xmlhttp.send();
}


// function that accepts multiple uids to add to cart, forcing each one and looping only on completion
// this prevents an overload of ajax requests all at once, which evidently is bad form, and also doesn't work.
function add_to_cart_bulk()
{
	var args = Array.prototype.slice.call(arguments);  

	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("button"+args[0]).innerHTML=xmlhttp.responseText;
			args.shift();
			if (args[0] !== undefined)
			{
				add_to_cart_bulk.apply(null, args); // continue the loop of adding problems to cart
			} else {
				update_cart_count(); // if there's nothing left, update the cart count.
			}
		}
	}

	xmlhttp.open("GET","addtocart.php?uid="+args[0]+"&force=true", true);
	xmlhttp.send();
	document.getElementById("button"+args[0]).innerHTML="<img src='img/ajax-loader.gif'>"

}



// function to update the cart count

function update_cart_count()
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("cartcount").innerHTML=xmlhttp.responseText;
		}
	}

	xmlhttp.open("GET","print_cart_count.php", true);
	xmlhttp.send();
}


// empty the cart
function empty_cart()
{
	ans=confirm("This action cannot be undone. Are you sure?");
	if (ans) {
		xmlhttp=new XMLHttpRequest();

		xmlhttp.onreadystatechange=function() { 
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				document.getElementById("d_query").innerHTML=xmlhttp.responseText;
				update_cart_count();
			}
		}

		xmlhttp.open("GET","empty_cart.php?header=emptycart", true);
		xmlhttp.send();
	}
}



// restore a cart
function restore_cart(uid_list)
{
	ans=confirm("This will replace your current cart. Do you wish to continue?");
	if (ans) {
		xmlhttp=new XMLHttpRequest();

		xmlhttp.onreadystatechange=function() { 
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				document.getElementById("d_query").innerHTML=xmlhttp.responseText;
				update_cart_count();
			}
		}

		xmlhttp.open("GET","index_restore_cart.php?restore_cart="+uid_list, true);
		xmlhttp.send();
	}
}


// function to toggle solution display

function toggle_sol_disp()
{
	xmlhttp_sol=new XMLHttpRequest();

	xmlhttp_sol.onreadystatechange=function() { 
		if (xmlhttp_sol.readyState==4 && xmlhttp_sol.status==200) {
			document.getElementById("sol_disp").innerHTML=xmlhttp_sol.responseText;
			query_last();
		}
	}

	xmlhttp_sol.open("GET","print_sol_disp_pref.php?toggle=true", true);
	xmlhttp_sol.send();
}

// function to toggle the display of solutions with the checkbox.

function toggle_sol_disp_checkbox()
{
	xmlhttp_sol=new XMLHttpRequest();

	xmlhttp_sol.onreadystatechange=function() { 
		if (xmlhttp_sol.readyState==4 && xmlhttp_sol.status==200) {
			document.getElementById("solutions_topbar").innerHTML=xmlhttp_sol.responseText;
			query_last();
		}
	}

	xmlhttp_sol.open("GET","toggle.php?q=solutions", true);
	xmlhttp_sol.send();
}


// function to toggle the display of tags with the checkbox.

function toggle_tag_disp_checkbox()
{
	xmlhttp_sol=new XMLHttpRequest();

	xmlhttp_sol.onreadystatechange=function() { 
		if (xmlhttp_sol.readyState==4 && xmlhttp_sol.status==200) {
			document.getElementById("tags_topbar").innerHTML=xmlhttp_sol.responseText;
			query_last();
		}
	}

	xmlhttp_sol.open("GET","toggle.php?q=tags", true);
	xmlhttp_sol.send();
}

// function to toggle tag display

function toggle_tag_disp()
{
	xmlhttp_sol=new XMLHttpRequest();

	xmlhttp_sol.onreadystatechange=function() { 
		if (xmlhttp_sol.readyState==4 && xmlhttp_sol.status==200) {
			document.getElementById("tag_disp").innerHTML=xmlhttp_sol.responseText;
			query_last();
		}
	}

	xmlhttp_sol.open("GET","print_tag_disp_pref.php?toggle=true", true);
	xmlhttp_sol.send();
}



// function to toggle preferences for a given tag

function toggle_tag_pref(tag)
{
	xmlhttp_sol=new XMLHttpRequest();

	xmlhttp_sol.onreadystatechange=function() { 
		if (xmlhttp_sol.readyState==4 && xmlhttp_sol.status==200) {
			document.getElementById("error_box").innerHTML=xmlhttp_sol.responseText;
		}
	}
	
	xmlhttp_sol.open("GET","toggle_tag_pref.php?tag="+encodeURIComponent(tag), true);
	xmlhttp_sol.send();
}


// show the tag preferences page

function list_tags()
{
	xmlhttp_add=new XMLHttpRequest();

	xmlhttp_add.onreadystatechange=function() { 
		if (xmlhttp_add.readyState==4 && xmlhttp_add.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp_add.responseText;
		}
	}

	xmlhttp_add.open("GET","list_tags.php", true);
	xmlhttp_add.send();
}

// show the help out page

function help_out()
{
	xmlhttp_add=new XMLHttpRequest();

	xmlhttp_add.onreadystatechange=function() { 
		if (xmlhttp_add.readyState==4 && xmlhttp_add.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp_add.responseText;
		}
	}

	xmlhttp_add.open("GET","help_out.php", true);
	xmlhttp_add.send();
}

// Show the home page

function home()
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
		}
	}

	xmlhttp.open("GET","index_default_content.php", true);
	xmlhttp.send();
	document.getElementById("d_query").innerHTML="Reticulating splines...";
}



// show the user info page

function user_info()
{
	xmlhttp_add=new XMLHttpRequest();

	xmlhttp_add.onreadystatechange=function() { 
		if (xmlhttp_add.readyState==4 && xmlhttp_add.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp_add.responseText;
		}
	}

	xmlhttp_add.open("GET","user_info.php", true);
	xmlhttp_add.send();
}

// show the saved carts page

function saved_carts()
{
	xmlhttp_add=new XMLHttpRequest();

	xmlhttp_add.onreadystatechange=function() { 
		if (xmlhttp_add.readyState==4 && xmlhttp_add.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp_add.responseText;
		}
	}

	xmlhttp_add.open("GET","save_cart.php", true);
	xmlhttp_add.send();
}

// show the shared carts page

function shared_carts()
{
	xmlhttp_add=new XMLHttpRequest();

	xmlhttp_add.onreadystatechange=function() { 
		if (xmlhttp_add.readyState==4 && xmlhttp_add.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp_add.responseText;
		}
	}

	xmlhttp_add.open("GET","shared_carts.php", true);
	xmlhttp_add.send();
}

// Saves a new password.
function save_new_pw()
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
		}
	}

	params=
		"oldpw="+encodeURIComponent(document.edit_pw.oldpw.value)
		+"&newpw1="+encodeURIComponent(document.edit_pw.newpw1.value)
		+"&newpw2="+encodeURIComponent(document.edit_pw.newpw2.value);
	xmlhttp.open("POST","user_info.php", true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length", params.length);
	xmlhttp.setRequestHeader("Connection", "close");
	xmlhttp.send(params);
}



function save_my_cart()
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
		}
	}

	params=
		"cartname="+encodeURIComponent(document.save_cart.cart_name.value);
	xmlhttp.open("POST","save_cart.php", true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-length", params.length);
	xmlhttp.setRequestHeader("Connection", "close");
	xmlhttp.send(params);
}


// allows people to change the course they are currently associated to
function change_current_course(course) {
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("current_selected_course").innerHTML=xmlhttp.responseText;
		}
	}
	
	close_everything_but('');
	
	xmlhttp.open("GET","change_current_course.php?course="+encodeURIComponent(course),true); 
	xmlhttp.send();
}


// play tag game!

function play_tag_game()
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"d_query"]); // re-renders page with MathJax
		}
	}

	xmlhttp.open("GET","tag_game.php",true); 
	xmlhttp.send();
	document.getElementById("d_query").innerHTML="Reticulating splines...";
}

function addTagRevert(uid) {
	document.getElementById("tagarea"+uid).innerHTML="<small>Tags:&nbsp;(<a class='xbutton' href=\"javascript:load_tag_box("+uid+")\">add&nbsp;tag</a>)</small>";
}

// This is only used on the "My carts" page at the moment...
function yesToNo(personid,cartnumber)
{
	if(document.getElementById( cartnumber+"_"+personid ).innerHTML=="Yes") {
		document.getElementById( cartnumber+"_"+personid ).innerHTML="No";
	} else {
		document.getElementById( cartnumber+"_"+personid ).innerHTML="Yes";
	}
}

function switchMenu(obj) {
	var el = document.getElementById(obj);
	if ( el.style.display != "none" ) {
		el.style.display = 'none';
	}
	else {
		el.style.display = '';
	}
}

function popup_image(filename) { // this doesn't seem to be working for the moment...
	window.open( "problem_images/"+filename, "myWindow", "status = 1, height = 300, width = 300, resizable = 0" );
}

function visibility_toggle(div) {
	var current=document.getElementById(div).style.display;
	if(current=="none") {
		document.getElementById(div).style.display="block";
	} else if(current=="block") {
		document.getElementById(div).style.display="none";
	} else {
		alert("Something went wrong."+current);
	}
}

// This closes all currently known divs except for a fixed one.
function close_everything_but(div) {
	if(div!="list_of_current_course_options") {
		document.getElementById('list_of_current_course_options').style.display="none";
	}
	if(div!="cart_pop_down") {
		document.getElementById('cart_pop_down').style.display="none";
	}
	if(div!="login_pop_down_options") {
		document.getElementById('login_pop_down_options').style.display="none";
	}
}


// More link for related.
function related_more_toggle() {
	if(document.getElementById('related_search').style.height=="60px") { // need to open.
		document.getElementById('related_search').style.height="auto";
		document.getElementById('related_search_more').innerHTML="<a href='javascript:related_more_toggle();' style='color: black; text-decoration: none;'>Less</a>";
		document.getElementById('related_search_more_td').vAlign="bottom";
	} else { // need to close.
		document.getElementById('related_search').style.height="60px";
		document.getElementById('related_search_more').innerHTML="<a href='javascript:related_more_toggle();' style='color: black; text-decoration: none;'>More</a>";
		document.getElementById('related_search_more_td').vAlign="top";
	}
}

// Query my problems.
function query_my_probs()
{
	xmlhttp_add=new XMLHttpRequest();

	xmlhttp_add.onreadystatechange=function() { 
		if (xmlhttp_add.readyState==4 && xmlhttp_add.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp_add.responseText;
		}
	}

	xmlhttp_add.open("GET","query_my_probs.php", true);
	xmlhttp_add.send();
}

