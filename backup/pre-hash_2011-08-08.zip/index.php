<?
ob_start("ob_gzhandler"); // Gzip should speed up website load times.

include("cookie_check.php");
include("connect.php");
include("cleanup/autoclean.php");
include("functions.php");

if($_COOKIE['username']=="tre8a" || $_COOKIE['username']=="svd5d") {
	$experimental=true;
} else {
	$experimental=false;
}

?>

<html class="main">
<head>
<title>Calculus Problem Database</title>

<link href="jquery/styles.css" rel="stylesheet" type="text/css" />
<link href="greybox/gb_styles.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<script type="text/javascript"> var GB_ROOT_DIR = "./greybox/"; </script>
<script type="text/javascript" src="greybox/AJS.js"></script>
<script type="text/javascript" src="greybox/AJS_fx.js"></script>
<script type="text/javascript" src="greybox/gb_scripts.js"></script>
<script type="text/javascript" src="jquery/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="jquery/jquery.autocomplete.js"></script>
<!--<script src="toggle.js" type="text/javascript"></script>-->
<script src="ajax_magic.js" type="text/javascript"></script>
<script type="text/javascript"
  src="https://d3eoax9i5htok0.cloudfront.net/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML">
   MathJax.Hub.Config({
      extensions: ["tex2jax.js"],
      jax: ["input/Tex","output/HTML-CSS"],
      tex2jax: {inlineMath: [["$","$"],["\\(","\\)"]]}
   });
</script>

<?

// old mathjaxs script:
// <SCRIPT SRC="MathJax/MathJax.js"> 
//  MathJax.Hub.Config({
//    extensions: ["tex2jax.js"],
//    jax: ["input/TeX","output/HTML-CSS"],
//    tex2jax: {inlineMath: [["$","$"],["\\(","\\)"]]}
//  });
// </SCRIPT> 

?>
  

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-24994476-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>
<body class="main">

<? if(true) include("topbar.php"); ?>

<?php

// $a_types = type_list();
// $a_tags = tag_list();

?>



<table width=100%>
<tr>
	
<? if(false): ?>

<td width=190 valign=top cellpadding=10px>
<a href="javascript:home()"><img border=0 src="img/logo.png"></a>

<? echo "<br />"; // include("search_box.php"); ?>

<h3><a href="javascript:query_cart()">Cart</a> (<span id="cartcount"><? include("print_cart_count.php"); ?></span>)</h3>

<h3><a href='javascript:saved_carts()'>My Carts</a></h3>
<h3><a href='javascript:shared_carts()'>Shared Carts</a></h3>

<!--<h3><a href="javascript:switchMenu('tag_list')">Tag List</a></h3>
<div id="tag_list" style="display:none">
<? // foreach($a_tags as $key => $value) { echo "<a href=\"javascript:query_tags('$key')\">$key</a> ($value)<br>"; } ?><br>
</div>



<h3><a href="javascript:switchMenu('type_list')">Type List</a></h3>
<div id="type_list" style="display:none">
<? // foreach($a_types as $key => $value) { echo "<a href=\"javascript:query_tags('type:$key')\">$key</a> ($value)<br>"; } ?><br>
</div> -->


<!-- seriously this is dumb <h3><a href="javascript:prob_query('all','')">All Probs</a></h3> -->

<h3><img src="img/add.jpg" width=15> <a href="add_prob_form.php" title="Add problem" onclick="return GB_showCenter('Add problem', this.href,550,720,function () { query_last();})">Add Prob</a></h3>

<p>Solutions: <span id="sol_disp"><? include("print_sol_disp_pref.php"); ?></span>
<br>Tags: <span id="tag_disp"><? include("print_tag_disp_pref.php"); ?></span>



<h3><a href="javascript:help_out()">Help Out!</a></h3>

<br><br><br>
<font size=-2>
<? if($experimental) {
	echo "<p><a href='debug_viewsession.php'>View $SESSION</a>\n<br><a href='debug_destroysession.php'>Destroy $SESSION</a></p>";
}
?>
<p>Logged in as <b><? echo $_COOKIE['username']; ?></b>
<br /><a href="javascript:user_info()">Edit</a> password.
<br /><a href="login.php?do=drop">Login</a> as another user.</p>
</font>

<font size=-1>
<p><a href="mailto:tre8a@virginia.edu">Email</a> the admins with problems or feature requests.</p>
</font>


</td>

<? endif; ?>
<td valign=top>
<span id="d_query">
</span> <? // end d_query span ?>

<? // select the content that goes here, based on GET
$cart=$_GET['restore_cart'];
if ($cart!=""):
?>
	<script type='text/javascript'>
	restore_cart("<? echo $cart; ?>");
	</script>
<? 
else:
?> 
	<script type='text/javascript'>
	home();
	</script>
<?
endif;
?>
</td>
</tr>
</table>
