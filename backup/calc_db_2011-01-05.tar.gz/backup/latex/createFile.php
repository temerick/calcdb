<?

// This file will build whichever file is in $whichPage. Options are "problems", "answers", or "hybrid".
// Also necessary is a "time".

$ourFileName = "temp/".session_id().$time."/".$whichPage.".tex";
$handle = fopen($ourFileName, 'w') or die("can't open file");


fwrite($handle,"\documentclass[letterpaper]{article}
\usepackage{amsmath, amsfonts, amsthm, graphicx, amssymb, textcomp, enumerate}
\usepackage[margin=.75in]{geometry}
\pagestyle{empty}
\begin{document}
\begin{enumerate}"); // Beginning of document

// OLD BEHAVIOR FOR FIRST VERSION OF SITE
//$listOfProbs=$_SESSION['sel_prob'];
//$arrayOfKeys=array_keys($listOfProbs);

// NEW BEHAVIOR. this assumes that the only latexing will be done from the cart.
$listOfProbs=$_SESSION['mycart'];
$arrayOfKeys=array_values($listOfProbs);


$end="";
foreach($arrayOfKeys as $key) { // Creating the query.
	$end=$end." OR uid='".$key."'";
}
$query="SELECT * FROM problems WHERE".substr($end,3)." ORDER BY type"; // This should only query for the things we want. Still not super efficient, but clean enough considering I couldn't come up with a better option. The substr function kills the leading "OR" that shouldn't be there.

$probs=mysql_query($query);

$n=0; // Number of types of problems.
$types=array(); // List of types of problems.

$needsFunctions=false;
$functionList=range('a','z'); // list of functions (i.e. a(x), b(x), ... ) Also, this is used to label the individual parts.
$currentFunction=0; // will run through the different functions.

while($result=mysql_fetch_array($probs)) {
		
	if ($types[$n-1]!=$result['type']) { // Deciding whether to start a new problem and add directions.
		if($n!=0) {
			fwrite($handle,"\n\t\end{enumerate}");
		}
			
		$types[$n]=$result['type'];
		$n+=1;
						
		$directions=mysql_fetch_array(mysql_query("SELECT * from directions WHERE type=\"$result[type]\""));
		fwrite($handle,"\n\n% Problem number ".$n."\n\item ".$directions['directions']); // Beginning of problem.
		$needsFunctions=$directions['boolean'];
		$currentFunction=0; // resetting function list.
			
		fwrite($handle,"\n\n\t\begin{enumerate}");
			
	}
	
	if($whichPage=="problems" || $whichPage=="hybrid") {
	
		$newProblem="";
		if ($needsFunctions) { // adding function names if necessary
			$newProblem="$".$functionList[$currentFunction]."(x)=".ltrim($result['prob']," $");
		} else {
			$newProblem=$result['prob'];
		} // ignoring function names if not necessary.
		
		fwrite($handle,"\n\n\t% Problem ".$n.$functionList[$currentFunction]."\n\n\t\item ".$newProblem);
		if($whichPage=="hybrid") {
			fwrite($handle," \\\\ \\textbf{Answer:} ".$result['answer']."\\\\");
		}
	}
	
	if($whichPage=="answers") {
		fwrite($handle,"\n\n\t% Answer to problem ".$n.$functionList[$currentFunction]."\n\t\item ".$result['answer']);
	}
	
	$currentFunction+=1;

}


fwrite($handle,"\n\t\end{enumerate}\n\n\end{enumerate}\n\end{document}");
fclose($handle);
?>
