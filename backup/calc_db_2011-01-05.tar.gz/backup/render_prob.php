<?
// This function is intended to render a single problem from the database.
// AS A ROW IN A PRE-EXISTING TABLE.
// To be used repeatedly in query.php and for previewing problems in add/edit/copy/delete/whatever dialogs
// The problem can be rendered with any of its components, depending on arguements passed.
// See below for the full list of possibilities (which are assumed false unless otherwise set to true).

function render_problem($rend)
{

include("connect.php");

$q_prob = mysql_query("SELECT * FROM problems WHERE uid=" . $rend['uid']);
$a_prob = mysql_fetch_array($q_prob);

$color="FFFFFF"; 
if($rend['color']) { // To bounce between colors for rows
	$color="CCFFFF";
}

//echo "<table bgcolor=" . $color . ">";
echo "<tr bgcolor=" . $color . "><td>"; 

echo "<table><tr>";
// cell containing up/down button
if ($rend["b_updown"]) {
	echo "<td><center>";
	echo "<img src='img/up.png'>";
	echo "<p>";
	echo "<img src='img/down.png'>";
	echo "</center></td>";
}

// cell containing add/remove button
echo "<td><center>"; 
if ($rend["b_addrem"]) {
	echo "<p><span id=\"button" . $rend['uid'] . "\">";
	sensitive_button($rend['uid']); // sensitive_button function is below
	echo "</span>";
}
// edit button
if ($rend["b_edit"]) echo "<p><img src='img/edit.png'><br>";

echo "</center></td>";
echo "</table>";



echo "</td><td>";

// cell containing the problem

// directions first
if ($rend["inst"]) {
	$prob_instructions = mysql_fetch_array(mysql_query("SELECT directions FROM directions WHERE type=\"". trim($a_prob["type"]) . "\""));
	echo $prob_instructions['directions'];
	echo "<br>"; }

// then the problem
if ($rend['prob'])
	echo $a_prob['prob'];
	echo "<br>";

// then the solution
if ($rend['sol'])
	echo "Answer: " . $a_prob['answer'];

echo "</td><td>";

// cell containing tags... all this code came from the old grabTabs.php

if ($rend['tags']) {
	$findConnections = mysql_query("SELECT tagid FROM probtags WHERE probid=".$rend['uid']);
	$tagList="";
	while($rowTwo=mysql_fetch_array($findConnections)) {
		$tag=mysql_fetch_array(mysql_query("SELECT tag FROM tags WHERE uid=".$rowTwo{'tagid'}));
		if($rowTwo{'tagid'}!=0) {
			$tagList=$tagList.", ".$tag{tag};
		}
	
	}
	$tagList=trim($tagList,","); // Throw away the extra comma at the end.
	echo "<span id=\"".$rend['uid'].",tags\" class=\"editText\">".$tagList."</span>";
	//echo $tagList;
}

echo "</td><td>";

// cell containing ... modify/copy buttons?


// finish off the table
echo "</td></tr>";
//echo "</table>";
}




// This function renders a button to add/remove problem from cart, depending on whether or not the problem is already in the cart.

function sensitive_button($uid)
{

if (in_array($uid,$_SESSION['mycart']))
	echo "<a href='javascript:add_to_cart(" . $uid. ")'><img src='img/rem.png'></a>";
else
	echo "<a href='javascript:add_to_cart(" . $uid. ")'><img src='img/add.png'></a>";


}

?>
