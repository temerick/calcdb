
<?php 
if (!function_exists('str_getcsv')) { 
    function str_getcsv($input, $delimiter = ',', $enclosure = '"', $escape = '\\', $eol = '\n') { 
        if (is_string($input) && !empty($input)) { 
            $output = array(); 
            $tmp    = preg_split("/".$eol."/",$input); 
            if (is_array($tmp) && !empty($tmp)) { 
                while (list($line_num, $line) = each($tmp)) { 
                    if (preg_match("/".$escape.$enclosure."/",$line)) { 
                        while ($strlen = strlen($line)) { 
                            $pos_delimiter       = strpos($line,$delimiter); 
                            $pos_enclosure_start = strpos($line,$enclosure); 
                            if ( 
                                is_int($pos_delimiter) && is_int($pos_enclosure_start) 
                                && ($pos_enclosure_start < $pos_delimiter) 
                                ) { 
                                $enclosed_str = substr($line,1); 
                                $pos_enclosure_end = strpos($enclosed_str,$enclosure); 
                                $enclosed_str = substr($enclosed_str,0,$pos_enclosure_end); 
                                $output[$line_num][] = $enclosed_str; 
                                $offset = $pos_enclosure_end+3; 
                            } else { 
                                if (empty($pos_delimiter) && empty($pos_enclosure_start)) { 
                                    $output[$line_num][] = substr($line,0); 
                                    $offset = strlen($line); 
                                } else { 
                                    $output[$line_num][] = substr($line,0,$pos_delimiter); 
                                    $offset = ( 
                                                !empty($pos_enclosure_start) 
                                                && ($pos_enclosure_start < $pos_delimiter) 
                                                ) 
                                                ?$pos_enclosure_start 
                                                :$pos_delimiter+1; 
                                } 
                            } 
                            $line = substr($line,$offset); 
                        } 
                    } else { 
                        $line = preg_split("/".$delimiter."/",$line); 
    
                        /* 
                         * Validating against pesky extra line breaks creating false rows. 
                         */ 
                        if (is_array($line) && !empty($line[0])) { 
                            $output[$line_num] = $line; 
                        }  
                    } 
                } 
                return $output; 
            } else { 
                return false; 
            } 
        } else { 
            return false; 
        } 
    } 
} 

include("connect.php");

$arrayOfTags=str_getcsv($_POST[bunchATags]);
$UID=$_POST[uid];

$nonexistent=array();
$n=0; // Number of elements in nonexistent.

foreach($arrayOfTags[0] as $value) {

	$value=strtolower(trim($value));
	$id=mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE tag=\"".$value."\""));
	$tagid=$id{'uid'};
	
	//echo "value: ".$value."<br>id: ".$id{'uid'}."<br>UID: ".$UID;
	
	settype($tagid,"int"); 
	settype($UID,"int"); // They were strings before this.
	
	if($tagid!=0) { // Ensure that the tag actually exists.
		$sql="INSERT INTO probtags (probid, tagid) VALUES ('$UID','$tagid')";
		
		if (!mysql_query($sql,$dbhandle)) {
  			die('Error: ' . mysql_error());
  		}
  		
	} else {
	
		$nonexistent[$n]=$value;
		$n=$n+1;
		
	}
	
	
}

if($n==0) {
	header('Location: ' . $_SERVER['HTTP_REFERER']);
} else {
	echo "The following tags do not currently exist in the database. Would you like to add them?<br><form action=\"createTags.php\" method=\"post\"><input type=\"hidden\" name=\"uid\" value=".$UID."><table>"; 
	
	foreach($nonexistent as $tag) {
		echo "<tr><td><input type=checkbox name=".$tag."></td><td>".$tag."</td></tr>";
	}
	echo "</table><input type=\"submit\" value=\"Tag 'em\"></form>";
}
//mysql_close($dbhandle);
?>