<?php
include("connect.php");

$prob = addslashes($_POST[prob]);
$answer = addslashes($_POST[answer]);
$type = addslashes($_POST[type]);
$comment = addslashes($_POST[comment]);

$sql="UPDATE problems SET 
prob=\"$prob\",
answer=\"$answer\",
type=\"$type\",
comment=\"$comment\"
WHERE uid=\"$_POST[uid]\";
";

if (!mysql_query($sql,$dbhandle))
  {
  die('Error: ' . mysql_error());
  }
header('Location: ' . $_SERVER['HTTP_REFERER']);


mysql_close($dbhandle)
?>
