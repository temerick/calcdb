<html>
<body>

<?php
include("connect.php");
include("strgetcsv.php");
?>

<?php
//execute the SQL query and return records
$FIELD=$_GET[col];
$VALUE=$_GET[value];
$result=array();

if ($VALUE=="all") {
	$probIds = mysql_query("SELECT * FROM problems");
	while ($row = mysql_fetch_array($probIds)) {
		$result[] = $row['uid'];
	}
} else if ($FIELD=="cart") {
	$result = $_SESSION['mycart'];

} else if ($FIELD=="tags") {
	$arrayOfTags=str_getcsv($VALUE);
	// print_r($arrayOfTags);
	foreach ($arrayOfTags[0] as $tag) {
		//echo $tag."; ";
		$tagid = mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE tag=\"$tag\""));
		//print_r($tagid);
		$probIds = mysql_query("SELECT * FROM probtags WHERE tagid=\"$tagid[uid]\"");
		while ($row = mysql_fetch_array($probIds)) {
			$result[]=$row['probid'];
		}
	}
} else {
	$QUERY="WHERE $FIELD=\"$VALUE\"";
	$problems = mysql_query("SELECT * FROM problems $QUERY");
	while ($row = mysql_fetch_array($problems)) {
		$result[] = $row['uid'];
	}
}

?>



<? //print the latex option box if this is the cart
if ($FIELD=="cart")
{
	echo "<h2>Your selected problems</h2>";
	echo "<center><h3><a href=\"javascript:switchMenu('latex_options')\">Download LaTeX</a></h3>";
	echo "<center><span id=\"latex_options\" style=\"display:none\">";
	include("latex.php");
	echo "</span></center>";
}
else
{
	echo "<h2>All problems tagged " . $VALUE. "</h2>";
}
?>


<table width=100% cellpadding="10" cellspacing="0">
<tr>
<td>Add/<br>Remove</td><td width=65%>Problem</td><td>Tags (click to edit)</td></tr>

<?
$COUNT=0;

include("render_prob.php");

foreach ($result as $UID) {

	// To bounce between colors for rows
	if($COUNT%2==0) { $color="1"; } else { $color = "0"; } 

	// for up/down buttons only in cart
	if ($FIELD=="cart") {$updown = "1"; } else { $updown = "0"; }

	$render_attributes = array(
		"uid" => "$UID",
		"b_updown" => $updown,
		"b_addrem" => "1",
		"b_edit" => "1",
		"ruid" => "0",
		"inst" => "1",
		"prob" => "1",
		"sol" => $_SESSION['sol_disp'],
		"type" => "0", 
		"tags" => "1", 
		"comment" => "0",
		"color" => $color );
	
	render_problem($render_attributes);

	$COUNT+=1;

}
?>

</table>

<p><? echo $COUNT; ?> problems found.</p>

</body>
</html>
