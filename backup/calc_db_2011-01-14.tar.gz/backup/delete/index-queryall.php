<html>
<head>
<SCRIPT SRC="MathJax/MathJax.js"> 
  MathJax.Hub.Config({
    extensions: ["tex2jax.js"],
    jax: ["input/TeX","output/HTML-CSS"],
    tex2jax: {inlineMath: [["$","$"],["\\(","\\)"]]}
  });
</SCRIPT> 
</head>
<body>

<?php
include("connect.php");
?>

<?php
//execute the SQL query and return records
$result = mysql_query("SELECT * FROM problems");
//fetch tha data from the database
?>

<table>
<tr>
<td>UID</td><td>Problem</td><td>Answer</td><td>Type</td><td>Comment</td></tr>

<?
$COUNT=0;
while ($row = mysql_fetch_array($result)) {
echo "<tr><td>".$row{'uid'}."</td>
<td>".$row{'prob'}." </td>
<td>".$row{'answer'}."</td>
<td> ".$row{'type'}." </td><td>".$row{'comment'}."</td>
<td><a href=\"modify.php?uid=".$row{'uid'}."\">Edit</a></td>
<td><a href=\"duplicate.php?uid=".$row{'uid'}."\">Dup</a></td>
</tr>\n\n";
$COUNT=$COUNT+1;
}
?>
</table>
<p><? echo $COUNT; ?> total records listed.</p>


<br><br><br>

<p>Add a problem, using full LaTeX markup:</p>

<form action="insert.php" method="post">
<? 
$add_prob="";
$add_ans="";
$add_type="";
$add_comment="";
include("add_prob_form.php"); 
?>
<input type="submit">
</form>


</body>
</html>
