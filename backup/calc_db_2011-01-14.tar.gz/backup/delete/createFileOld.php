<?

// This file will build whichever file is in $whichPage. Options are "problems", "answers", or "hybrid".
// Also necessary is a "time".

include("../functions.php");


$ourFileName = "temp/".session_id().$time."/".$whichPage.".tex";
$handle = fopen($ourFileName, 'w') or die("can't open file");


fwrite($handle,"\documentclass[letterpaper]{article}
\usepackage{amsmath, amsfonts, amsthm, graphicx, amssymb, textcomp, enumerate}
\usepackage[margin=.75in]{geometry}
\pagestyle{empty}
\begin{document}
\begin{enumerate}"); // Beginning of document

// OLD BEHAVIOR FOR FIRST VERSION OF SITE
//$listOfProbs=$_SESSION['sel_prob'];
//$arrayOfKeys=array_keys($listOfProbs);

// NEW BEHAVIOR. this assumes that the only latexing will be done from the cart.
$listOfProbs=$_SESSION['mycart'];
$arrayOfKeys=array_values($listOfProbs);

$type_list=type_list($arrayOfKeys);

$end="";
foreach($arrayOfKeys as $key) { // Creating the query.
	$end=$end." OR uid='".$key."'";
}
$query="SELECT * FROM problems WHERE".substr($end,3)." ORDER BY type"; // This should only query for the things we want. Still not super efficient, but clean enough considering I couldn't come up with a better option. The substr function kills the leading "OR" that shouldn't be there.

$probs=mysql_query($query);

$n=0; // Number of types of problems.
$types=array(); // List of types of problems.

// $needsFunctions=false;
$functionList=range('a','z'); // list of functions (i.e. a(x), b(x), ... ) Also, this is used to label the individual parts.
$currentFunction=0; // will run through the different functions.

while($result=mysql_fetch_array($probs)) {
	
	$item="\item "; // If there is only one problem of a given type, this will get changed. (See below.)
	
	if ($types[$n-1]!=$result['type']) { // Deciding whether to start a new problem and add directions.
		if($n!=0 && $type_list[$types[$n-1]]!=1) {
			fwrite($handle,"\n\t\end{enumerate}");
		}
			
		$types[$n]=$result['type'];
		$n+=1;
						
		$directions=mysql_fetch_array(mysql_query("SELECT * from directions WHERE type=\"$result[type]\""));
		fwrite($handle,"\n\n% Problem number ".$n."\n\item ".$directions['directions']); // Beginning of problem.
		
		
		$currentFunction=0; // resetting function list.
		
		if($type_list[$result['type']]!=1) {
			fwrite($handle,"\n\n\t\begin{enumerate}");
		} else {
			fwrite($handle,"\n\n");
			$item=""; // Told you so!
		}
	}
	
	// Problem number
	if($item=="") {
		$problem_number=$n;
	} else {
		$problem_number=$n.$functionList[$currentFunction];
	}
	
	if($whichPage=="problems" || $whichPage=="hybrid") {
	
		$newProblem=build_prob($result['uid'],$result['prob'],1,$functionList[$currentFunction]);
		
		fwrite($handle,"\n\n\t% Problem ".$n.$functionList[$currentFunction]."\n\n\t".$item.$newProblem);
		if($whichPage=="hybrid") {
			fwrite($handle," \\\\ \\textbf{Answer:} ".build_prob($result['uid'],$result['answer'],1,$functionList[$currentFunction])."\\\\");
		}
	}
	
	if($whichPage=="answers") {
		fwrite($handle,"\n\n\t% Answer to problem ".$n.$functionList[$currentFunction]."\n\t".$item.build_prob($result['uid'],$result['answer'],1,$functionList[$currentFunction]));
	}
	
	$currentFunction+=1;

}


fwrite($handle,"\n\t\end{enumerate}\n\n\end{enumerate}\n\end{document}");
fclose($handle);
?>
