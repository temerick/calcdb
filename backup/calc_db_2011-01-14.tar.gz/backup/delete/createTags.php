<?
include("connect.php");

$UID=$_POST['uid'];
$tagsToAdd=array_keys($_POST,"on");
foreach($tagsToAdd as $tag) {
	$value=strtolower(trim($tag));
 	$sql="INSERT INTO tags (tag) VALUES ('$value')";
 	
 	if (!mysql_query($sql,$dbhandle)) {
		die('Error: ' . mysql_error());
   	}
   	
	$id=mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE tag=\"".$value."\""));
	$tagid=$id{'uid'};
	echo "value: ".$value."<br>id: ".$id{'uid'}."<br>UID: ".$UID;
	settype($tagid,"int"); 
	settype($UID,"int"); // They were strings before this.
	if($tagid!=0) { // Ensure that the tag actually exists.
		$sql="INSERT INTO probtags (probid, tagid) VALUES ('$UID','$tagid')";
		
		if (!mysql_query($sql,$dbhandle)) {
  			die('Error: ' . mysql_error());
  		}
	}
	

}
mysql_close($dbhandle);
?>
<a href="http://people.virginia.edu/~svd5d/db_test/">Go back-ish</a>