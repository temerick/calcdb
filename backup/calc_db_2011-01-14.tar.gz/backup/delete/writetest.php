<?
$myFile = "testFile.txt";
$fh = fopen($myFile, 'w') or die("can't create file");
$stringData = "Floppy Jalopy\n";
fwrite($fh, $stringData);
$stringData = "Pointy Pinto\n";
fwrite($fh, $stringData);
fclose($fh);
?>
