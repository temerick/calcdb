<?

// This file will build whichever file is in $whichPage. Options are "problems", "answers", or "hybrid".
// Also necessary is a "time".

include("../functions.php");


$ourFileName = "temp/".session_id().$time."/".$whichPage.".tex";
$handle = fopen($ourFileName, 'w') or die("can't open file");


fwrite($handle,"\documentclass[letterpaper]{article}
\usepackage{amsmath, amsfonts, amsthm, graphicx, amssymb, textcomp, enumerate}
\usepackage[margin=.75in]{geometry}
\pagestyle{empty}
\begin{document}
\begin{enumerate}"); // Beginning of document

// OLD BEHAVIOR FOR FIRST VERSION OF SITE
//$listOfProbs=$_SESSION['sel_prob'];
//$arrayOfKeys=array_keys($listOfProbs);

// NEW BEHAVIOR. this assumes that the only latexing will be done from the cart.
$listOfProbs=$_SESSION['mycart'];
$arrayOfKeys=array_values($listOfProbs);

$type_list=type_list($arrayOfKeys);


// Creating the query.
$end="";
foreach($arrayOfKeys as $key) { 
	$end=$end." OR uid='".$key."'";
}


$query="SELECT * FROM problems WHERE".substr($end,3)." ORDER BY type"; // This should only query for the things we want. Still not super efficient, but clean enough considering I couldn't come up with a better option. The substr function kills the leading "OR" that shouldn't be there.

$probs=mysql_query($query);

$n=0; // Number of problems. (excluding individual parts. Can otherwise be thought about as number of types.)
$types=array(); // List of types of problems.


$functionList=range('a','z'); // list of functions (i.e. a(x), b(x), ... ) Also, this is used to label the individual parts. ("problem 1 part a", etc.)

$result=mysql_fetch_array($probs);

while($result!==false) { // This while loop will run through the list of problems.
	
	$currentFunction=0; // will run through the different functions.
	$n++; // add one to the problem number.
	
	// Fetch directions
	$directions=mysql_fetch_array(mysql_query("SELECT (directions) from directions WHERE type=\"$result[type]\"")); 
	
	// Create new problem and print directions.
	fwrite($handle,"\n\n% Problem number ".$n."\n\item ".$directions['directions']); 
	
	$types[$n]=$result['type'];
	
	// Only have parts if there are more than one of them.
	if($type_list[$types[$n]]!=1) {
		fwrite($handle,"\n\n\t\begin{enumerate}");
	}
	
	while($result['type']==$types[$n]) { // This while loop will run through the list of parts.
		
		// Print problems and hybrid.
		if($whichPage=="problems" || $whichPage=="hybrid") { 

			$newProblem=build_prob($result['uid'],$result['prob'],1,$functionList[$currentFunction]);
			
			// Now I need to distinguish between whether there is a single problem, or there are multiple problems.
			if ($type_list[$types[$n]]==1) { // The one-part case.
				fwrite($handle,"\n\n\t".$newProblem);
			} else { // The multi-part case.
				fwrite($handle,"\n\n\t% Problem ".$n.$functionList[$currentFunction]."\n\n\t\item ".$newProblem);
			}
			
			if($whichPage=="hybrid") {
				fwrite($handle," \\\\ \n \\textbf{Answer:} ".build_prob($result['uid'],$result['answer'],1,$functionList[$currentFunction])."\\\\");
			}
		}
		
		// Print answers.
		if($whichPage=="answers") {
			// Now I need to distinguish between whether there is a single problem, or there are multiple problems.
			$newAnswer=build_prob($result['uid'],$result['answer'],1,$functionList[$currentFunction]);
			if ($type_list[$types[$n]]==1) { // The one-part case.
				fwrite($handle,"\n\n\t".$newAnswer);
			} else { // The multi-part case.
				fwrite($handle,"\n\n\t% Answer to problem ".$n.$functionList[$currentFunction]."\n\n\t\item ".$newAnswer);
			}
		}
		
		$result=mysql_fetch_array($probs);
		$currentFunction++;
		
	}
	
	// Only have parts if there are more than one of them.
	if($type_list[$types[$n]]!=1) {
		fwrite($handle,"\n\n\t\end{enumerate}");
	}
}


fwrite($handle,"\n\n\end{enumerate}\n\end{document}");
fclose($handle);
?>
