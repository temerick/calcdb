<?php include("connect.php"); ?>

<html>
<body>
<? 

// Additional things to work on: 
// 1) maybe throw out a warning if there are too many parts (>26) in an individual problem. We could throw the parts into separate problems, but that seems inelegant. Besides, people should be notified of their bloodlust if they're throwing more than 26 problems of a single type at their students.
// 2) Something to think about: do we want to be able to make a "problem with solution" joint tex file? Maybe we should have different options for turning the answers / problems on and off separately.
// 3) The "email me" link isn't currently operational. It shouldn't be too hard to write an email handling file. However, I feel like it isn't too terribly important until we figure out how to get images working, where it'll become more of an issue anyway.
// 4) Since I got this .tex file thing figured out, I don't think it's all that necessary to display the code on this page. Maybe have a form for email instead?
// 5) Currently, these files and folders in the latex/temp folder will just keep building up mindlessly. Maybe set up something that will automatically delete things when they get too old. The timestamp is hidden in the folder name, after all... Just a thought.
// 5) This might be more tricky considering our current set up, but it would kind of nice to give people the ability to edit the order of parts in a given problem. Yeah, they could do it themselves in the tex file, but then they'd need to do it in the answers too.... and our current method for ordering problems will always produce the same order, which may not necessarily be the best order for students to get their problems in. Again, this is probably not something that we'd ever consider implementing due to the difficulty, but it's something I dream about.

$answers=$_GET['answers'];
if ($_GET['answers']=="enable") {
	$opposite="disable";
} else {
	$answers="disable";
	$opposite="enable";
}
?>


<table width=100%>

<tr><td><b>Currently viewing with answers <? echo $answers."d."; ?></b>
</td><td><a href="latex.php?answers=<? echo $opposite; ?>"><? echo $opposite." answers"?></a>
</td></tr>
<tr><td><a href="latex/email.php">Email me everything</a> (suggested for projects with pictures or multiple files).</td><td><a href="latex/texIt.php?p=<? echo $answers; ?>">Make the .tex</a></td></tr>

<tr><td>
<?

echo "\documentclass[letterpaper]{article} <br /><br />
\usepackage{amsmath, amsfonts, amsthm, graphicx, amssymb, textcomp, enumerate}
\usepackage[margin=.75in]{geometry}
<br />
\pagestyle{empty}
<br />
\begin{document}
<br />
\begin{enumerate}"; // Beginning of document.


$listOfProbs=$_SESSION['sel_prob'];
$arrayOfKeys=array_keys($listOfProbs);

$end="";
foreach($arrayOfKeys as $key) { // Creating the query.
	$end=$end." OR uid='".$key."'";
}
$query="SELECT * FROM problems WHERE".substr($end,3)." ORDER BY type"; // This should only query for the things we want. Still not super efficient, but clean enough considering I couldn't come up with a better option. The substr function kills the leading "OR" that shouldn't be there.

$probs=mysql_query($query);

$n=0; // Number of types of problems.
$types=array(); // List of types of problems.

$needsFunctions=false;
$functionList=range('a','z'); // list of functions (i.e. a(x), b(x), ... )
$currentFunction=0; // will run through the different functions.

while($result=mysql_fetch_array($probs)) {
		
	if ($types[$n-1]!=$result['type']) { // Deciding whether to start a new problem and add directions.
		if($n!=0) {
			echo "<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\end{enumerate}";
		}
			
		$types[$n]=$result['type'];
		$n+=1;
						
		$directions=mysql_fetch_array(mysql_query("SELECT * from directions WHERE type=\"$result[type]\""));
		echo "<br /><br />"."% Problem number ".$n."<br />\item ".$directions['directions']; // Beginning of problem.
		$needsFunctions=$directions['boolean'];
		$currentFunction=0; // resetting function list.
			
		echo "<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\begin{enumerate}";
			
	}
	
	if ($answers=="disable") {
		$functionName="$";
		if ($needsFunctions) {
			$functionName=$functionName.$functionList[$currentFunction]."(x)=";
		}
		echo "<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;% Problem ".$n.$functionList[$currentFunction]."<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\item ".$functionName.trim($result['prob']," $")."$"; // We kill the outside $'s and add them back in later. This was done so that the function name, if it exists, will be in the same math environment as the rest of the problem.
	}
	
	if ($answers=="enable") {
		echo "<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;% Problem ".$n.$functionList[$currentFunction]."<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\item ".$result['answer'];
	}
				
	
	$currentFunction+=1;

}


echo "<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\end{enumerate}<br /><br />\end{enumerate}<br />\end{document}";
?>
</td></tr>
</table>
</body>
</html>
