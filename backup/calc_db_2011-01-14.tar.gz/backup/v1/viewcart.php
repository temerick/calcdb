<html>
<head>
<SCRIPT SRC="MathJax/MathJax.js"> 
  MathJax.Hub.Config({
    extensions: ["tex2jax.js"],
    jax: ["input/TeX","output/HTML-CSS"],
    tex2jax: {inlineMath: [["$","$"],["\\(","\\)"]]}
  });
</SCRIPT> 
</head>
<body>

<?php
include("connect.php");
?>

<?php
$cartitems .=implode(",",$_SESSION['mycart']);
//echo $cartitems;

$result = mysql_query("SELECT * FROM problems WHERE uid IN ($cartitems)");
//fetch tha data from the database
?>

<h2>Your problem sack:</h2>

<form action="decide.php" method="post">

<table>
<tr>
<td>Act</td><td width=300px>Problem</td><td>Answer</td><td>Type</td><td>Comment</td></tr>

<?
$COUNT=0;
while ($row = mysql_fetch_array($result)) {
echo "<tr><td><input type=checkbox name=".$row{'uid'}."></td>
<td>".$row{'prob'}." </td>
<td>".$row{'answer'}."</td>
<td> ".$row{'type'}." </td><td>".$row{'comment'}."</td>
</tr>\n\n";
$COUNT=$COUNT+1;
}
?>
</table>
<p><? echo $COUNT; ?> total records listed.</p>

<br><br><br>

<a href="index.php">Back to main page</a>

</body>
</html>
