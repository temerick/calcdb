<?

// leaving it alone, but copying all of it to render_prob.php, so this file should not be needed in the future.


$findConnections = mysql_query("SELECT * FROM probtags WHERE probid=".$UID);
$tagList="";
while($rowTwo=mysql_fetch_array($findConnections)) {
	$tag=mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE uid=".$rowTwo{'tagid'}));
	if($rowTwo{'tagid'}!=0) {
		$tagList=$tagList.", ".$tag{tag};
	}
	
}
$tagList=trim($tagList,","); // Throw away the extra comma at the end.
?>
