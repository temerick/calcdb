<table>
<tr>
<td>
<p>Problem:<br><textarea rows="5" cols="35" name="prob"><? echo $add_prob; ?></textarea></p>
</td>
<td>
<p>Answer:<br><textarea rows="5" cols="35" name="answer"><? echo $add_ans; ?></textarea></p>
</td>
</tr>
<tr>
<td>
<p>Comment:<br><textarea rows="5" cols="35" name="comment"><? echo $add_comment; ?></textarea></p>
</td>
<td valign=top>
<p>Type:<br><textarea rows="1" cols="35" name="type"><? echo $add_type; ?></textarea></p>
</td>
</tr>
</table>
