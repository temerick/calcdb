<?
include("../connect.php");
include("../functions.php");

$whichPage=$_GET['p'];
$time=time();

if(!mkdir("./temp/".session_id().$time)) { // Make a directory to store all of this stuff in.
	echo "unable to create directory. :(";
}

if($whichPage=="zip") { // this will be used for zipping and downloading / emailing.
	
	if(array_key_exists("email",$_POST)) { // Determine integrity of email address.
		include("validEmail.php");
		if(!validEmail($_POST['emailAddress'])) { // Huh. For some reason this hangs when I enter in a crazy domain that doesn't exist. Better than it going through, but it would be nice if it picked up on that. I don't know enough about the script to debug it right now, though.
			
			header( 'Location: http://people.virginia.edu/~svd5d/db_test/latex.php?p=notvalid' ); // I can't get this to work as a relative path. i.e. I wanted to use ../latex.php?p=notvalid , but that didn't fly for some reason. :(
			// This non-relative path is something it'd be really nice to fix. I'm not entirely sure what's wrong. I was thinking about using the server referrer and just tacking on "?p=notvalid" at the end, but that would break if the user entered in a bad email address more than once. (You'd get "?p=notvalid?p=notvalid", which would error.)
			
		}
	}

	
	if(array_key_exists("problems",$_POST)) { // build "problems"
		build_tex("problems",$time); 
	}
	if(array_key_exists("answers",$_POST)) { // build "answers"
		build_tex("answers",$time);
	}
	if(array_key_exists("hybrid",$_POST)) { // build "hybrid"
		build_tex("hybrid",$time);
	}
	// Zip the files
	require ("pclzip.lib.php");
	$zipfile = new PclZip('temp/'.session_id().$time.'/packet.zip');
	
	$whatToDo="create"; // This is here because I don't know when I'm going to need to create the zip, or just add to it. Kind of annoying, but not too terrible.
	
	// This is kind of inefficient. I'm individually creating and adding to the zip. It would be nice if we just had it run through some sort of loop. Especially once we get images and we don't know how many files will be getting zipped up.
	
	if(array_key_exists("problems",$_POST)) { // add problems
		$v_list = $zipfile->create('temp/'.session_id().$time.'/problems.tex','','temp/'.session_id().$time); // This path will need to be adjusted appropriately for images. I'm leaving it alone for now, since we don't know how we're planning on handling them.
		
		if ($v_list == 0) { // error handling
			die ("Error: " . $zipfile->errorInfo(true));
		}
		$whatToDo="add";
	}
	
	if(array_key_exists("answers",$_POST)) { // add answers
		if ($whatToDo=="add") {
			$v_list = $zipfile->add('temp/'.session_id().$time.'/answers.tex','','temp/'.session_id().$time);
		} else {
			$v_list = $zipfile->create('temp/'.session_id().$time.'/answers.tex','','temp/'.session_id().$time);
			$whatToDo="add";
		}
		
		if ($v_list == 0) {
			die ("Error: " . $zipfile->errorInfo(true));
		}
	}
	
	if(array_key_exists("hybrid",$_POST)) { // add hybrid
		if ($whatToDo=="add") {
			$v_list = $zipfile->add('temp/'.session_id().$time.'/hybrid.tex','','temp/'.session_id().$time);
		} else {
			$v_list = $zipfile->create('temp/'.session_id().$time.'/hybrid.tex','','temp/'.session_id().$time);
			$whatToDo="add";
		}
		
		if ($v_list == 0) {
			die ("Error: " . $zipfile->errorInfo(true));
		}
	}
	
	if(array_key_exists("download",$_POST)) {  // Download.
		header( 'Location: temp/'.session_id().$time.'/packet.zip');
	}
	
	if(array_key_exists("email",$_POST)) { // Email.
		include("email.php");
	}
	
} else { // if p=problems, answers, or hybrid	
	build_tex($whichPage,$time);
	header( 'Location: temp/'.session_id().$time.'/'.$whichPage. '.tex' );
}

?>
