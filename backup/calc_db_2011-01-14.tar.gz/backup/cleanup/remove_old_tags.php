<?

include("../connect.php");


$query=mysql_query("SELECT * FROM probtags");

while($result=mysql_fetch_array($query)) {
	$problem=mysql_fetch_array(mysql_query("SELECT * FROM problems WHERE uid=$result[probid]"));
	if($problem==false) {
		echo "The probtag ";
		print_r($result);
		echo " has become obsolete has been deleted.<br />";
		mysql_query("DELETE FROM probtags where uid=$result[uid]");
	}
}

echo "done.";


?>