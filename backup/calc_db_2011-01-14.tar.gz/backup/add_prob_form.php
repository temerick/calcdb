<SCRIPT SRC="MathJax/MathJax.js"> 
  MathJax.Hub.Config({
    extensions: ["tex2jax.js"],
    jax: ["input/TeX","output/HTML-CSS"],
    tex2jax: {inlineMath: [["$","$"],["\\(","\\)"]]}
  });
</SCRIPT> 
<script src="ajax_magic.js" type="text/javascript"></script>
<script src="add_prob_java.js" type="text/javascript"></script>
<script src="toggle.js" type="text/javascript"></script>

<?

// this page exists as a separate html page, loaded in a frame via greybox.
// if we ever decide to load it via an invisible div in index.php, all of these includes and scripts will be unnecessary and probably create errors.

include("connect.php");
include("functions.php");

unset($_SESSION['last_action']);
unset($_SESSION['last_modified_uid']);
unset($_SESSION['last_modified_type']);

if (isset($_GET["uid"]))
{
	$edit_uid = $_GET["uid"];
} 
else {
	$edit_uid = "new";
}


if ($edit_uid != "new")
{
	$q_prob = mysql_query("SELECT * FROM problems WHERE uid=" . $edit_uid);
	$a_prob = mysql_fetch_array($q_prob);
	$add_prob = $a_prob['prob'];
	$add_ans = $a_prob['answer'];
	$add_type = $a_prob['type'];
}

?>



<table width=100%>
<tr>
<td><font size=+1><b>Problem Preview</b></font> <small><? if($edit_uid!="new") echo "(Editing problem - UID ".$edit_uid.")"; else echo "(Creating new problem)"; ?></small></td></tr>

<tr>
	<td colspan=2>
	<hr>

	<form name="add_type_select">
	<p>Directions: 

	<select name="type" id="type_box" onchange="javascript:boxes_changed();javascript:directions_changed();" onkeyup="javascript:boxes_changed();javascript:directions_changed();">
	<? 

	// construct an array of directions (the actual directions!)
	$a_types = array();
	$q_types = mysql_query("SELECT type, directions FROM directions");
	while ($row = mysql_fetch_array($q_types)) {
		$trimdirections = trim($row{'directions'});
		$trimtype = trim($row{'type'});
		if (!$trimdirections) $trimdirections="$trimtype (no direction text)";	// if the directions are blank, give a little hint
		if (!in_array($trimtype, $a_types)) {
			$a_types[$trimdirections]=$trimtype;
		}
	}

	print_r($a_types);

	// attempt to guess what directions should be selected by default
	if (isset($add_type)) // choice is obvious if we're editing
	{
		$desired_type = $add_type;
	} elseif(isset($_SESSION['last_modified_type'])) {  // if a problem was previously created or modified, go with that type
		$desired_type = $_SESSION['last_modified_type'];
	} elseif(isset($_SESSION['last_value'])) { // last chance: was a type search just done?
		$last_tags = explode(",",$_SESSION['last_value']);
		foreach($last_tags as $value) {
			if (substr_count($value, "type:") > 0)
			{
				$desired_type = str_replace("type:","",$value);
			}
		}
	}
	

	// print the select box of directions
	foreach ($a_types as $key => $value)
	{
		if ($value == $desired_type) { $sel = "selected"; } else { $sel = ""; }		// determining which to select by default
		echo "<option $sel value=\"$value\">$key</option>";
	}
	?>
	<option value="create_new_type">New...</option>
	</select>
	</form>
	</p>

	</td>
	<td>
	<span id="new_type_span"></span>
	</td>
	</tr>

<td>

<span id="prob_preview">
<?
if ($edit_uid != "new")
{
	$render_attributes = array(
		"uid" => $edit_uid,
		"inst" => "0",
		"prob" => "1",
		"sol" => "1",
		"type" => "1",
		"color" => "3",
		"preview" => "1");

	echo "<table width=100%>";			// this whole block is balls. this is run once, when a problem is edited.
	render_problem($render_attributes);	// after that, render_prob_frontend is used. stupid stupid stupid
	echo "</table>";

}
else
{
	echo "Type the LaTeX code for your problem in the boxes below, then click Preview.<br><br>";
}

?>
</span>

<hr>

</td>
</tr>
<tr>
<td>
<span id="add_boxes">
	<form id="add_prob" name="add_prob">
	<table>
	<tr>
	<td>
	<p>Problem:<br><textarea rows="5" cols="35" id="prob_box" name="prob" onchange="javascript:boxes_changed()" onkeyup="javascript:boxes_changed()"><? echo $add_prob; ?></textarea></p>
	</td>
	<td>
	<p>Answer:<br><textarea rows="5" cols="35" id="answer_box" name="answer" onchange="javascript:boxes_changed()" onkeyup="javascript:boxes_changed()"><? echo $add_ans; ?></textarea></p>
	</td>
	</tr>
	<tr>
	<td colspan=2>
	<small><a href="javascript:switchMenu('p_format_notes')">Show formatting notes</a></small>
	</td>
	</tr>
	</table>
	</form>
</span>
</td>
</tr>
<tr>
<td>
<hr>
<center>
<span id="add_controls">

<? if($edit_uid == "new") { $save_button = "hidden"; } else { $save_button = "button"; } ?>

<input type="button" id="add_preview" onclick="javascript:add_form_preview('<? echo $edit_uid; ?>')" value="Preview" DISABLED>

<input type="<? echo $save_button; ?>" id="add_revert" onclick="javascript:add_form_revert('<? echo $edit_uid; ?>')" value="Revert" DISABLED>

<? // disabling this functionality for now. perhaps we'll have it never come back. ?>
<input type="hidden" id="add_copy" onclick="javascript:add_form_copy_to_cart()" value="Copy to Cart" DISABLED>


<input type="<? echo $save_button; ?>" id="add_save" onclick="javascript:add_form_save_to_db('<? echo $edit_uid; ?>')" value="Save to DB" DISABLED>

<input type=button id="add_add" onclick="javascript:add_form_add_to_db('<? echo $edit_uid; ?>')" value="Add to DB" DISABLED>

<input type="<? echo $save_button; ?>" id="add_delete" onclick="javascript:add_form_delete_from_db('<? echo $edit_uid; ?>')" value="Delete from DB">

<p><small><a href="javascript:switchMenu('p_explain')">Explain these buttons</a></small></p>

</span>
</center>
<hr>
</td>
</tr>
<tr>
<td>
<span  id="p_format_notes" style="display:none">
<p  class="tex2jax_ignore">Formatting instructions: 
<ul>
<li>Use full LaTeX markup, using $'s as appropriate. Do not use $$ -- use \[ and \] instead. Do not use \displaystyle.</li>
<li>Type [[f]] for a random function name.</li>
<li>Type [[IMAGE]] to include an image at that location. Images can only be uploaded once the problem has been saved to the database. Use the (Add Image) links.</li>
</ul>
<br /></p>
</span>

<span  id="p_explain" style="display:none">
<p>Button explaination:
<ul>
<li>You must <b>preview</b> your changes before any other action is taken!</li>
<? if ($edit_uid != "new") echo "<li><b>Revert</b> returns the problem to its original state.</li>"; ?>
<? //<li><b>Copy to Cart</b> puts this problem in your cart, but does not alter the database at all. If you close your browser window, the problem will be lost.</li> ?>
<? if ($edit_uid != "new") echo "<li><b>Save to DB</b> alters the problem in the database for everyone to see. Use this if you found an error in the problem.</li>"; ?>
<li><b>Add to DB</b> adds the problem to the database as a new problem<? if ($edit_uid != "new") echo ", leaving the original problem unaltered. Use this to add new problems using an existing problem as a template"?>.</li>
<? if ($edit_uid != "new") echo "<li><b>Delete from DB</b> deletes the problem from the database. This cannot be undone."; ?></li>
</ul>
</span>
</td>
</tr>
</table>
