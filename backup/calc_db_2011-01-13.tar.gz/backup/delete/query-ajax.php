<html>
<head>

</head>
<body>

<?php
include("connect.php");
?>

<?php
$result = mysql_query("SELECT * FROM problems where uid=278");
//fetch tha data from the database
?>

<h2>Ajax test</h2>

<table>
<tr>
<td>Act</td><td width=300px>Problem</td><td>Answer</td><td>Type</td><td>Comment</td></tr>

<?
$COUNT=0;
$row = mysql_fetch_array($result);
echo "<tr><td><input type=checkbox name=".$row{'uid'}."></td>
<td>".$row{'prob'}." </td>
<td>".$row{'answer'}."</td>
<td> ".$row{'type'}." </td><td>".$row{'comment'}."</td>
<td><a href=\"modify.php?uid=".$row{'uid'}."&col=$FIELD&value=$VALUE\">Edit</a></td>
<td><a href=\"duplicate.php?uid=".$row{'uid'}."\">Dup</a></td>
</tr>\n\n";
?>
</table>


</body>
</html>
