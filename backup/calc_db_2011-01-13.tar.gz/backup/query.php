
<?
include("connect.php");
include("functions.php");

$FIELD=$_GET['col'];
$VALUE=$_GET['value'];

//echo "field is $FIELD<br>";
//echo $_SESSION['last_modified_uid'];

// this block is for the special case of "most_recent_change", whose UID is stored in $_SESSION
// 
if ($FIELD=="most_recent_change") {
	$_GET['highlight'] = $_SESSION['last_modified_uid'];

	if (isset($_SESSION['last_action']) && $_SESSION['last_action'] == "insert")
	{	// if the last action was a new problem creation, query for that problem's type
		$FIELD="type";
		$VALUE=$_SESSION['last_modified_type'];
	} else { // if the last action was a delete or update or is not defined, just repeat the last query
		$FIELD="last_query";
	}
}

// when solution display is toggled, or we finish adding/modifying a problem, use prob_query("last_query") to refresh the search panel. this next block deals with that. query is stored in SESSION. also uses last query if no $FIELD is provided.
if (!isset($FIELD) || $FIELD=="last_query" || $FIELD=="") 
{
	if ($_SESSION['last_col'])
	{
		$FIELD = $_SESSION['last_col'];
		$VALUE = $_SESSION['last_value'];
	} else {
		echo "Select a search criterion.";
		die;
	}
} else {
	$_SESSION['last_col'] = $FIELD;
	$_SESSION['last_value'] = $VALUE;
}


// at the end of this block, $result should be an array of problems to be rendered.
// $FIELD can have special values "all", "cart", and "tags"
$t_result=array();
if ($FIELD=="all") {		// returning all problems
	$probIds = mysql_query("SELECT * FROM problems");
	while ($row = mysql_fetch_array($probIds)) {
		$t_result[] = $row['uid'];
	}
} else if ($FIELD=="cart") {		// returning problems in the cart
	$t_result = $_SESSION['mycart'];

} else if ($FIELD=="tags") {		// returning all problems matching a particular tag
	$arrayOfTags=str_getcsv($VALUE);

	foreach ($arrayOfTags[0] as $tag) {
		$tagid = mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE tag=\"$tag\""));
		$probIds = mysql_query("SELECT * FROM probtags WHERE tagid=\"$tagid[uid]\"");
		while ($row = mysql_fetch_array($probIds)) {
			$t_result[]=$row['probid'];
		}
	}
} else {		// something else that looks kind of dangerous, although i guess the "type" query uses this block
	$QUERY="WHERE $FIELD=\"$VALUE\"";
	$problems = mysql_query("SELECT * FROM problems $QUERY");
	while ($row = mysql_fetch_array($problems)) {
		$t_result[] = $row['uid'];
	}
}


// this could probably be done more elegantly in the above,
// but i want to convert the above array which is "dummy#" => "uid"
// to an array which carries types, i.e. "uid" => "type"

//$t_result = array_diff($t_result,array("0"));    // this is a hack to fix a deeper problem which should be resolved instead

$uid_string = implode(",", $t_result);

$type_query = mysql_query("SELECT uid,type FROM problems WHERE uid IN (".$uid_string.");");

$result=array();
foreach($t_result as $stupid => $uid)
{
	$temp_type = mysql_fetch_array($type_query);
	$result[$temp_type['uid']] = $temp_type['type'];
}


 //print the latex option box if this is the cart
if ($FIELD=="cart")
{
	echo "<h2>Your selected problems</h2>";
	echo "<center><h3><a href=\"javascript:switchMenu('latex_options')\">Download LaTeX</a></h3>";
	echo "<span id=\"latex_options\" style=\"display:none\">";
	include("latex.php");
	echo "</span></center>";
}
else
{
	echo "<h3>All problems matching $VALUE.</h3>";
	// echo "(" . sizeof($result) . " problems found.)";

	// the cart should respect the order of 'mycart' array, but if we're just querying problems, let's sort them by type
	asort($result);
}
?>


<table width=100% cellpadding="10" cellspacing="0" border=0>
<tr>
<!-- <td>Add/<br>Remove</td><td width=65%>Problem</td><td>Tags (click to edit)</td></tr> -->

<?
$COUNT=0;

$last_type_rendered = "";

foreach ($result as $UID => $prob_type) {
	
	if ($prob_type != $last_type_rendered) { // block determining if a new type set is starting
		$prob_instructions = mysql_fetch_array(mysql_query("SELECT directions FROM directions WHERE type=\"". $prob_type . "\""));
		echo "<tr bgcolor=white><td></td></tr><tr bgcolor=lightblue><td valign=center colspan=6><h4>".$prob_instructions['directions']."</h4></td></tr>";
		$last_type_rendered = $prob_type;
	}
	
	// To bounce between colors for rows
	$color=($COUNT +1)%2;
	if ($_GET['highlight'] == $UID) { $color = "2"; }

	// for up/down buttons only in cart
	if ($FIELD=="cart") {$updown = "1"; } else { $updown = "0"; }

	$render_attributes = array(
		"uid" => "$UID",
		"b_updown" => $updown,
		"b_addrem" => "1",
		"b_edit" => "1",
		"inst" => "0",
		"prob" => "1",
		"sol" => $_SESSION['sol_disp'],
		"tags" => $_SESSION['tag_disp'], 
		"color" => $color );
	
	//echo "rendering" . $UID;

	render_problem($render_attributes);

	$COUNT+=1;

}


?>

</table>

</body>
</html>
