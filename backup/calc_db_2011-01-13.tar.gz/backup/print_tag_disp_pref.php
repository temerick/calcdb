<?
session_start();

if (!isset($_SESSION['tag_disp'])) $_SESSION['tag_disp'] = 1;
if ($_GET['toggle']) $_SESSION['tag_disp'] = !($_SESSION['tag_disp']);

echo "<a href=\"javascript:toggle_tag_disp()\">";

if ($_SESSION['tag_disp'])
	echo "shown";
else
	echo "hidden";

echo "</a>";

?>
