<html>
<head>
<?
if($_GET[edit]==1) {
echo "<script type=\"text/javascript\" src=\"instantedit.js\"></script>";
} else {
echo "<SCRIPT SRC=\"MathJax/MathJax.js\"> 
  MathJax.Hub.Config({
    extensions: [\"tex2jax.js\"],
    jax: [\"input/TeX\",\"output/HTML-CSS\"],
    tex2jax: {inlineMath: [[\"$\",\"$\"],[\"\\\\(\",\"\\\\)\"]]}
  });
</SCRIPT>"; 
}
?> 

<script language="javascript">
function checkAll(){
	for (var i=0;i<document.forms[0].elements.length;i++)
	{
		var e=document.forms[0].elements[i];
		if ((e.name != 'allbox') && (e.type=='checkbox'))
		{
			e.checked=document.forms[0].allbox.checked;
		}
	}
}
</script>
</head>
<body>

<?php
include("connect.php");
include("strgetcsv.php");
?>

<?php
//execute the SQL query and return records
$FIELD=$_GET[col];
$VALUE=$_GET[value];
$result=array();

if ($VALUE=="all") {
	$probIds = mysql_query("SELECT * FROM problems");
	while ($row = mysql_fetch_array($probIds)) {
		$result[] = $row['uid'];
	}
} else if ($FIELD=="tags") {
	$arrayOfTags=str_getcsv($VALUE);
	// print_r($arrayOfTags);
	foreach ($arrayOfTags[0] as $tag) {
		//echo $tag."; ";
		$tagid = mysql_fetch_array(mysql_query("SELECT * FROM tags WHERE tag=\"$tag\""));
		//print_r($tagid);
		$probIds = mysql_query("SELECT * FROM probtags WHERE tagid=\"$tagid[uid]\"");
		while ($row = mysql_fetch_array($probIds)) {
			$result[]=$row['probid'];
		}
	}
} else {
	$QUERY="WHERE $FIELD=\"$VALUE\"";
	$problems = mysql_query("SELECT * FROM problems $QUERY");
	while ($row = mysql_fetch_array($problems)) {
		$result[] = $row['uid'];
	}
}

//print_r($result); this just proves the result is not a real array :(
//fetch the data from the database
?>

<h2>All problems tagged "<? echo $VALUE; ?>"</h2>

<form action="decide.php" method="post">

<table width=100% cellpadding="10" cellspacing="0">
<tr>
<td>Act</td><td width=65%>Problem</td><? if($_GET['edit']==1) { echo "<td>Answer</td>"; } ?><!--<td>Comment</td>--><td>Tags</td></tr>

<?
$COUNT=0;
// while ($row = mysql_fetch_array($result)) {

foreach ($result as $UID) {

include("grabTags.php");

if($tagList=="" && $_GET[edit]==1) {
	$tagList="None.";
}

$row = mysql_fetch_array(mysql_query("SELECT * FROM problems WHERE uid=\"$UID\""));
$type=trim($row['type']);

$directionData = mysql_fetch_array(mysql_query("SELECT * FROM directions where type=\"$type\""));

// display table.

$color="FFFFFF"; 
if($COUNT%2==0) { // To bounce between colors for rows
	$color="CCFFFF";
}

echo "<tr bgcolor=\"".$color."\"><td><input type=checkbox name=".$row['uid']."></td> 
<td>".$directionData['directions']."<br /><br /><center><span id=\"".$UID.",prob\" class=\"editText\">".$row['prob']."</span></center></td>";

if($_GET['edit']==1) {
	echo "<td><span id=\"".$UID.",answer\" class=\"editText\">".$row['answer']."</span></td>";
}
echo "<!--<td>".$row['comment']."</td>--><td><span id=\"".$UID.",tags\" class=\"editText\">".$tagList."</span></td>
<!--<td><a href=\"duplicate.php?uid=".$row['uid']."\">Dup</a></td>-->
</tr>\n\n";
$COUNT+=1;

}
?>
<tr<? if($COUNT%2==0) {echo " bgcolor=\"CCFFFF\"";}?>><td><input type="checkbox" name="allbox" onclick="checkAll();"/></td><td>Check all</td><td></td></tr></table>
<p><? echo $COUNT; ?> total records listed.</p>

<? 
	if($_GET[edit]==1) { // in edit mode, add "batch tag" and "delete" options.
		echo "<p>Batch add tags here: <br><textarea rows=\"1\" cols=\"40\" name=\"type\"></textarea><br><input type=\"submit\" name=\"tag\" value=\"Tag 'em\"></p><p>Alternatively, you can <input type=\"submit\" name=\"delete\" value=\"Delete Selected\"></p>";
	} else { // only add nice buttons in non-edit mode.
		echo "<p>Add selected problems to your satchel <input type=\"submit\" name=\"addcart\" value=\"Bag 'em\"></p><p>Generate LaTeX code for selected problems <input type=\"submit\" name=\"latex\" value=\"Break it down yall\"></p>";
	}
?>

<br><br>
<table width=100%><tr><td>
<a href="index.php">Back to main page</a></td><td>
<p align="right">
<?
// Determine whether this is an editing situation or not.
if($_GET[edit]==1) {
	echo "<a href=\"query.php?col=".$_GET[col]."&value=".$_GET[value]."\">Back to pretty math!</a>";
} else {
	echo "<a href=\"query.php?col=".$_GET[col]."&value=".$_GET[value]."&edit=1\">Edit these problems</a>";
}
?>
</td></tr></table>
</body>
</html>
