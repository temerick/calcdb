// function to display a query result in the content frame
// inputs are q_type (should be "tags" or "type") and q_value (the query)

function prob_query(q_type, q_value)
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("d_query").innerHTML=xmlhttp.responseText;
			MathJax.Hub.Queue(["Typeset",MathJax.Hub,"d_query"]); // re-renders page with MathJax
			editbox_init(); // re-initialize instantedit; needs to be done on every query.
		}
	}

	// this stuff should probably be run through URIencode   +"&highlight="+highlight
	xmlhttp.open("GET","query.php?col="+q_type+"&value="+q_value,true); 
	xmlhttp.send();
	document.getElementById("d_query").innerHTML="Reticulating splines...";
}



// function to add a problem to the cart by uid

function add_to_cart(uid)
{
	xmlhttp_add=new XMLHttpRequest();

	xmlhttp_add.onreadystatechange=function() { 
		if (xmlhttp_add.readyState==4 && xmlhttp_add.status==200) {
			document.getElementById("button"+uid).innerHTML=xmlhttp_add.responseText;
			update_cart_count();
		}
	}

	xmlhttp_add.open("GET","addtocart.php?uid="+uid, true);
	xmlhttp_add.send();
}


// function to update the cart count

function update_cart_count()
{
	xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() { 
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			document.getElementById("cartcount").innerHTML=xmlhttp.responseText;
		}
	}

	xmlhttp.open("GET","print_cart_count.php", true);
	xmlhttp.send();
}



// function to toggle solution display

function toggle_sol_disp()
{
	xmlhttp_sol=new XMLHttpRequest();

	xmlhttp_sol.onreadystatechange=function() { 
		if (xmlhttp_sol.readyState==4 && xmlhttp_sol.status==200) {
			document.getElementById("sol_disp").innerHTML=xmlhttp_sol.responseText;
			prob_query("last_query","");
		}
	}

	xmlhttp_sol.open("GET","print_sol_disp_pref.php?toggle=true", true);
	xmlhttp_sol.send();
}



// function to tag solution display

function toggle_tag_disp()
{
	xmlhttp_sol=new XMLHttpRequest();

	xmlhttp_sol.onreadystatechange=function() { 
		if (xmlhttp_sol.readyState==4 && xmlhttp_sol.status==200) {
			document.getElementById("tag_disp").innerHTML=xmlhttp_sol.responseText;
			prob_query("last_query","");
		}
	}

	xmlhttp_sol.open("GET","print_tag_disp_pref.php?toggle=true", true);
	xmlhttp_sol.send();
}
