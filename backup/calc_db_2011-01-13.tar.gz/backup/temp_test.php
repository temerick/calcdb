<?

include("connect.php");
include("functions.php");

if(imagejpeg(imagecreatefrompng("problem_images/279-0.png"),"problem_images/279-0.jpg")) {
	echo "File problem_images/279-0.jpg has been created.<br />";
}

echo "Done!!!";

?>
